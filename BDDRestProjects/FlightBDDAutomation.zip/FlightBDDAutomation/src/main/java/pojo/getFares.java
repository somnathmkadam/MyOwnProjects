package pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class getFares {
	
	private String showReturnFares;
	private String appVersion;

	private String osVersion;
	private String origin;
	private String destination;
	
	private String showOnwardFares;
	private String flightType;
	private String userType;
	private String sessionId;
	private String bookingMode;
	private String deviceId;
	
	private String noOfAdults;
	private String enableMulti;
	private String noOfInfants;
	private String travelClass;
	private String tripType;
	private String domain;
	
	private String flightPrice;
	public String getFlightPrice() {
		return flightPrice;
	}
	public void setFlightPrice(String flightPrice) {
		this.flightPrice = flightPrice;
	}
	public String getFlightIdCSV() {
		return flightIdCSV;
	}
	public void setFlightIdCSV(String flightIdCSV) {
		this.flightIdCSV = flightIdCSV;
	}
	public String getFlightIDCSV_Supplier() {
		return FlightIDCSV_Supplier;
	}
	public void setFlightIDCSV_Supplier(String flightIDCSV_Supplier) {
		FlightIDCSV_Supplier = flightIDCSV_Supplier;
	}
	public String getSearchId() {
		return searchId;
	}
	public void setSearchId(String searchId) {
		this.searchId = searchId;
	}
	public String getSc() {
		return sc;
	}
	public void setSc(String sc) {
		this.sc = sc;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getAjx() {
		return ajx;
	}
	public void setAjx(String ajx) {
		this.ajx = ajx;
	}
	public String getBpc() {
		return bpc;
	}
	public void setBpc(String bpc) {
		this.bpc = bpc;
	}
	public String getFlightTypeCSV() {
		return flightTypeCSV;
	}
	public void setFlightTypeCSV(String flightTypeCSV) {
		this.flightTypeCSV = flightTypeCSV;
	}
	private String flightIdCSV;
	private String FlightIDCSV_Supplier;
	private String searchId;
	private String sc;
	private String mode;
	private String emailId;
	private String ajx;
	private String bpc;
	private String flightTypeCSV;
	
	
	public String getNoOfAdults() {
		return noOfAdults;
	}
	public void setNoOfAdults(String noOfAdults) {
		this.noOfAdults = noOfAdults;
	}
	public String getEnableMulti() {
		return enableMulti;
	}
	public void setEnableMulti(String enableMulti) {
		this.enableMulti = enableMulti;
	}
	public String getNoOfInfants() {
		return noOfInfants;
	}
	public void setNoOfInfants(String noOfInfants) {
		this.noOfInfants = noOfInfants;
	}
	public String getTravelClass() {
		return travelClass;
	}
	public void setTravelClass(String travelClass) {
		this.travelClass = travelClass;
	}
	public String getTripType() {
		return tripType;
	}
	public void setTripType(String tripType) {
		this.tripType = tripType;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getExpectedRespTime() {
		return expectedRespTime;
	}
	public void setExpectedRespTime(String expectedRespTime) {
		this.expectedRespTime = expectedRespTime;
	}
	public String getOrigin1() {
		return origin1;
	}
	public void setOrigin1(String origin1) {
		this.origin1 = origin1;
	}
	private String expectedRespTime;
	
	@JsonProperty("tripList[0].origin")
	private String origin1 ;

	
	@JsonProperty("tripList[0].destination")
	private String destination1 ;
	
	@JsonProperty("tripList[0].departureDate")
	private String dearturedate ;
	
	
	public String getDearturedate() {
		return dearturedate;
	}
	public void setDearturedate(String dearturedate) {
		this.dearturedate = dearturedate;
	}
	public String getDestination1() {
		return destination1;
	}
	public void setDestination1(String destination1) {
		this.destination1 = destination1;
	}
	public String getNoOfChildren() {
		return noOfChildren;
	}
	public void setNoOfChildren(String noOfChildren) {
		this.noOfChildren = noOfChildren;
	}
	private String noOfChildren;
	
	public String getShowReturnFares() {
		return showReturnFares;
	}
	public void setShowReturnFares(String showReturnFares) {
		this.showReturnFares = showReturnFares;
	}
	public String getAppVersion() {
		return appVersion;
	}
	public void setAppVersion(String appVersion) {
		this.appVersion = appVersion;
	}
	
	public String getOsVersion() {
		return osVersion;
	}
	public void setOsVersion(String osVersion) {
		this.osVersion = osVersion;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	

	
	public String getShowOnwardFares() {
		return showOnwardFares;
	}
	public void setShowOnwardFares(String showOnwardFares) {
		this.showOnwardFares = showOnwardFares;
	}
	public String getFlightType() {
		return flightType;
	}
	public void setFlightType(String flightType) {
		this.flightType = flightType;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public String getBookingMode() {
		return bookingMode;
	}
	public void setBookingMode(String bookingMode) {
		this.bookingMode = bookingMode;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	

}

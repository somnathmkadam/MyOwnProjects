package resources;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import java.util.HashMap;

import java.util.Map;
import java.util.Properties;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;



public class Utils {
	public static RequestSpecification req; 
	public RequestSpecification reqSpec(String interactionid, String Excelread) throws IOException {
		
		
		
//		if (req==null)  //if req is saved then no need to execute same request again
//	{
				
			PrintStream log = new PrintStream(new FileOutputStream("logging.txt"));
			req = new RequestSpecBuilder().setBaseUri(getGlobalValue("baseUrl"))
					 .addFilter(RequestLoggingFilter.logRequestTo(log))
					 .addFilter(ResponseLoggingFilter.logResponseTo(log)) //used to log request and response
					 .setContentType(ContentType.URLENC)
					 .addHeader("App-Version", "339")
					 .addHeaders(getHeaders(interactionid,Excelread))
					 .build();
			         
			return req;
		
	}
	
	public Map<String,String> getHeaders(String interaction,String Excelreader) throws IOException {
		ReadExcelSheetData read = new ReadExcelSheetData();
		Map<String,String> headerMap = new HashMap<String,String>();
		if(Excelreader.equals("true"))
				{
			headerMap = read.setMapData().get("DataSheet");
			return headerMap;
		}
		interaction = interaction==null?"b8ca4e2c-9b61-4c93-b1f9-6aaafa4b7ca8":interaction;  //if else shortcut method
		headerMap. put("Device-Id", "b73d13743966d9cd");
		headerMap. put("yt-code", "898cca20b1066c2621c4ee78d5f32850");
		headerMap. put("Parent-Interaction-Id",interaction);
		System.out.println("fetch interaction id is :"+ interaction);
		headerMap. put("Connection", "close");
		headerMap. put("User-Agent", "yatra/13.0.95 (Android 9)");
		headerMap. put("secure-s-token", "1b99a635-f77f-4ff4-b35c-4870725e97a9");
		headerMap. put("Session-Id", "b73d13743966d9cd15864154924976981");
		//headerMap. put("Connection", "close");
		return headerMap;
	}
	public static String getGlobalValue(String key) throws IOException {  //accepts baseurl from requestspecification method and applied it to properties file to fetch baseurl
		Properties prop = new Properties(); //create empty property list
		FileInputStream fis = new FileInputStream("D:\\Eclipse\\MyOwnProject\\FlightBDDAutomation\\src\\test\\java\\resources\\global.properties");
		prop.load(fis); //load all params into property file
		 return prop.getProperty(key);
		
		
	}
	
	public String getJsonpathandExtractvalue(Response response, String key) {
		String res = response.asString();
	     JsonPath js = new JsonPath(res);
	     return js.get(key).toString();
		
		
	}
	
	public JsonPath getJsonResponseValue(Response response) {
		String res = response.asString();
	     JsonPath js = new JsonPath(res);
	     return js;
		
		
	}
}

package resources;

import pojo.getFares;

public class TestDataBuild {

	public getFares getfarespayload() {
		
	getFares fare = new getFares();
	fare.setShowReturnFares("true");
	fare.setAppVersion("339");
	fare.setBookingMode("");
	fare.setDestination("BOM");
	fare.setOrigin("DEL");
	fare.setShowOnwardFares("true");
	fare.setFlightType("R");
	fare.setUserType("GUEST");
	fare.setSessionId("b93d13743966d9cd15864154924976981");
	fare.setDeviceId("b73d13743966d9cd");
	fare.setOsVersion("28");
	return fare;
	}
	
	public getFares prestocallpayload(String interactionID) {
		    
		getFares fare = getfarespayload();
		fare.setNoOfChildren("0");
		fare.setOrigin1("DEL");
		fare.setDestination1("BOM");
		fare.setNoOfAdults("1");
		fare.setNoOfInfants("0");
		fare.setEnableMulti("true");
		fare.setTravelClass("Economy");
		fare.setTripType("ONEWAY");
		fare.setDomain("DOM");
		fare.setExpectedRespTime("9000");
		fare.setDearturedate("03/09/2020");
		return fare;
		}
	
	public   getFares getFlightPrice(String flightPrice, String flightIdCSV, String searchId, String SupplierID) {
	    
		getFares fare = getfarespayload();
	       fare.setFlightPrice(flightPrice);
	       fare.setFlightIdCSV(flightIdCSV);
	       fare.setFlightIDCSV_Supplier(flightIdCSV);
	       fare.setFlightTypeCSV("nf");
	       fare.setSearchId(searchId);
	       fare.setMode("Background");
	       fare.setEmailId("yatratestbookings@gmail.com");
	       fare.setBpc("false");
	       fare.setSc(SupplierID);
	       return fare;
	       
		}
	
	
	
	
}

package resources;
import java.io.IOException;
public class MainClass {

/*	public static void main(String[] args) throws IOException {
		ReadExcelSheetData r = new ReadExcelSheetData();
		String val = r.getMapData("TestCases");
		System.out.println("Value of the keyword (search) is- "+val);
		}*/
	
}

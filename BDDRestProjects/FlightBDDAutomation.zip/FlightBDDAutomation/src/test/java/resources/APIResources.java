package resources;

public enum APIResources {

	getFaresAPI("/ccwebapp/mobile/flight/mdomandroid/getFares.htm"),
	getFlightsFromPresto("/ccwebapp/mobile/flight/mdomandroid/getFlightsFromPresto.htm"),
	getFlightPriceBack("/ccwebapp/mobile/flight/mdomandroid/v7/getFlightPrice.htm");
	
	private String Resource;
	APIResources(String resources){ //constructor of apiresources class
		this.Resource = resources;
		
	}
	
	public String getresource() {
		return Resource; //pass resource to this method
	}
	
	
}

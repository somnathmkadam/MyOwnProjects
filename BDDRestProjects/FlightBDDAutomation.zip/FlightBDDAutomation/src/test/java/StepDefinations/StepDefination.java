package StepDefinations;

import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

import java.util.Map;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import resources.APIResources;
import resources.TestDataBuild;
import resources.Utils;

public class StepDefination extends Utils{
	RequestSpecification res;
	Response Response;
	ResponseSpecification resspec;
	TestDataBuild data = new TestDataBuild();
	private static String intractionID;
	private static String intractionIDPresto;
	private static String flightIdPresto;
	private static String  totalFarePresto;
	private static String  fltSupplierIdPresto;
	private static String ExcelSheetReader;
	
	@Given("^\"([^\"]*)\" playload$")
	public void playload(String payload) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		RestAssured.baseURI="https://secure.yatra.com";
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> map = null;
		
		 if(payload.equalsIgnoreCase("getfare"))  // Convert POJO to Map
		map =  mapper.convertValue(data.getfarespayload(), new TypeReference<Map<String, Object>>() {});
		
		 if(payload.equalsIgnoreCase("prestocall"))
	    map =  mapper.convertValue(data.prestocallpayload(intractionID), new TypeReference<Map<String, Object>>() {});
		 
		 if(payload.equalsIgnoreCase("FlightPriceBackground"))
			 map =  mapper.convertValue(data.getFlightPrice(totalFarePresto, flightIdPresto, intractionID, fltSupplierIdPresto), new TypeReference<Map<String, Object>>() {});
		 
		res = given().spec(reqSpec(intractionID,ExcelSheetReader)).formParams(map);
		
	}

	@When("^User calls \"([^\"]*)\" with \"([^\"]*)\" Http request$")
	public void user_calls_with_Http_request(String resource, String method) throws Throwable {
		APIResources resourcevalue =APIResources.valueOf(resource);
		resspec= new ResponseSpecBuilder().build();
		
		if(method.equalsIgnoreCase("post"))
			 Response=  res.when()
			.post(resourcevalue.getresource())
				.then()
				.spec(resspec)
				.extract()
				.response();
	
	   
	}

	@Then("^The API call got success with status code (\\d+)$")
	public void the_API_call_got_success_with_status_code(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		assertEquals(Response.getStatusCode(),200);
		assertEquals(getJsonpathandExtractvalue(Response,"resMessage"), "Success") ;
		
	}

	@Then("^\"([^\"]*)\" in response body is \"([^\"]*)\"$")
	public void in_response_body_is(String keyvalue, String Expectedvalue) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 assertEquals(getJsonpathandExtractvalue(Response,keyvalue), Expectedvalue) ;
	}

	@Then("^fetch interactionId from response body$")
	public void fetch_interactionId_from_response_body() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		intractionID=	getJsonpathandExtractvalue(Response, "interactionId");
	//   JsonPath jsonPath =  getJsonResponseValue(Response); 
	//   intractionID = jsonPath.getString("interactionId");
	   System.out.println("Interaction id from response is: "+ intractionID );
	}
	

@Then("^fetch \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" from response body$")
public void fetch_from_response_body(String interactionId, String flightId, String totalFare, String fltSupplierId) throws Throwable {
    
	intractionID=	getJsonpathandExtractvalue(Response,interactionId);
	System.out.println("Presto call interaction id is :"+ intractionID);
	
	 flightIdPresto=  getJsonpathandExtractvalue(Response,"response.searchResults.sectorResults[0].flights[0].allFares[0]."+flightId +""); 
	 System.out.println("flightid id :"+ flightIdPresto);
	
      totalFarePresto = getJsonpathandExtractvalue(Response, "response.searchResults.sectorResults[0].flights[0].allFares[0]."+totalFare+"");
	             
     fltSupplierIdPresto = getJsonpathandExtractvalue(Response, "response.searchResults.sectorResults[0].flights[0].allFares[0]."+fltSupplierId+"");
      
}

@Given("^ExcelSheetRead \"([^\"]*)\"$")
public void excelsheetread_something(String ExcelReadervalue) throws Throwable {

	
	ExcelSheetReader=ExcelReadervalue;
	
}







}

package PassdataFromMainclass;

public class Body {

	public static String body(String GUEST, String city) {
		String body= "appVersion=339&offset=10&isPaginated=true&sessionId=b73d13743966d9cd15856559148951993&firstTimeLocation=false&filterBy=&categoryName="+city+"&checkInDate=23%2F05%2F2020&deviceId=b73d13743966d9cd&roomRequests%5B0%5D.noOfAdults=1&country.code=India&checkOutDate=24%2F05%2F2020&osVersion=28&propertyType=hotels&categoryValue=Bengaluru&country.name=India&roomRequests%5B0%5D.id=1"
				+ "&sortBy=&page=1&userType="+GUEST+"&roomRequests%5B0%5D.noOfChildren=0&cameFromLastMinuteDeals=false&bookingMode=&";
		System.out.println("body is"+ body);
		return body;
	}
	
	public static String Payload1(String appversion, String desti){	   //this is how to pass json body
		String body1= "\"INF\":\"0\",\"appVersion\":\""+appversion+"\",\"origin\":\"DEL\",\"destination\":\""+desti+"\"\",\"sessionId\":\"b73d13743966d9cd15794106683223259\",\"type\":\"O\",\"deviceId\":\"b73d13743966d9cd\",\"ADT\":\"1\",\"flight_depart_date\":\"05/06/2020\",\"osVersion\":\"28\",\"userType\":\"GUEST\",\"class\":\"Economy\",\"bookingMode\":\"\",\"CHD\":\"0\" \r\n" + 
				"";	
				return body1;
				
		}
}

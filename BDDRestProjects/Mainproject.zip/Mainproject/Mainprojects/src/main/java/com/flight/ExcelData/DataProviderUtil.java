package com.flight.ExcelData;
import org.testng.ITestContext;
import org.testng.annotations.DataProvider;



public class DataProviderUtil {

	@DataProvider(name = "TestData")
	public static Object[][] getData() throws Exception {
		Object[][] OW_SRP = null;
		Testdatagenerator testdata = new Testdatagenerator();
		try{
			OW_SRP = testdata.getTestDataForSanityTest();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Data from excel sheet is :" + OW_SRP);
		return OW_SRP;
		
	}
	
	
	
}


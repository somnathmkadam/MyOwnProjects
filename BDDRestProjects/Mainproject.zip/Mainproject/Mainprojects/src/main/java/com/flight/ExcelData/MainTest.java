package com.flight.ExcelData;
import java.util.LinkedHashMap;
import java.util.List;

import org.testng.annotations.Test;



public class MainTest extends BaseTest {

	@Test(dataProvider = "TestData" , dataProviderClass = DataProviderUtil.class)	
	public void  flightSearch(List data) throws Exception {
		//ctl+shift+l multi comment	
		
		System.out.println("Flight list of data is given below :\n"+ data);
//Flight list of data is given below :
//[TestName_FlightSearch, TestDescription_Verify Flight Search, Domain_DOM, Origin_DEL, Destination_BOM, DepartureDate_3, ReturnDate_5, TripType_ONEWAY, Adult_2, Child_1, Infant_1, Class_Economy, OsVersion_23, AppVersion_197, Platform_android, Yes/No_Yes]



//Now convert data into hashmap
		HashMapData=	Testdatagenerator.getHashMap(data);  //Hashmap take from BaseTest extend here
		System.out.println("HashMap data is :\n"+ HashMapData);
	//	HashMap data is :
	//	{TestName=FlightSearch, TestDescription=Verify Flight Search, Domain=DOM, Origin=DEL, Destination=BOM, DepartureDate=7, ReturnDate=10, TripType=ONEWAY, Adult=2, Child=1, Infant=9, Class=Economy, OsVersion=23, AppVersion=197, Platform=android, Yes/No=Yes}
             System.out.println("get perticular value from hashmap: "+ HashMapData.get("TestName") );
             //now we can set this values in pojo 
             
             
  //Now we can fetch all data we want from overall data and then pass it as a body
             LinkedHashMap<String, String> searchParams = new LinkedHashMap<String, String>();
             searchParams.put("appVersion", HashMapData.get("appVersion"));
 			searchParams.put("osVersion", HashMapData.get("OsVersion"));
 			searchParams.put("domain", HashMapData.get("Domain"));
 	         searchParams.put("tripType", HashMapData.get("TripType"));
 
 	         HashMapData.remove("appVersion");
 	         
 	         System.out.println("Converted linked hasmap response is  :\n"+ searchParams );
}
	
}

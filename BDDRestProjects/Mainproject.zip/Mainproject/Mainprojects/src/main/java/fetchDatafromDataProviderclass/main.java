package fetchDatafromDataProviderclass;

import org.testng.annotations.Test;

public class main {

	@Test(dataProvider = "data-provider", dataProviderClass = DataproviderinAnotherClass.class)
    public void testMethod(String data) 
    {
        System.out.println("Data is: " + data);
    }
	
}

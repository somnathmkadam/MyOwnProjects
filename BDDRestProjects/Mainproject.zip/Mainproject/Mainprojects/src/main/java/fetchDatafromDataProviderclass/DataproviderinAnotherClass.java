package fetchDatafromDataProviderclass;

import org.testng.annotations.DataProvider;

public class DataproviderinAnotherClass {
	
	@DataProvider(name = "data-provider")
    public static Object[][] dataProviderMethod() 
    {
        return new Object[][] { { "data one" }, { "data two" } };
    }

}

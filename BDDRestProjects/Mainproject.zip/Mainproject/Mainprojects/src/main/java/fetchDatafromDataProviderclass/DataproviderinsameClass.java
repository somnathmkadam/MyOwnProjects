package fetchDatafromDataProviderclass;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;




public class DataproviderinsameClass {
	
	
	 @DataProvider(name = "data-provider1")
	    public Object[][] dataProviderMethod() {
	        return new Object[][] { { "Key","b73d13743966d9cd"},{"key","b73d13743966d9cd"} };
	    }
	 
	    @Test(dataProvider = "data-provider1")
	    public void testMethod(String data, String data2)   {
	    	
	    	System.out.println("datafrom dataprovider is :" +data +""+ data2);
	    	
	    }

}

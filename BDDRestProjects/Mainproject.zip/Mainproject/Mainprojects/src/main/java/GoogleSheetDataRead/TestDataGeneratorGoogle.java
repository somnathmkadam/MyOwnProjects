package GoogleSheetDataRead;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.SheetsScopes;
import com.google.api.services.sheets.v4.model.ValueRange;


public class TestDataGeneratorGoogle {
	List<Object> googleSheetHeader = null;  
	public Object [][] getGooglesheetTestData(String speradsheetID, String SheetName){ //get data id and name from gettestdataforsanity method which send to getgooglesheetdata to get google data
		Object [][] array = null;
		
		try {
			System.out.println("getGoogleSheetTestData : Start");
			
			System.out.println("_______________________________________");
			System.out.println("Total test in " + SheetName + " sheet to Run: "); //show number of yes rows in one sheet
			System.out.println("_______________________________________");
			List<List<Object>> listData =	getGoogleSheetdata(speradsheetID, SheetName); //pass id and name to getGoogleSheetdata method //fetch data from getgoogle sheet and pass it to listData
			//listdata taken from sheetdata 
			
			googleSheetHeader =	listData.get(0); //get header/ all keys
			listData.remove(0); //Remove header from list data only values are remaining used to fetch data from excel sheet
			array = getArrayGoogleSheet(listData, googleSheetHeader);
			System.out.println("_______________________________________");
			System.out.println("Total test in " + SheetName + " sheet to Run: " + array.length);
			System.out.println("_______________________________________");
			
		}
		catch(Exception e){ //after catch exception class is base class of every exception
			// finally is used when we have run perticular mandatorly
			//After executing the catch block, the control will be transferred to finally block(if present) and then the rest program will be executed.
	//The class Exception and any subclasses that are not also subclasses of RuntimeException are checked exceptions. Checked exceptions need to be declared in a method or constructor's throws clause if they can be thrown by the execution of the method or constructor and propagate outside the method or constructor boundary.
			
			System.out.println("Exception in getGoogleSheetTestData: "+e);
			
		}
		finally {
			System.out.println("getGoogleSheetTestData : End");
		}
		return array;
		
	}
	
	
	public static List<List<Object>> getGoogleSheetdata(String spreadsheetId, String sheetName)throws Exception{ //this method is used to use this data many times in many classes
		List<List<Object>> sheetdata = new ArrayList<List<Object>>(); //initalized array list
		try {
			sheetdata = getAllTestDataFromGoogleSheet(spreadsheetId, sheetName); // now pass this data to another method to used it getAllTestDataFromGoogleSheet
			//take sheetdata and pass it to getGooglesheetTestData as listData
		}
	catch(Exception e) {
		e.printStackTrace();
	}
		return sheetdata;
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public static List<List<Object>> getAllTestDataFromGoogleSheet (String spreadsheetId, String sheetName) throws Exception{
		List<List<Object>> values = new ArrayList<List<Object>>();
		try {
			String range = sheetName; // passes it to google api request 
			System.out.println("GoogleSpreadsheetId:" + spreadsheetId);
			System.out.println("TestSheetName: " + sheetName);
			Sheets service= getSheetsService();
			
			ValueRange response = service.spreadsheets().values().get(spreadsheetId, range).execute(); //Google API Execution call
			
			       values= response.getValues(); //get value and return as list of list object
			       
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return values;
	}
	
	
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	
	
	
	
public static final String APPLICATION_NAME = "Google Sheets API Java Quickstart";
public static Sheets getSheetsService() throws Exception {
	Credential credential = authorize();
	return new Sheets.Builder(HTTP_TRANSPORT, JSON_FACTORY, credential).setApplicationName(APPLICATION_NAME)
			.build(); //return sheets type object/ instance
}


/** Global instance of the JSON factory. */ //created global variable
private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
public static Credential authorize() throws Exception {
	// Load client secrets.
	InputStream in = TestDataGeneratorGoogle.class.getResourceAsStream("/client_secret.json");
	GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

	// Build flow and trigger user authorization request.
	GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(HTTP_TRANSPORT, JSON_FACTORY,
			clientSecrets, SCOPES).setDataStoreFactory(DATA_STORE_FACTORY).setAccessType("offline").build();
	
	Credential credential = new AuthorizationCodeInstalledApp(flow, new LocalServerReceiver()).authorize("user");
	System.out.println("Credentials saved to " + DATA_STORE_DIR.getAbsolutePath());
	return credential;
} 


/** Global instance of the {@link FileDataStoreFactory}. */
private static  FileDataStoreFactory DATA_STORE_FACTORY;
private static HttpTransport HTTP_TRANSPORT;     /** Global instance of the HTTP transport. */
private static final File DATA_STORE_DIR = new File( System.getProperty("user.dir") + File.separator + "src/main/resources"); /** Directory to store user credentials for this application. */

private static final List<String> SCOPES = Arrays.asList(SheetsScopes.SPREADSHEETS_READONLY);
static {
	try {
		HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
		DATA_STORE_FACTORY = new FileDataStoreFactory(DATA_STORE_DIR);
	} catch (Throwable t) {
		t.printStackTrace();
		System.exit(1);
	}
} 


////////////////////////////////////////////////////////////////////////////////////////////////////////

public Object[][] getArrayGoogleSheet(List<List<Object>> sheetData, List<Object> headers) {
	List<List<Object>> list = new ArrayList<List<Object>>();
	List<Object> tempList, list1=null; 

	// int indYN = getIndexFromSheetHeaderListOO("Yes/No");
	int indYN = googleSheetHeader.size() - 1;

	Iterator<List<Object>> checkData = sheetData.iterator();
	List<Object> oneDList = null;
	while (checkData.hasNext()) {
		oneDList = (List<Object>) checkData.next();

		if (oneDList.get(indYN).toString().equalsIgnoreCase("Yes")) {
			tempList = new ArrayList<Object>();
			
			for (int i = 0; i < oneDList.size(); i++) {
				tempList.add(headers.get(i).toString() + "_" + oneDList.get(i).toString());
			}
			
			list.add(tempList);
		}
	}

	Object[][] result = new Object[list.size()][];
	try {
		for (int i = 0; i < result.length; i++) {
			result[i] = new Object[] { list.get(i)
					// listToHashMap(list.get(i))
			};

		}
	} catch (Exception ex) {
		System.out.println("Exception is :: " + ex);
	}
	System.out.println("Result from googlesheetarray "+ result);
	return result;
	
}


	
}

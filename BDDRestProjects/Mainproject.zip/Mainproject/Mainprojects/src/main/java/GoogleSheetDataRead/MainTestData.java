package GoogleSheetDataRead;

import java.util.List;

import org.testng.annotations.Test;



@SuppressWarnings("rawtypes")
public class MainTestData extends BaseTest{
	
	@Test(	dataProvider="Dataprovider", dataProviderClass= DataProviderClass.class)
	public void flightsearch(List data) {  //dataprovider class provide data in list format and pass it to gethashmap to convert Key_value
	testdata=TestDataGenerator.getHashMap(data);  //testdata used in BaseTest written a reused it another classes
	
	//https://console.developers.google.com/apis/dashboard?authuser=1&project=quickstart-1583598726692&folder=&organizationId=&supportedpurview=project
	//for client screts
	System.out.println("My data from flight is :\n"+data);

	}

}

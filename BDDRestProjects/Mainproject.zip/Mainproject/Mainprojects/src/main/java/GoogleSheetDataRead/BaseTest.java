package GoogleSheetDataRead;

import java.util.HashMap;

public class BaseTest {
	public HashMap <String, String> testdata = new HashMap <String,String>();

}

package GoogleSheetDataRead;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCell;


public class TestDataGenerator {
	private String workBookName;  // used for getter setter make variable private
	private String workSheet;
	private String testCaseId;
	private String dataDriver;
	private String spreadsheetId;
	List<XSSFCell> sheetHeader = null;
	List<HSSFCell> sheetHeaderOO = null;
	
	TestDataGeneratorGoogle GoogleSheetdataObject = new TestDataGeneratorGoogle(); //created object for TestDataGeneratorGoogle becasue its in same package
	
	public TestDataGenerator (String xlworkBook, String xlsheetname, String xldataDriver, String xlspreadsheetId)
	//we used parameterized constructor which should be as per dataprovider class but name can be different constructor is same as class name used to inheriated this class from any class inside or outside the package
	//because if type mismatched the it will throw an error
	// after this we used getter setter method to secure the strings so it cannot used outside this class called encapsulation
	{
		this.dataDriver = xldataDriver; //show java that both are same 
		this.workBookName = xlworkBook;
		this.workSheet = xlsheetname;
		this.testCaseId = xlspreadsheetId;
		this.spreadsheetId = xlspreadsheetId;
		
	}

	public String getWorkBookName() {  //alt+shift+s to create getter setter method 
		return workBookName;
	}

	public void setWorkBookName(String workBookName) {
		this.workBookName = workBookName;
	}

	public String getWorkSheet() {
		return workSheet;
	}

	public void setWorkSheet(String workSheet) {
		this.workSheet = workSheet;
	}

	public String getTestCaseId() {
		return testCaseId;
	}

	public void setTestCaseId(String testCaseId) {
		this.testCaseId = testCaseId;
	}

	public String getDataDriver() {
		return dataDriver;
	}

	public void setDataDriver(String dataDriver) {
		this.dataDriver = dataDriver;
	}

	public String getSpreadsheetId() {
		return spreadsheetId;
	}

	public void setSpreadsheetId(String spreadsheetId) {
		this.spreadsheetId = spreadsheetId;
	}
	
	public Object [][] gettestdataforsanity(){ //accept only 2D array method
		Object[][] array = null; 
		try {
			switch (dataDriver) {
			case "GOOGLESHEET":
				array = GoogleSheetdataObject.getGooglesheetTestData(spreadsheetId, workSheet); //called parameterized constructor using object and passing paramter which used by that constructor
				System.out.println("get data from array "+ array.toString());	//get data array data without double quotes
				break; //switch command ends
				
			}
			
			}
		catch (Exception e) {// added exception for catch block
			
		} finally { //finally used to run perticular function after try catch
		
		}
		
		return array;  //return 2D object array	
	}
	
	
	public static HashMap<String, String> getHashMap (List data){
		HashMap<String, String> testdata = new LinkedHashMap<String, String>();
		for (int i = 0; i < data.size(); i++) {
			String[] temp = data. get(i).toString().split("_");

			if (temp.length == 1)
				testdata.put(temp[0], "");
			else
				testdata.put(temp[0], temp[1]);
		}
		return testdata;
	}
	
	
}

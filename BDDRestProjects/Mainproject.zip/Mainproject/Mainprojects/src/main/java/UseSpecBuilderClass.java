


import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import static io.restassured.RestAssured.given;



public class UseSpecBuilderClass {
	public static void main (String args[]) {
	
	RequestSpecification request=	new RequestSpecBuilder().setBaseUri("url").addQueryParam("key", "value").setContentType(ContentType.JSON).build();
	 ResponseSpecification check= new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();
	 
	Response response=	given().spec(request).body("").when().post("resourcses").then().extract().response();
	
	//OR
	RequestSpecification res1=	given().spec(request).body("");  //we can divide the complete request in two parts
	Response res=res1.when().post().then().spec(check).extract().response();
    String responseString= res.asString(); 
   
   

	
	
}

		 
	}
 


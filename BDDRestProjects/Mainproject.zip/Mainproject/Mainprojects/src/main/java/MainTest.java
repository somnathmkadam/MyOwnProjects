import java.util.List;

import org.testng.annotations.Test;



public class MainTest {

	@Test(dataProvider = "TestData" , dataProviderClass = DataProviderUtil.class)	
	public void  flightSearch(List data) throws Exception {
		
		
		System.out.println("Flight list of data is given below :\n"+ data);
//Flight list of data is given below :
//[TestName_FlightSearch, TestDescription_Verify Flight Search, Domain_DOM, Origin_DEL, Destination_BOM, DepartureDate_3, ReturnDate_5, TripType_ONEWAY, Adult_2, Child_1, Infant_1, Class_Economy, OsVersion_23, AppVersion_197, Platform_android, Yes/No_Yes]
//ctl+shift+l multi comment

		
	
}
}

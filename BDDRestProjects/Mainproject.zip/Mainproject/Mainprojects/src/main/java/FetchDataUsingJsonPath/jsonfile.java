package FetchDataUsingJsonPath;

public class jsonfile {
/*
 Viewer
Text
 
Paste	
 
 
Copy	
 
 
Format	
 
 
Remove white space	
 
 
Clear	
 
 
Load JSON data	
 
 
About	
 
{
  "resCode": 200,
  "resMessage": "Success",
  "interactionId": "23052020-24052020-10zzzzz-00zzzzz-00zzzzz-00zzzzz:51320",
  "interationType": "HotelSearchV4",
  "sessionId": "b73d13743966d9cd15856559148951993",
  "response": {
    "filterDetails": {
      "showTA": true,
      "booleanFilters": [
        
      ],
      "multiSelectFilters": [
        {
          "filterKey": "am",
          "filterValues": [
            {
              "count": 67,
              "label": "AC",
              "value": "02"
            },
            {
              "count": 19,
              "label": "ATM",
              "value": "06"
            },
            {
              "count": 71,
              "label": "Airport Transfer",
              "value": "03"
            },
            {
              "count": 2,
              "label": "Airport Transfer",
              "value": "04"
            },
            {
              "count": 51,
              "label": "Bar",
              "value": "09"
            },
            {
              "count": 219,
              "label": "Breakfast",
              "value": "32"
            },
            {
              "count": 25,
              "label": "Fitness Centre",
              "value": "410"
            },
            {
              "count": 39,
              "label": "Health club",
              "value": "52"
            },
            {
              "count": 311,
              "label": "Internet",
              "value": "54"
            },
            {
              "count": 27,
              "label": "Jacuzzi",
              "value": "355"
            },
            {
              "count": 559,
              "label": "Laundry",
              "value": "59"
            },
            {
              "count": 12,
              "label": "Night Club",
              "value": "349"
            },
            {
              "count": 318,
              "label": "Parking",
              "value": "71"
            },
            {
              "count": 2,
              "label": "Pool",
              "value": "80"
            },
            {
              "count": 2,
              "label": "Private Beach",
              "value": "82"
            },
            {
              "count": 27,
              "label": "Restaurant",
              "value": "536"
            },
            {
              "count": 225,
              "label": "Restaurant",
              "value": "83"
            },
            {
              "count": 357,
              "label": "Room Service",
              "value": "84"
            },
            {
              "count": 22,
              "label": "Spa",
              "value": "336"
            },
            {
              "count": 1,
              "label": "Spa",
              "value": "337"
            },
            {
              "count": 59,
              "label": "Suitable for children",
              "value": "100"
            },
            {
              "count": 97,
              "label": "Swimming Pool",
              "value": "345"
            },
            {
              "count": 279,
              "label": "WiFi",
              "value": "58"
            }
          ],
          "filterName": "Amenities"
        },
        {
          "filterKey": "la",
          "filterValues": [
            {
              "count": 5,
              "label": "Airport Road",
              "value": "Airport Road"
            },
            {
              "count": 1,
              "label": "Amruthahalli",
              "value": "Amruthahalli"
            },
            {
              "count": 28,
              "label": "Anand Rao Circle",
              "value": "Anand Rao Circle"
            },
            {
              "count": 7,
              "label": "B T M Layout",
              "value": "B T M Layout"
            },
            {
              "count": 2,
              "label": "Balepet",
              "value": "Balepet"
            },
            {
              "count": 3,
              "label": "Banashankari",
              "value": "Banashankari"
            },
            {
              "count": 1,
              "label": "Banaswadi",
              "value": "Banaswadi"
            },
            {
              "count": 3,
              "label": "Bannerghatta",
              "value": "Bannerghatta"
            },
            {
              "count": 8,
              "label": "Bannerghatta Road",
              "value": "Bannerghatta Road"
            },
            {
              "count": 1,
              "label": "Bapuji Nagar",
              "value": "Bapuji Nagar"
            },
            {
              "count": 4,
              "label": "Basavangudi",
              "value": "Basavangudi"
            },
            {
              "count": 1,
              "label": "Basaveshwara Nagar",
              "value": "Basaveshwara Nagar"
            },
            {
              "count": 11,
              "label": "Bellandur",
              "value": "Bellandur"
            },
            {
              "count": 25,
              "label": "Bengaluru International Airport Road",
              "value": "Bengaluru International Airport Road"
            },
            {
              "count": 7,
              "label": "Bommasandra Industrial Area",
              "value": "Bommasandra Industrial Area"
            },
            {
              "count": 12,
              "label": "Brigade Road",
              "value": "Brigade Road"
            },
            {
              "count": 3,
              "label": "Brookefield",
              "value": "Brookefield"
            },
            {
              "count": 1,
              "label": "Btm Layout Stage 1",
              "value": "Btm Layout Stage 1"
            },
            {
              "count": 1,
              "label": "Channasandra",
              "value": "Channasandra"
            },
            {
              "count": 1,
              "label": "Cooke Town",
              "value": "Cooke Town"
            },
            {
              "count": 6,
              "label": "Cunningham Road",
              "value": "Cunningham Road"
            },
            {
              "count": 3,
              "label": "Devanahalli",
              "value": "Devanahalli"
            },
            {
              "count": 2,
              "label": "Doddaballapur Main Road",
              "value": "Doddaballapur Main Road"
            },
            {
              "count": 16,
              "label": "Domlur",
              "value": "Domlur"
            },
            {
              "count": 6,
              "label": "Double Road",
              "value": "Double Road"
            },
            {
              "count": 1,
              "label": "Ejipura",
              "value": "Ejipura"
            },
            {
              "count": 20,
              "label": "Electronic City",
              "value": "Electronic City"
            },
            {
              "count": 2,
              "label": "Frazer Town",
              "value": "Frazer Town"
            },
            {
              "count": 30,
              "label": "Gandhi Nagar",
              "value": "Gandhi Nagar"
            },
            {
              "count": 1,
              "label": "Gottigere",
              "value": "Gottigere"
            },
            {
              "count": 1,
              "label": "Hbr Layout",
              "value": "Hbr Layout"
            },
            {
              "count": 22,
              "label": "Hebbal",
              "value": "Hebbal"
            },
            {
              "count": 1,
              "label": "Hennur",
              "value": "Hennur"
            },
            {
              "count": 2,
              "label": "High Grounds",
              "value": "High Grounds"
            },
            {
              "count": 10,
              "label": "Hosur Main Road",
              "value": "Hosur Main Road"
            },
            {
              "count": 15,
              "label": "Hsr Layout",
              "value": "Hsr Layout"
            },
            {
              "count": 20,
              "label": "Indira Nagar",
              "value": "Indira Nagar"
            },
            {
              "count": 7,
              "label": "Infantry Road",
              "value": "Infantry Road"
            },
            {
              "count": 18,
              "label": "J P Nagar",
              "value": "J P Nagar"
            },
            {
              "count": 1,
              "label": "Jakkur",
              "value": "Jakkur"
            },
            {
              "count": 3,
              "label": "Jalahalli",
              "value": "Jalahalli"
            },
            {
              "count": 18,
              "label": "Jayanagar",
              "value": "Jayanagar"
            },
            {
              "count": 1,
              "label": "K R Road",
              "value": "K R Road"
            },
            {
              "count": 1,
              "label": "Kadubisannahalli",
              "value": "Kadubisannahalli"
            },
            {
              "count": 1,
              "label": "Kalasipalyam",
              "value": "Kalasipalyam"
            },
            {
              "count": 7,
              "label": "Kalyan Nagar",
              "value": "Kalyan Nagar"
            },
            {
              "count": 10,
              "label": "Kammanahalli",
              "value": "Kammanahalli"
            },
            {
              "count": 1,
              "label": "Kempe Gowda Road",
              "value": "Kempe Gowda Road"
            },
            {
              "count": 4,
              "label": "Kodihalli",
              "value": "Kodihalli"
            },
            {
              "count": 46,
              "label": "Koramangala",
              "value": "Koramangala"
            },
            {
              "count": 6,
              "label": "Krishnarajapuram",
              "value": "Krishnarajapuram"
            },
            {
              "count": 3,
              "label": "Lavelle Road",
              "value": "Lavelle Road"
            },
            {
              "count": 11,
              "label": "M G Road",
              "value": "M G Road"
            },
            {
              "count": 15,
              "label": "Madiwala",
              "value": "Madiwala"
            },
            {
              "count": 5,
              "label": "Mahadevapura Post",
              "value": "Mahadevapura Post"
            },
            {
              "count": 44,
              "label": "Majestic",
              "value": "Majestic"
            },
            {
              "count": 4,
              "label": "Malleshwaram",
              "value": "Malleshwaram"
            },
            {
              "count": 3,
              "label": "Manyata Tech Park",
              "value": "Manyata Tech Park"
            },
            {
              "count": 9,
              "label": "Marathahalli",
              "value": "Marathahalli"
            },
            {
              "count": 9,
              "label": "Mathikere",
              "value": "Mathikere"
            },
            {
              "count": 9,
              "label": "Minerva Circle",
              "value": "Minerva Circle"
            },
            {
              "count": 7,
              "label": "Mysore Road",
              "value": "Mysore Road"
            },
            {
              "count": 2,
              "label": "Nagvara Palya Road",
              "value": "Nagvara Palya Road"
            },
            {
              "count": 2,
              "label": "New Bel Road",
              "value": "New Bel Road"
            },
            {
              "count": 2,
              "label": "New Tippasandra",
              "value": "New Tippasandra"
            },
            {
              "count": 7,
              "label": "Old Airport Road",
              "value": "Old Airport Road"
            },
            {
              "count": 1,
              "label": "Opp-t.dasarahalli Meto Station",
              "value": "Opp-t.dasarahalli Meto Station"
            },
            {
              "count": 3,
              "label": "Outer Ring Road",
              "value": "Outer Ring Road"
            },
            {
              "count": 29,
              "label": "Outskirts",
              "value": "Outskirts"
            },
            {
              "count": 1,
              "label": "Peenya Industrial Estate",
              "value": "Peenya Industrial Estate"
            },
            {
              "count": 9,
              "label": "R T Nagar",
              "value": "R T Nagar"
            },
            {
              "count": 9,
              "label": "Race Course Road",
              "value": "Race Course Road"
            },
            {
              "count": 1,
              "label": "Raj Bhavan Road",
              "value": "Raj Bhavan Road"
            },
            {
              "count": 11,
              "label": "Rajaji Nagar",
              "value": "Rajaji Nagar"
            },
            {
              "count": 2,
              "label": "Ramamurthy Nagar",
              "value": "Ramamurthy Nagar"
            },
            {
              "count": 7,
              "label": "Residency Road",
              "value": "Residency Road"
            },
            {
              "count": 11,
              "label": "Richmond Road",
              "value": "Richmond Road"
            },
            {
              "count": 1,
              "label": "Rustam Bagh",
              "value": "Rustam Bagh"
            },
            {
              "count": 1,
              "label": "Sadahalli",
              "value": "Sadahalli"
            },
            {
              "count": 1,
              "label": "Sampangi Ram Nagar",
              "value": "Sampangi Ram Nagar"
            },
            {
              "count": 3,
              "label": "Sarjapur Road",
              "value": "Sarjapur Road"
            },
            {
              "count": 16,
              "label": "Seshadripuram",
              "value": "Seshadripuram"
            },
            {
              "count": 1,
              "label": "Sheeshadripuram",
              "value": "Sheeshadripuram"
            },
            {
              "count": 1,
              "label": "Shivaji Nagar",
              "value": "Shivaji Nagar"
            },
            {
              "count": 2,
              "label": "St Marks Road",
              "value": "St Marks Road"
            },
            {
              "count": 1,
              "label": "Sudhama Nagar",
              "value": "Sudhama Nagar"
            },
            {
              "count": 1,
              "label": "Tavarekere",
              "value": "Tavarekere"
            },
            {
              "count": 2,
              "label": "Tumkur Road",
              "value": "Tumkur Road"
            },
            {
              "count": 10,
              "label": "Ulsoor",
              "value": "Ulsoor"
            },
            {
              "count": 28,
              "label": "Whitefield",
              "value": "Whitefield"
            },
            {
              "count": 1,
              "label": "Wilson Garden",
              "value": "Wilson Garden"
            },
            {
              "count": 10,
              "label": "Yelahanka",
              "value": "Yelahanka"
            },
            {
              "count": 24,
              "label": "Yeshwanthpur",
              "value": "Yeshwanthpur"
            }
          ],
          "filterName": "Location"
        },
        {
          "filterKey": "ex",
          "filterValues": [
            {
              "count": 78,
              "label": "Couple Friendly",
              "value": "Couple Friendly"
            },
            {
              "count": 249,
              "label": "Free Breakfast",
              "value": "Free Breakfast"
            },
            {
              "count": 644,
              "label": "Free Cancellation",
              "value": "Free Cancellation"
            },
            {
              "count": 370,
              "label": "Free WiFi",
              "value": "Free WiFi"
            },
            {
              "count": 225,
              "label": "Yatra Smart",
              "value": "Yatra Smart"
            }
          ],
          "filterName": "Hotels With"
        },
        {
          "filterKey": "pr",
          "filterValues": [
            {
              "count": 91,
              "label": "Less than Rs. 1,000",
              "value": "p1"
            },
            {
              "count": 275,
              "label": "Rs. 1,001 to  Rs. 2,000",
              "value": "p2"
            },
            {
              "count": 248,
              "label": "Rs. 2,001 to Rs. 4,000",
              "value": "p3"
            },
            {
              "count": 114,
              "label": "Rs. 4,001 to Rs. 7,000",
              "value": "p4"
            },
            {
              "count": 23,
              "label": "Rs. 7,001 to Rs. 10,000",
              "value": "p5"
            },
            {
              "count": 17,
              "label": "Greater than Rs. 10,001",
              "value": "p6"
            }
          ],
          "filterName": "Hotel price"
        },
        {
          "filterKey": "st",
          "filterValues": [
            {
              "count": 148,
              "label": "0",
              "value": "0"
            },
            {
              "count": 144,
              "label": "1",
              "value": "1"
            },
            {
              "count": 87,
              "label": "2",
              "value": "2"
            },
            {
              "count": 296,
              "label": "3",
              "value": "3"
            },
            {
              "count": 59,
              "label": "4",
              "value": "4"
            },
            {
              "count": 34,
              "label": "5",
              "value": "5"
            }
          ],
          "filterName": "Star Rating"
        },
        {
          "filterKey": "ta",
          "filterValues": [
            {
              "count": 7,
              "label": "1",
              "value": "1"
            },
            {
              "count": 14,
              "label": "2",
              "value": "2"
            },
            {
              "count": 83,
              "label": "3",
              "value": "3"
            },
            {
              "count": 246,
              "label": "4",
              "value": "4"
            },
            {
              "count": 179,
              "label": "5",
              "value": "5"
            }
          ],
          "filterName": "Trip Adviser Rating"
        },
        {
          "filterKey": "id",
          "filterValues": [
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.674,
                "la": 12.853,
                "az": "Electronic City"
              },
              "label": "Hotel Presidency-Electronic City",
              "value": "00125410"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.625009,
                "la": 13.157257,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Arna Hotel",
              "value": "00147385"
            },
            {
              "loc": {
                "a": "Old Airport Road",
                "c": "Bangalore",
                "lo": 77.644017,
                "la": 12.957145,
                "az": "Indira Nagar",
                "z": "Central Bangalore"
              },
              "label": "Hotel Royal Orchid, Bangalore",
              "value": "00000163"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.623564,
                "la": 12.93057,
                "az": "Koramangala"
              },
              "label": "Hotel Wafi Suites",
              "value": "00020162"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.633648,
                "la": 13.188065,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Royal Lotus View Resotel",
              "value": "00152554"
            },
            {
              "loc": {
                "a": "Race Course Road",
                "c": "Bangalore",
                "lo": 77.577756,
                "la": 12.977517,
                "az": "Gandhi Nagar",
                "z": "West Bangalore"
              },
              "label": "Hotel Basant Residency",
              "value": "00007253"
            },
            {
              "loc": {
                "a": "R T Nagar",
                "c": "Bangalore",
                "lo": 77.593469,
                "la": 13.006283,
                "az": "Hebbal"
              },
              "label": "Atlaantic Inn",
              "value": "00031050"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.576583,
                "la": 12.980236,
                "az": "Gandhi Nagar"
              },
              "label": "The Rialto Hotel",
              "value": "00034481"
            },
            {
              "loc": {
                "a": "Brookefield",
                "c": "Bangalore",
                "lo": 77.716563,
                "la": 12.964899,
                "az": "Whitefield"
              },
              "label": "De Venetian by TGI",
              "value": "00151536"
            },
            {
              "loc": {
                "a": "Domlur",
                "c": "Bangalore",
                "lo": 77.648586,
                "la": 12.959219,
                "az": "Indira Nagar",
                "z": "East Bangalore"
              },
              "label": "Sterlings Mac Hotel",
              "value": "00008767"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 74.860453,
                "la": 31.657604,
                "az": "Indira Nagar",
                "z": "Central Bangalore"
              },
              "label": "bloom Boutique l Indiranagar",
              "value": "00007077"
            },
            {
              "loc": {
                "a": "Airport Road",
                "c": "Bangalore",
                "lo": 77.588,
                "la": 13.036
              },
              "label": "Kanaka Grand Hotel & Spa",
              "value": "00177387"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.629477,
                "la": 12.934439,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "Hotel Silicrest",
              "value": "00005382"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.6,
                "la": 13.04,
                "az": "Hebbal"
              },
              "label": "Nandu Hospitality - Matoshri",
              "value": "00102228"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.57,
                "la": 12.97,
                "az": "Gandhi Nagar"
              },
              "label": "The Palladium by Bigtree Hotels",
              "value": "00177137"
            },
            {
              "loc": {
                "a": "Domlur",
                "c": "Bangalore",
                "lo": 77.639918,
                "la": 12.952691,
                "az": "Indira Nagar"
              },
              "label": "Hotel 12 Degrees West EGL",
              "value": "00154512"
            },
            {
              "loc": {
                "a": "Malleshwaram",
                "c": "Bangalore",
                "lo": 77.571354,
                "la": 12.993664,
                "az": "Yeshwanthpur",
                "z": "North Bangalore"
              },
              "label": "bloom Boutique l Malleshwaram",
              "value": "00007154"
            },
            {
              "loc": {
                "a": "Hosur Main Road",
                "c": "Bangalore",
                "lo": 77.659205,
                "la": 12.839268,
                "az": "Electronic City",
                "z": "South Bangalore"
              },
              "label": "Svenska Electronic City Bangalore",
              "value": "00005960"
            },
            {
              "loc": {
                "a": "Residency Road",
                "c": "Bangalore",
                "lo": 77.60055,
                "la": 12.967429,
                "az": "M G Road"
              },
              "label": "Orchid Suites",
              "value": "00073979"
            },
            {
              "loc": {
                "a": "Race Course Road",
                "c": "Bangalore",
                "lo": 77.585012,
                "la": 12.984427,
                "az": "Gandhi Nagar",
                "z": "West Bangalore"
              },
              "label": "Taj West End Bengaluru",
              "value": "00001757"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.540708,
                "la": 13.029138,
                "az": "Yeshwanthpur",
                "z": "North Bangalore"
              },
              "label": "Taj Yeshwantpur, Bengaluru",
              "value": "00006517"
            },
            {
              "loc": {
                "a": "Devanahalli",
                "c": "Bangalore",
                "lo": 77.619881,
                "la": 12.973238,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Taj Bangalore",
              "value": "00061977"
            },
            {
              "loc": {
                "a": "Bannerghatta",
                "c": "Bangalore",
                "lo": 77.5485,
                "la": 12.94709
              },
              "label": "Grand Continent Hotel - Bannerghatta Road",
              "value": "00177381"
            },
            {
              "loc": {
                "a": "Brookefield",
                "c": "Bangalore",
                "lo": 77.709767,
                "la": 12.963012,
                "az": "Whitefield"
              },
              "label": "The Continentti Brookefield",
              "value": "00157186"
            },
            {
              "loc": {
                "a": "Kadubisannahalli",
                "c": "Bangalore",
                "lo": 77.685641,
                "la": 12.929909,
                "az": "Marathahalli"
              },
              "label": "Bhagini Icon Premier Hotel",
              "value": "00087261"
            },
            {
              "loc": {
                "a": "Residency Road",
                "c": "Bangalore",
                "lo": 77.598694,
                "la": 12.966027,
                "az": "M G Road",
                "z": "South Bangalore"
              },
              "label": "The Chancery Pavilion",
              "value": "00001366"
            },
            {
              "loc": {
                "a": "Devanahalli",
                "c": "Bangalore",
                "lo": 77.62608,
                "la": 13.15797,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Arra Transit Bengaluru International Airport Hotel",
              "value": "00147641"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.620333,
                "la": 12.921888,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "Davanam Sarovar Portico Suites - A Sarovar Hotel",
              "value": "00008235"
            },
            {
              "loc": {
                "a": "M G Road",
                "c": "Bangalore",
                "lo": 77.596583,
                "la": 12.972003,
                "az": "M G Road",
                "z": "Central Bangalore"
              },
              "label": "Oakwood Premier Prestige Bangalore",
              "value": "00005285"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.61971,
                "la": 13.148062,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Hotel Airport Gateway",
              "value": "00017440"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.631573,
                "la": 13.163814,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Silicon Inn",
              "value": "00118397"
            },
            {
              "loc": {
                "a": "Domlur",
                "c": "Bangalore",
                "lo": 77.641107,
                "la": 12.955424,
                "az": "Indira Nagar"
              },
              "label": "Ramada Encore Bangalore Domlur",
              "value": "00017090"
            },
            {
              "loc": {
                "a": "Domlur",
                "c": "Bangalore",
                "lo": 77.631569,
                "la": 12.968469,
                "az": "Indira Nagar"
              },
              "label": "Apollo Greens Serviced Apartment",
              "value": "00019825"
            },
            {
              "loc": {
                "a": "Basaveshwara Nagar",
                "c": "Bangalore",
                "lo": 77.555,
                "la": 13.01257
              },
              "label": "Shoba Elite",
              "value": "00113120"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.575558,
                "la": 12.973898,
                "z": "West Bangalore"
              },
              "label": "Hotel Swagath",
              "value": "00001778"
            },
            {
              "loc": {
                "a": "Jayanagar",
                "c": "Bangalore",
                "lo": 77.58538,
                "la": 12.930599,
                "az": "Jayanagar",
                "z": "South Bangalore"
              },
              "label": "The Royal Comfort",
              "value": "00001015"
            },
            {
              "loc": {
                "a": "Minerva Circle",
                "c": "Bangalore",
                "lo": 77.583453,
                "la": 12.956667,
                "az": "Jayanagar",
                "z": "South Bangalore"
              },
              "label": "Springs Hotel & Spa",
              "value": "00009965"
            },
            {
              "loc": {
                "a": "J P Nagar",
                "c": "Bangalore",
                "lo": 77.59873,
                "la": 12.892977
              },
              "label": "Hotel Euphoria",
              "value": "00071368"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.690168,
                "la": 13.197912,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Orange Suites & Inn Bangalore Airport",
              "value": "00029093"
            },
            {
              "loc": {
                "a": "Domlur",
                "c": "Bangalore",
                "lo": 77.638308,
                "la": 12.954015,
                "az": "Indira Nagar"
              },
              "label": "The Olive Suites",
              "value": "00011949"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.641566,
                "la": 13.183227,
                "az": "Bengaluru International Airport Road"
              },
              "label": "HouseFinch Residency",
              "value": "00068741"
            },
            {
              "loc": {
                "a": "Hosur Main Road",
                "c": "Bangalore",
                "lo": 77.712377,
                "la": 12.800697
              },
              "label": "TS Royal Grand - Attibele",
              "value": "00122640"
            },
            {
              "loc": {
                "a": "Minerva Circle",
                "c": "Bangalore",
                "lo": 77.555012,
                "la": 12.919753,
                "az": "Jayanagar",
                "z": "South Bangalore"
              },
              "label": "Raaj Residency",
              "value": "00001016"
            },
            {
              "loc": {
                "a": "J P Nagar",
                "c": "Bangalore",
                "lo": 77.598947,
                "la": 12.914691
              },
              "label": "The Ambient Turret",
              "value": "00011038"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.63311,
                "la": 12.932026,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "The Bouvice",
              "value": "00003864"
            },
            {
              "loc": {
                "a": "Domlur",
                "c": "Bangalore",
                "lo": 77.643464,
                "la": 12.955151,
                "az": "Indira Nagar"
              },
              "label": "Mak Hotel",
              "value": "00020466"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.578454,
                "la": 12.976431,
                "az": "Gandhi Nagar"
              },
              "label": "Hotel Sovereign Grand",
              "value": "00011007"
            },
            {
              "loc": {
                "a": "Jakkur",
                "c": "Bangalore",
                "lo": 77.5967,
                "la": 13.0688,
                "az": "Bengaluru International Airport Road"
              },
              "label": "White Castle",
              "value": "00117861"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.586008,
                "la": 12.897912,
                "az": "Hebbal"
              },
              "label": "Shoba Tulip",
              "value": "00082685"
            },
            {
              "loc": {
                "a": "Kalyan Nagar",
                "c": "Bangalore",
                "lo": 77.631259,
                "la": 13.025201,
                "az": "Hebbal"
              },
              "label": "Shoba Residency",
              "value": "00059813"
            },
            {
              "loc": {
                "a": "Bellandur",
                "c": "Bangalore",
                "lo": 77.698077,
                "la": 12.942469,
                "az": "Marathahalli"
              },
              "label": "Hotel Highsky (Outer Ring Road)",
              "value": "00012864"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.585764,
                "la": 12.967658
              },
              "label": "Hotel VT Orchid",
              "value": "00014518"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.631713,
                "la": 13.163774,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Orange Corner",
              "value": "00146640"
            },
            {
              "loc": {
                "a": "Kammanahalli",
                "c": "Bangalore",
                "lo": 77.641325,
                "la": 13.020981,
                "az": "Hebbal"
              },
              "label": "ShobaEnclave",
              "value": "00080863"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.570505,
                "la": 12.975012,
                "z": "West Bangalore"
              },
              "label": "Hotel City Centaur",
              "value": "00004114"
            },
            {
              "loc": {
                "a": "Kammanahalli",
                "c": "Bangalore",
                "lo": 77.64131,
                "la": 13.021231,
                "az": "Hebbal"
              },
              "label": "Shoba Suites",
              "value": "00014517"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.576969,
                "la": 12.977976,
                "az": "Gandhi Nagar"
              },
              "label": "Sri Trupthi Comforts",
              "value": "00020674"
            },
            {
              "loc": {
                "a": "Hennur",
                "c": "Bangalore",
                "lo": 77.638326,
                "la": 13.022457,
                "az": "Hebbal"
              },
              "label": "Shoba Inn",
              "value": "00014292"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.55,
                "la": 12.93,
                "az": "Yeshwanthpur"
              },
              "label": "Caramel Hotels",
              "value": "00111892"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.589438,
                "la": 13.036466,
                "az": "Hebbal",
                "z": "North Bangalore"
              },
              "label": "The Royale Senate Hebbal",
              "value": "00004739"
            },
            {
              "loc": {
                "a": "Mysore Road",
                "c": "Bangalore",
                "lo": 77.544999,
                "la": 12.952981,
                "az": "Outskirts"
              },
              "label": "Rosewood International Hotel",
              "value": "00057639"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.57922,
                "la": 12.973514,
                "az": "Gandhi Nagar",
                "z": "South Bangalore"
              },
              "label": "Hotel Bangalore Gate",
              "value": "00001092"
            },
            {
              "loc": {
                "a": "Race Course Road",
                "c": "Bangalore",
                "lo": 77.587675,
                "la": 12.984703,
                "az": "Gandhi Nagar",
                "z": "Central Bangalore"
              },
              "label": "Hotel Chalukya",
              "value": "00001842"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.544948,
                "la": 13.028613,
                "az": "Yeshwanthpur"
              },
              "label": "Hotel Venkat Presidency",
              "value": "00017335"
            },
            {
              "loc": {
                "a": "Mahadevapura Post",
                "c": "Bangalore",
                "lo": 77.694663,
                "la": 12.978978,
                "az": "Marathahalli"
              },
              "label": "Sarovar Portico Outer Ring Road Bengaluru",
              "value": "00078874"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.579377,
                "la": 12.978079,
                "az": "Gandhi Nagar",
                "z": "West Bangalore"
              },
              "label": "Golden Residency",
              "value": "00003678"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.574795,
                "la": 12.979248,
                "az": "Gandhi Nagar",
                "z": "West Bangalore"
              },
              "label": "JP Cordial",
              "value": "00001132"
            },
            {
              "loc": {
                "a": "Race Course Road",
                "c": "Bangalore",
                "lo": 77.579122,
                "la": 12.98539,
                "az": "Gandhi Nagar"
              },
              "label": "The Royale Senate Race Course",
              "value": "00087138"
            },
            {
              "loc": {
                "a": "M G Road",
                "c": "Bangalore",
                "lo": 77.615425,
                "la": 12.974849,
                "az": "M G Road",
                "z": "South Bangalore"
              },
              "label": "Royal Orchid Central Bangalore",
              "value": "00000706"
            },
            {
              "loc": {
                "a": "Bannerghatta Road",
                "c": "Bangalore",
                "lo": 77.5983,
                "la": 12.928362,
                "az": "Koramangala"
              },
              "label": "Hotel Viva",
              "value": "00081143"
            },
            {
              "loc": {
                "a": "Race Course Road",
                "c": "Bangalore",
                "lo": 77.57622,
                "la": 12.978372,
                "az": "Gandhi Nagar"
              },
              "label": "HLV Grand Inn",
              "value": "00103382"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.620112,
                "la": 12.944559,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "Hotel Ganga Sagar(Koramangala)",
              "value": "00002608"
            },
            {
              "loc": {
                "a": "Gottigere",
                "c": "Bangalore",
                "lo": 0,
                "la": 0
              },
              "label": "Flamingos The Service Apartment",
              "value": "00174739"
            },
            {
              "loc": {
                "a": "Richmond Road",
                "c": "Bangalore",
                "lo": 77.598355,
                "la": 12.964318,
                "az": "M G Road",
                "z": "Central Bangalore"
              },
              "label": "Adarsh Hamilton",
              "value": "00005472"
            },
            {
              "loc": {
                "a": "J P Nagar",
                "c": "Bangalore",
                "lo": 77.585853,
                "la": 12.908625,
                "z": "South Bangalore"
              },
              "label": "Cross Roads Inn",
              "value": "00001064"
            },
            {
              "loc": {
                "a": "Brigade Road",
                "c": "Bangalore",
                "lo": 77.609023,
                "la": 12.970271,
                "az": "M G Road"
              },
              "label": "The Chevron Brigade",
              "value": "00047325"
            },
            {
              "loc": {
                "a": "Krishnarajapuram",
                "c": "Bangalore",
                "lo": 77.70993,
                "la": 13.022592
              },
              "label": "Y N Hotels",
              "value": "00117452"
            },
            {
              "loc": {
                "a": "Hsr Layout",
                "c": "Bangalore",
                "lo": 77.653954,
                "la": 12.919381,
                "az": "Koramangala"
              },
              "label": "Serene Boutique Hotel",
              "value": "00073875"
            },
            {
              "loc": {
                "a": "Cunningham Road",
                "c": "Bangalore",
                "lo": 77.600729,
                "la": 12.98414,
                "az": "M G Road",
                "z": "Central Bangalore"
              },
              "label": "Regenta Place",
              "value": "00000165"
            },
            {
              "loc": {
                "a": "Outer Ring Road",
                "c": "Bangalore",
                "lo": 77.688009,
                "la": 12.990964,
                "az": "Marathahalli"
              },
              "label": "The Iris Inn By Bhagini",
              "value": "00012869"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.55,
                "la": 13.02,
                "az": "Yeshwanthpur"
              },
              "label": "The Royal Comfort",
              "value": "00104713"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.646248,
                "la": 12.879766,
                "az": "Electronic City",
                "z": "South Bangalore"
              },
              "label": "Keys Select Hosur Road - By Lemon Tree Hotels",
              "value": "00005183"
            },
            {
              "loc": {
                "a": "Jayanagar",
                "c": "Bangalore",
                "lo": 77.589341,
                "la": 12.918127,
                "az": "Jayanagar"
              },
              "label": "Nagananda Residency",
              "value": "00101781"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.621629,
                "la": 12.936036,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "Nandhana Grand",
              "value": "00001095"
            },
            {
              "loc": {
                "a": "Hosur Main Road",
                "c": "Bangalore",
                "lo": 77.661692,
                "la": 12.836745,
                "az": "Electronic City",
                "z": "South Bangalore"
              },
              "label": "Radha Regent",
              "value": "00005872"
            },
            {
              "loc": {
                "a": "Infantry Road",
                "c": "Bangalore",
                "lo": 77.594431,
                "la": 12.982199,
                "az": "M G Road",
                "z": "South Bangalore"
              },
              "label": "The Capitol",
              "value": "00000227"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.69,
                "la": 12.81,
                "az": "Electronic City"
              },
              "label": "Online Suites",
              "value": "00104714"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.717497,
                "la": 12.97161,
                "az": "Whitefield",
                "z": "East Bangalore"
              },
              "label": "MGM Mark Whitefield Hotel",
              "value": "00003827"
            },
            {
              "loc": {
                "a": "Richmond Road",
                "c": "Bangalore",
                "lo": 77.59485,
                "la": 12.96619,
                "az": "M G Road",
                "z": "Central Bangalore"
              },
              "label": "Hotel Ramanashree Richmond Circle",
              "value": "00001080"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.576919,
                "la": 12.980218,
                "az": "Gandhi Nagar"
              },
              "label": "IV Sanctum Hotel",
              "value": "00085110"
            },
            {
              "loc": {
                "a": "Lavelle Road",
                "c": "Bangalore",
                "lo": 77.599435,
                "la": 12.974772,
                "az": "M G Road",
                "z": "Central Bangalore"
              },
              "label": "Southern Star",
              "value": "00001278"
            },
            {
              "loc": {
                "a": "Marathahalli",
                "c": "Bangalore",
                "lo": 77.714156,
                "la": 12.955866,
                "az": "Marathahalli"
              },
              "label": "Bhagini Icon",
              "value": "00083861"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.663878,
                "la": 12.980106,
                "az": "Indira Nagar"
              },
              "label": "Silicon Hearth",
              "value": "00021819"
            },
            {
              "loc": {
                "a": "J P Nagar",
                "c": "Bangalore",
                "lo": 77.57868,
                "la": 12.911223
              },
              "label": "Fountain Tree By TGI",
              "value": "00115926"
            },
            {
              "loc": {
                "a": "Jayanagar",
                "c": "Bangalore",
                "lo": 77.583281,
                "la": 12.933274,
                "az": "Jayanagar",
                "z": "South Bangalore"
              },
              "label": "The President Hotel",
              "value": "00001030"
            },
            {
              "loc": {
                "a": "Airport Road",
                "c": "Bangalore",
                "lo": 77.591847,
                "la": 13.076042
              },
              "label": "Liwa - The Transit Hotel, Bengaluru",
              "value": "00020601"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.546616,
                "la": 12.936453,
                "az": "Koramangala"
              },
              "label": "SS Lumina Hotel",
              "value": "00117545"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.624914,
                "la": 13.038905,
                "az": "Hebbal"
              },
              "label": "Raj Elegance",
              "value": "00102434"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.622219,
                "la": 12.936356,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "Casa De Bengaluru",
              "value": "00003985"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.663465,
                "la": 12.840108,
                "az": "Electronic City"
              },
              "label": "Vinaya Royal Inn",
              "value": "00029532"
            },
            {
              "loc": {
                "a": "Jalahalli",
                "c": "Bangalore",
                "lo": 77.525731,
                "la": 13.044834,
                "az": "Yeshwanthpur"
              },
              "label": "Supreme Boutique Hotel",
              "value": "00145301"
            },
            {
              "loc": {
                "a": "Hosur Main Road",
                "c": "Bangalore",
                "lo": 77.757182,
                "la": 12.783998,
                "az": "Electronic City",
                "z": "South Bangalore"
              },
              "label": "La Classic",
              "value": "00006798"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.633867,
                "la": 13.206806,
                "az": "Bengaluru International Airport Road",
                "z": "North Bangalore"
              },
              "label": "Clarks Exotica Convention Resort & Spa",
              "value": "00003716"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.65915,
                "la": 12.821718,
                "az": "Electronic City"
              },
              "label": "Starlit Suites Smondo",
              "value": "00020724"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.637483,
                "la": 12.979282,
                "az": "Indira Nagar",
                "z": "Central Bangalore"
              },
              "label": "City Centre Residency",
              "value": "00005484"
            },
            {
              "loc": {
                "a": "Sampangi Ram Nagar",
                "c": "Bangalore",
                "lo": 77.595298,
                "la": 12.965729,
                "z": "Central Bangalore"
              },
              "label": "Woodlands Hotel",
              "value": "00002076"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.573788,
                "la": 12.988821,
                "az": "Yeshwanthpur",
                "z": "Central Bangalore"
              },
              "label": "Hotel Trinity Isle",
              "value": "00004793"
            },
            {
              "loc": {
                "a": "Hosur Main Road",
                "c": "Bangalore",
                "lo": 77.74342,
                "la": 12.78542,
                "az": "Electronic City",
                "z": "South Bangalore"
              },
              "label": "Ramee Guestline Hotel",
              "value": "00004100"
            },
            {
              "loc": {
                "a": "Richmond Road",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "M G Road"
              },
              "label": "Langford Keys by TGI",
              "value": "00156891"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.575418,
                "la": 12.979648
              },
              "label": "Hotel RR International",
              "value": "00082930"
            },
            {
              "loc": {
                "a": "Jayanagar",
                "c": "Bangalore",
                "lo": 77.586094,
                "la": 12.93939,
                "az": "Jayanagar"
              },
              "label": "Lords Eco inn Jayanagar",
              "value": "00070561"
            },
            {
              "loc": {
                "a": "Manyata Tech Park",
                "c": "Bangalore",
                "lo": 77.624386,
                "la": 13.058569
              },
              "label": "Transit Manyata By Staytrendz",
              "value": "00177636"
            },
            {
              "loc": {
                "a": "Jayanagar",
                "c": "Bangalore",
                "lo": 77.583694,
                "la": 12.935943,
                "az": "Jayanagar",
                "z": "South Bangalore"
              },
              "label": "Pai Viceroy Jayanagar",
              "value": "00001428"
            },
            {
              "loc": {
                "a": "Mathikere",
                "c": "Bangalore",
                "lo": 77.573003,
                "la": 13.028593,
                "az": "Yeshwanthpur"
              },
              "label": "White Feather Hotel",
              "value": "00071360"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.664438,
                "la": 12.843855,
                "az": "Electronic City"
              },
              "label": "Rest Inn SKR",
              "value": "00152553"
            },
            {
              "loc": {
                "a": "R T Nagar",
                "c": "Bangalore",
                "lo": 77.594044,
                "la": 13.028794,
                "az": "Hebbal"
              },
              "label": "The Sai Leela Suites",
              "value": "00046691"
            },
            {
              "loc": {
                "a": "Bellandur",
                "c": "Bangalore",
                "lo": 77.697426,
                "la": 12.942276,
                "az": "Marathahalli"
              },
              "label": "Octave Hotel & Spa, Marathahalli",
              "value": "00037544"
            },
            {
              "loc": {
                "a": "Bellandur",
                "c": "Bangalore",
                "lo": 77.663774,
                "la": 12.921212,
                "az": "Marathahalli",
                "z": "South Bangalore"
              },
              "label": "Hotel Enzo International",
              "value": "00004041"
            },
            {
              "loc": {
                "a": "High Grounds",
                "c": "Bangalore",
                "lo": 77.580811,
                "la": 12.984984,
                "az": "Gandhi Nagar",
                "z": "Central Bangalore"
              },
              "label": "37th Crescent Hotel Bangalore",
              "value": "00001458"
            },
            {
              "loc": {
                "a": "Hsr Layout",
                "c": "Bangalore",
                "lo": 77.603942,
                "la": 12.905069,
                "az": "Koramangala"
              },
              "label": "Maple Suites",
              "value": "00011081"
            },
            {
              "loc": {
                "a": "Hsr Layout",
                "c": "Bangalore",
                "lo": 77.63538,
                "la": 12.91321,
                "az": "Koramangala"
              },
              "label": "Bluemoon Loginn",
              "value": "00011049"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.610315,
                "la": 12.934033,
                "az": "Koramangala"
              },
              "label": "Comfy Business Hotel",
              "value": "00046959"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.625386,
                "la": 12.937556,
                "az": "Koramangala"
              },
              "label": "Bluemoon Comforts",
              "value": "00011074"
            },
            {
              "loc": {
                "a": "B T M Layout",
                "c": "Bangalore",
                "lo": 77.60892,
                "la": 12.917266,
                "az": "Koramangala"
              },
              "label": "Aiyara Comforts",
              "value": "00144745"
            },
            {
              "loc": {
                "a": "Race Course Road",
                "c": "Bangalore",
                "lo": 77.576764,
                "la": 12.980889,
                "az": "Gandhi Nagar",
                "z": "West Bangalore"
              },
              "label": "Hotel Maurya",
              "value": "00004388"
            },
            {
              "loc": {
                "a": "Yelahanka",
                "c": "Bangalore",
                "lo": 77.588098,
                "la": 13.097015,
                "az": "Bengaluru International Airport Road"
              },
              "label": "The Verda Prakyathi",
              "value": "00075366"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.573199,
                "la": 12.920689,
                "z": "Central Bangalore"
              },
              "label": "Pai Vista Hotel",
              "value": "00007977"
            },
            {
              "loc": {
                "a": "Bommasandra Industrial Area",
                "c": "Bangalore",
                "lo": 77.698085,
                "la": 12.806733,
                "az": "Electronic City"
              },
              "label": "SRT Alpines",
              "value": "00019849"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.682765,
                "la": 12.847823,
                "az": "Electronic City"
              },
              "label": "SAP Golden Grande",
              "value": "00102602"
            },
            {
              "loc": {
                "a": "Frazer Town",
                "c": "Bangalore",
                "lo": 77.61315,
                "la": 12.998282,
                "az": "M G Road"
              },
              "label": "Grand Savoury Suites",
              "value": "00054623"
            },
            {
              "loc": {
                "a": "Tumkur Road",
                "c": "Bangalore",
                "lo": 77.445072,
                "la": 13.089135,
                "az": "Yeshwanthpur",
                "z": "North Bangalore"
              },
              "label": "The Golden Palms Hotel & Spa",
              "value": "00000246"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.572134,
                "la": 12.996781,
                "az": "Electronic City"
              },
              "label": "Southend By TGI",
              "value": "00136795"
            },
            {
              "loc": {
                "a": "Lavelle Road",
                "c": "Bangalore",
                "lo": 77.593255,
                "la": 12.96868,
                "az": "M G Road"
              },
              "label": "The Bougain Villa",
              "value": "00126105"
            },
            {
              "loc": {
                "a": "Kempe Gowda Road",
                "c": "Bangalore",
                "lo": 77.650383,
                "la": 13.177702
              },
              "label": "Airport Regency",
              "value": "00149103"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.570639,
                "la": 12.97314
              },
              "label": "The Signature Inn",
              "value": "00017612"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.709475,
                "la": 13.200342,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Tranzotel Bangalore Airport",
              "value": "00083476"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.698492,
                "la": 12.995308,
                "az": "Whitefield"
              },
              "label": "Park Inn Hospitality",
              "value": "00020631"
            },
            {
              "loc": {
                "a": "Sheeshadripuram",
                "c": "Bangalore",
                "lo": 77.57454,
                "la": 12.98904,
                "az": "Yeshwanthpur",
                "z": "Central Bangalore"
              },
              "label": "Magaji Orchid",
              "value": "00003956"
            },
            {
              "loc": {
                "a": "Bannerghatta",
                "c": "Bangalore",
                "lo": 77.60003,
                "la": 12.91673
              },
              "label": "Hotel Monarch By Rivido",
              "value": "00152550"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.928284,
                "la": 12.985555,
                "az": "Electronic City"
              },
              "label": "RG Hotels And Resort",
              "value": "00102340"
            },
            {
              "loc": {
                "a": "Manyata Tech Park",
                "c": "Bangalore",
                "lo": 77.620157,
                "la": 13.040544
              },
              "label": "X by bloom l Manyata",
              "value": "00156787"
            },
            {
              "loc": {
                "a": "J P Nagar",
                "c": "Bangalore",
                "lo": 77.591519,
                "la": 12.916679
              },
              "label": "WOODYS",
              "value": "00020813"
            },
            {
              "loc": {
                "a": "New Tippasandra",
                "c": "Bangalore",
                "lo": 77.651865,
                "la": 12.974665
              },
              "label": "Bluemoon Grand",
              "value": "00011050"
            },
            {
              "loc": {
                "a": "Domlur",
                "c": "Bangalore",
                "lo": 77.640048,
                "la": 12.956608,
                "az": "Indira Nagar"
              },
              "label": "Golf Inn",
              "value": "00011189"
            },
            {
              "loc": {
                "a": "Wilson Garden",
                "c": "Bangalore",
                "lo": 77.59649,
                "la": 12.944567
              },
              "label": "The Porch Inn",
              "value": "00174790"
            },
            {
              "loc": {
                "a": "Double Road",
                "c": "Bangalore",
                "lo": 77.592332,
                "la": 12.956552,
                "az": "Jayanagar",
                "z": "Central Bangalore"
              },
              "label": "Deva Residency",
              "value": "00001089"
            },
            {
              "loc": {
                "a": "J P Nagar",
                "c": "Bangalore",
                "lo": 77.583554,
                "la": 12.9056,
                "z": "South Bangalore"
              },
              "label": "Hotel Nandhini (J.P.Nagar)",
              "value": "00004048"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.581133,
                "la": 12.971608
              },
              "label": "Shri Kamal Hotel",
              "value": "00014284"
            },
            {
              "loc": {
                "a": "Kodihalli",
                "c": "Bangalore",
                "lo": 77.651305,
                "la": 12.955882,
                "az": "Indira Nagar",
                "z": "Central Bangalore"
              },
              "label": "Raj Comfort ( Off Airport Road)",
              "value": "00002375"
            },
            {
              "loc": {
                "a": "B T M Layout",
                "c": "Bangalore",
                "lo": 77.610145,
                "la": 12.932866,
                "az": "Koramangala"
              },
              "label": "Hotel Palm Suite",
              "value": "00088645"
            },
            {
              "loc": {
                "a": "Cunningham Road",
                "c": "Bangalore",
                "lo": 77.595,
                "la": 12.990167
              },
              "label": "bloomrooms @ Cunningham Road",
              "value": "00177171"
            },
            {
              "loc": {
                "a": "Jayanagar",
                "c": "Bangalore",
                "lo": 77.581148,
                "la": 12.930524,
                "az": "Jayanagar"
              },
              "label": "Alcott Hotel & Resorts",
              "value": "00136678"
            },
            {
              "loc": {
                "a": "Ramamurthy Nagar",
                "c": "Bangalore",
                "lo": 77.665568,
                "la": 13.012483,
                "az": "Hebbal"
              },
              "label": "Hotel The Shack",
              "value": "00136797"
            },
            {
              "loc": {
                "a": "Marathahalli",
                "c": "Bangalore",
                "lo": 77.632506,
                "la": 12.932705,
                "az": "Marathahalli",
                "z": "East Bangalore"
              },
              "label": "Nandu Guest House Marathalli",
              "value": "00010336"
            },
            {
              "loc": {
                "a": "Mysore Road",
                "c": "Bangalore",
                "lo": 77.399112,
                "la": 12.79857,
                "az": "Outskirts"
              },
              "label": "S A B Residency",
              "value": "00144872"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.609948,
                "la": 12.932752,
                "az": "Koramangala"
              },
              "label": "Hotel Fa",
              "value": "00085117"
            },
            {
              "loc": {
                "a": "Kammanahalli",
                "c": "Bangalore",
                "lo": 77.662723,
                "la": 13.002181,
                "az": "Hebbal"
              },
              "label": "Mayflower Bluebell",
              "value": "00083483"
            },
            {
              "loc": {
                "a": "Brookefield",
                "c": "Bangalore",
                "lo": 77.717598,
                "la": 12.964775,
                "az": "Whitefield"
              },
              "label": "Eyrie Hospitality",
              "value": "00075826"
            },
            {
              "loc": {
                "a": "J P Nagar",
                "c": "Bangalore",
                "lo": 77.594005,
                "la": 12.904633
              },
              "label": "Hotel Catalyst Suites",
              "value": "00147508"
            },
            {
              "loc": {
                "a": "Raj Bhavan Road",
                "c": "Bangalore",
                "lo": 77.594458,
                "la": 12.982567,
                "az": "M G Road",
                "z": "South Bangalore"
              },
              "label": "Hotel Paraag",
              "value": "00006144"
            },
            {
              "loc": {
                "a": "Jayanagar",
                "c": "Bangalore",
                "lo": 77.58945,
                "la": 12.922979,
                "az": "Jayanagar"
              },
              "label": "Pratik Comforts",
              "value": "00020786"
            },
            {
              "loc": {
                "a": "Double Road",
                "c": "Bangalore",
                "lo": 77.59836,
                "la": 12.948646,
                "az": "Jayanagar"
              },
              "label": "Hotel Sabharwal Inn",
              "value": "00020693"
            },
            {
              "loc": {
                "a": "Basavangudi",
                "c": "Bangalore",
                "lo": 77.571141,
                "la": 12.941343,
                "az": "Jayanagar",
                "z": "South Bangalore"
              },
              "label": "Shree Ganesh Regency",
              "value": "00005702"
            },
            {
              "loc": {
                "a": "Channasandra",
                "c": "Bangalore",
                "lo": 77.518612,
                "la": 12.902207
              },
              "label": "Hotel The Prince Royal",
              "value": "00085726"
            },
            {
              "loc": {
                "a": "J P Nagar",
                "c": "Bangalore",
                "lo": 77.578497,
                "la": 12.906198,
                "z": "South Bangalore"
              },
              "label": "Aurick Hotel",
              "value": "00008671"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.574431,
                "la": 12.972939,
                "az": "Whitefield"
              },
              "label": "Adi Hospitality",
              "value": "00030372"
            },
            {
              "loc": {
                "a": "Minerva Circle",
                "c": "Bangalore",
                "lo": 77.579941,
                "la": 12.950812,
                "az": "Jayanagar",
                "z": "South Bangalore"
              },
              "label": "Akshaya Lakshmi Comfort",
              "value": "00009607"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.95184,
                "la": 13.13287,
                "az": "Outskirts",
                "z": "East Bangalore"
              },
              "label": "Golden Amoon Resorts & Retreats",
              "value": "00006240"
            },
            {
              "loc": {
                "a": "Kammanahalli",
                "c": "Bangalore",
                "lo": 77.61315,
                "la": 12.9983,
                "az": "Hebbal"
              },
              "label": "Grand Savoury Boutique Hotel",
              "value": "00147522"
            },
            {
              "loc": {
                "a": "Balepet",
                "c": "Bangalore",
                "lo": 77.574677,
                "la": 12.971577,
                "z": "West Bangalore"
              },
              "label": "Shrusti Comfort",
              "value": "00005892"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.661892,
                "la": 12.989572,
                "az": "Indira Nagar"
              },
              "label": "Silicon Hearth BANGALORE",
              "value": "00021827"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.629428,
                "la": 12.93263
              },
              "label": "Dass Suites",
              "value": "00011290"
            },
            {
              "loc": {
                "a": "Rajaji Nagar",
                "c": "Bangalore",
                "lo": 77.550579,
                "la": 12.993931,
                "az": "Yeshwanthpur"
              },
              "label": "Navya Residency",
              "value": "00020660"
            },
            {
              "loc": {
                "a": "Rajaji Nagar",
                "c": "Bangalore",
                "lo": 77.61,
                "la": 12.98,
                "az": "Yeshwanthpur"
              },
              "label": "Utse Suites-Bangalore",
              "value": "00098384"
            },
            {
              "loc": {
                "a": "Old Airport Road",
                "c": "Bangalore",
                "lo": 77.650723,
                "la": 12.955133,
                "az": "Indira Nagar"
              },
              "label": "Pearl Suites",
              "value": "00011368"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.555229,
                "la": 13.020782,
                "az": "Yeshwanthpur"
              },
              "label": "Nava Nidhi Comforts",
              "value": "00020672"
            },
            {
              "loc": {
                "a": "Cunningham Road",
                "c": "Bangalore",
                "lo": 77.594051,
                "la": 12.991328,
                "az": "M G Road",
                "z": "Central Bangalore"
              },
              "label": "Young Island Comforts",
              "value": "00003245"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.626831,
                "la": 12.937862,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "Hotel Gangothri",
              "value": "00002611"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.5695,
                "la": 12.9633
              },
              "label": "Hotel Holiday Home",
              "value": "00117449"
            },
            {
              "loc": {
                "a": "Jayanagar",
                "c": "Bangalore",
                "lo": 77.584834,
                "la": 12.943643,
                "az": "Jayanagar"
              },
              "label": "Sanman Gardenia",
              "value": "00013476"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.579668,
                "la": 12.972582,
                "z": "Central Bangalore"
              },
              "label": "Hotel TAP Paradise",
              "value": "00003394"
            },
            {
              "loc": {
                "a": "Seshadripuram",
                "c": "Bangalore",
                "lo": 77.572867,
                "la": 12.989329,
                "az": "Yeshwanthpur"
              },
              "label": "Hotel Samrat Residency",
              "value": "00010460"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.552978,
                "la": 13.022989,
                "az": "Yeshwanthpur",
                "z": "North Bangalore"
              },
              "label": "Veekay Residency",
              "value": "00005380"
            },
            {
              "loc": {
                "a": "Minerva Circle",
                "c": "Bangalore",
                "lo": 77.589697,
                "la": 12.965689,
                "az": "Jayanagar",
                "z": "South Bangalore"
              },
              "label": "Hotel VT Paradise",
              "value": "00001084"
            },
            {
              "loc": {
                "a": "Brigade Road",
                "c": "Bangalore",
                "lo": 77.60024,
                "la": 12.9706,
                "az": "M G Road"
              },
              "label": "Mango Hotels Purple Brigade",
              "value": "00117217"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.550487,
                "la": 13.010903,
                "az": "Yeshwanthpur"
              },
              "label": "Minla Hotel",
              "value": "00073491"
            },
            {
              "loc": {
                "a": "Hosur Main Road",
                "c": "Bangalore",
                "lo": 77.656778,
                "la": 12.852642,
                "az": "Electronic City"
              },
              "label": "FabHotel Astra Electronic City",
              "value": "00011532"
            },
            {
              "loc": {
                "a": "Yelahanka",
                "c": "Bangalore",
                "lo": 77.567593,
                "la": 13.154171,
                "az": "Bengaluru International Airport Road",
                "z": "North Bangalore"
              },
              "label": "The Sai Leela",
              "value": "00006386"
            },
            {
              "loc": {
                "a": "Cunningham Road",
                "c": "Bangalore",
                "lo": 77.594938,
                "la": 12.989446,
                "az": "M G Road",
                "z": "Central Bangalore"
              },
              "label": "Fortune Select JP Cosmos - Member ITC Hotel Group",
              "value": "00003661"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.592621,
                "la": 13.059662,
                "az": "Hebbal"
              },
              "label": "Nandhana Pride",
              "value": "00148455"
            },
            {
              "loc": {
                "a": "J P Nagar",
                "c": "Bangalore",
                "lo": 77.579311,
                "la": 12.910991,
                "z": "South Bangalore"
              },
              "label": "Prasidhi Stay Inn",
              "value": "00002728"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.571606,
                "la": 12.980672,
                "az": "Gandhi Nagar",
                "z": "West Bangalore"
              },
              "label": "Sheetal Residency",
              "value": "00008762"
            },
            {
              "loc": {
                "a": "Yelahanka",
                "c": "Bangalore",
                "lo": 77.591352,
                "la": 13.086595,
                "az": "Bengaluru International Airport Road",
                "z": "North Bangalore"
              },
              "label": "Royal Orchid Resort & Convention Centre",
              "value": "00000717"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.631343,
                "la": 12.935569,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "Halcyon",
              "value": "00007691"
            },
            {
              "loc": {
                "a": "Lavelle Road",
                "c": "Bangalore",
                "lo": 77.597502,
                "la": 12.975636,
                "az": "M G Road",
                "z": "Central Bangalore"
              },
              "label": "The Chancery",
              "value": "00000620"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.622849,
                "la": 12.931791,
                "az": "Koramangala"
              },
              "label": "Nandhana Regent",
              "value": "00087534"
            },
            {
              "loc": {
                "a": "Ulsoor",
                "c": "Bangalore",
                "lo": 77.616774,
                "la": 12.987364,
                "az": "M G Road",
                "z": "Central Bangalore"
              },
              "label": "Lemon Tree Premier, Ulsoor Lake, Bengaluru",
              "value": "00005454"
            },
            {
              "loc": {
                "a": "Richmond Road",
                "c": "Bangalore",
                "lo": 77.599677,
                "la": 12.96546,
                "az": "M G Road",
                "z": "Central Bangalore"
              },
              "label": "The Elanza Hotel",
              "value": "00001648"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.6419,
                "la": 12.962046,
                "az": "Indira Nagar",
                "z": "Central Bangalore"
              },
              "label": "NANDHANA HOMETEL",
              "value": "00005005"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.5927,
                "la": 13.0795,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Attide Hotel",
              "value": "00088563"
            },
            {
              "loc": {
                "a": "Sadahalli",
                "c": "Bangalore",
                "lo": 77.644871,
                "la": 13.190241
              },
              "label": "Purple Cloud Hotel",
              "value": "00136242"
            },
            {
              "loc": {
                "a": "Brigade Road",
                "c": "Bangalore",
                "lo": 77.606628,
                "la": 12.967409
              },
              "label": "Treebo Trend Stylotel By Jagdish",
              "value": "00061557"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.685295,
                "la": 13.34787,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Mount Palazzo",
              "value": "00020316"
            },
            {
              "loc": {
                "a": "Rajaji Nagar",
                "c": "Bangalore",
                "lo": 77.552746,
                "la": 12.987395,
                "az": "Yeshwanthpur"
              },
              "label": "Treebo Trip KES Residency",
              "value": "00154860"
            },
            {
              "loc": {
                "a": "Frazer Town",
                "c": "Bangalore",
                "lo": 77.614505,
                "la": 12.996879,
                "az": "M G Road"
              },
              "label": "Hotel Grand Savoury Fandhook",
              "value": "00136699"
            },
            {
              "loc": {
                "a": "Jayanagar",
                "c": "Bangalore",
                "lo": 77.593428,
                "la": 12.941418,
                "az": "Jayanagar"
              },
              "label": "Grand Empark",
              "value": "00102069"
            },
            {
              "loc": {
                "a": "Double Road",
                "c": "Bangalore",
                "lo": 77.599238,
                "la": 12.956952,
                "az": "Jayanagar"
              },
              "label": "Compact Langford Homes",
              "value": "00096476"
            },
            {
              "loc": {
                "a": "Brigade Road",
                "c": "Bangalore",
                "lo": 77.607004,
                "la": 12.970738,
                "az": "M G Road",
                "z": "East Bangalore"
              },
              "label": "Iris - The Business Hotel and Spa",
              "value": "00003843"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.66391,
                "la": 12.839816,
                "az": "Electronic City",
                "z": "South Bangalore"
              },
              "label": "Oyester Inn",
              "value": "00010082"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.626288,
                "la": 13.044658,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Howard Johnson Bengaluru Hebbal",
              "value": "00018206"
            },
            {
              "loc": {
                "a": "Bapuji Nagar",
                "c": "Bangalore",
                "lo": 77.57513,
                "la": 12.979682,
                "az": "Gandhi Nagar"
              },
              "label": "Hotel ABM International",
              "value": "00037979"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.64,
                "la": 12.84,
                "az": "Electronic City"
              },
              "label": "Hotel Royal Inn",
              "value": "00104387"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.615213,
                "la": 12.933478,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "Blupetal - A Business Hotel",
              "value": "00005209"
            },
            {
              "loc": {
                "a": "Brigade Road",
                "c": "Bangalore",
                "lo": 77.604582,
                "la": 12.972198,
                "az": "M G Road"
              },
              "label": "Oxford Inn - Business Hotel",
              "value": "00017523"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.619263,
                "la": 12.93909,
                "az": "Koramangala"
              },
              "label": "4 Seasons Suites",
              "value": "00024630"
            },
            {
              "loc": {
                "a": "Marathahalli",
                "c": "Bangalore",
                "lo": 77.699595,
                "la": 12.949004,
                "az": "Marathahalli"
              },
              "label": "Nandhana Comforts",
              "value": "00019635"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.637487,
                "la": 13.021441,
                "az": "Hebbal"
              },
              "label": "37th Crescent Boutique Suites",
              "value": "00123667"
            },
            {
              "loc": {
                "a": "Brigade Road",
                "c": "Bangalore",
                "lo": 77.607872,
                "la": 12.974256,
                "az": "M G Road",
                "z": "East Bangalore"
              },
              "label": "The Curzon Court",
              "value": "00005707"
            },
            {
              "loc": {
                "a": "Residency Road",
                "c": "Bangalore",
                "lo": 77.608545,
                "la": 12.971445,
                "az": "M G Road",
                "z": "South Bangalore"
              },
              "label": "Ballal Residency",
              "value": "00009646"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.581031,
                "la": 12.971764,
                "z": "South Bangalore"
              },
              "label": "Hotel Manasa Paradise",
              "value": "00005269"
            },
            {
              "loc": {
                "a": "Kammanahalli",
                "c": "Bangalore",
                "lo": 77.600207,
                "la": 12.975545,
                "az": "Hebbal",
                "z": "North Bangalore"
              },
              "label": "Nandhana Vista",
              "value": "00003382"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.577305,
                "la": 12.977029
              },
              "label": "Hotel Sangam Royal",
              "value": "00030985"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.635635,
                "la": 12.975397,
                "az": "Indira Nagar",
                "z": "Central Bangalore"
              },
              "label": "Hotel Cloud9 Residency",
              "value": "00006150"
            },
            {
              "loc": {
                "a": "Ulsoor",
                "c": "Bangalore",
                "lo": 77.626033,
                "la": 12.971192,
                "az": "M G Road"
              },
              "label": "Trinity suites",
              "value": "00016320"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Koramangala"
              },
              "label": "Apple Tree Apartment and Suites",
              "value": "00156708"
            },
            {
              "loc": {
                "a": "Rajaji Nagar",
                "c": "Bangalore",
                "lo": 12.987847,
                "la": 77.555779,
                "az": "Yeshwanthpur"
              },
              "label": "Vajra Heritage",
              "value": "00126311"
            },
            {
              "loc": {
                "a": "Brigade Road",
                "c": "Bangalore",
                "lo": 77.603166,
                "la": 12.975085,
                "az": "M G Road",
                "z": "Central Bangalore"
              },
              "label": "Highgates Hotel",
              "value": "00003640"
            },
            {
              "loc": {
                "a": "Bellandur",
                "c": "Bangalore",
                "lo": 77.683798,
                "la": 12.931049,
                "az": "Marathahalli"
              },
              "label": "Siesta Bellandur",
              "value": "00085109"
            },
            {
              "loc": {
                "a": "Hosur Main Road",
                "c": "Bangalore",
                "lo": 77.665384,
                "la": 12.845083,
                "az": "Electronic City"
              },
              "label": "Zone by the Park, Electronic City",
              "value": "00088559"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.71787,
                "la": 12.972239,
                "az": "Whitefield"
              },
              "label": "Lemon Tree Hotel Whitefield",
              "value": "00015459"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.64025,
                "la": 12.982951,
                "az": "Indira Nagar"
              },
              "label": "Regenta inn indiranagar",
              "value": "00176479"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.592591,
                "la": 13.058658,
                "az": "Hebbal"
              },
              "label": "Attide Biz",
              "value": "00044138"
            },
            {
              "loc": {
                "a": "Airport Road",
                "c": "Bangalore",
                "lo": 77.614976,
                "la": 13.151981
              },
              "label": "Classio Inn",
              "value": "00151411"
            },
            {
              "loc": {
                "a": "Marathahalli",
                "c": "Bangalore",
                "lo": 77.714524,
                "la": 12.963825,
                "az": "Marathahalli"
              },
              "label": "Kensington Suites",
              "value": "00156210"
            },
            {
              "loc": {
                "a": "Nagvara Palya Road",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Hebbal"
              },
              "label": "Hotel Felicity Inn by Sky Stays",
              "value": "00156846"
            },
            {
              "loc": {
                "a": "Hsr Layout",
                "c": "Bangalore",
                "lo": 77.643,
                "la": 12.91,
                "az": "Koramangala"
              },
              "label": "Coffee Bean Inn Service Apartment",
              "value": "00177180"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.638419,
                "la": 12.98089,
                "az": "Indira Nagar"
              },
              "label": "Apollo House",
              "value": "00147599"
            },
            {
              "loc": {
                "a": "Domlur",
                "c": "Bangalore",
                "lo": 12.9595,
                "la": 77.6384,
                "az": "Indira Nagar"
              },
              "label": "Apollo 27",
              "value": "00156706"
            },
            {
              "loc": {
                "a": "Devanahalli",
                "c": "Bangalore",
                "lo": 77.635713,
                "la": 13.194954,
                "az": "Bengaluru International Airport Road",
                "z": "North Bangalore"
              },
              "label": "Goldfinch Retreat",
              "value": "00007533"
            },
            {
              "loc": {
                "a": "Ulsoor",
                "c": "Bangalore",
                "lo": 77.619425,
                "la": 12.976151,
                "az": "M G Road"
              },
              "label": "Radisson Bengaluru City Center",
              "value": "00135194"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.643165,
                "la": 13.191889,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Shivas Galaxy",
              "value": "00147486"
            },
            {
              "loc": {
                "a": "Rajaji Nagar",
                "c": "Bangalore",
                "lo": 77.554217,
                "la": 13.014275,
                "az": "Yeshwanthpur",
                "z": "Central Bangalore"
              },
              "label": "Parijatha Gateway Hotel",
              "value": "00004615"
            },
            {
              "loc": {
                "a": "Hsr Layout",
                "c": "Bangalore",
                "lo": 77.62409,
                "la": 12.917935,
                "az": "Koramangala"
              },
              "label": "FabHotel 4 Seasons Silk Board",
              "value": "00012873"
            },
            {
              "loc": {
                "a": "High Grounds",
                "c": "Bangalore",
                "lo": 77.578101,
                "la": 12.985432,
                "az": "Gandhi Nagar",
                "z": "Central Bangalore"
              },
              "label": "Goldfinch Hotel Bangalore",
              "value": "00000333"
            },
            {
              "loc": {
                "a": "Bommasandra Industrial Area",
                "c": "Bangalore",
                "lo": 77.681543,
                "la": 12.824631,
                "az": "Electronic City",
                "z": "South Bangalore"
              },
              "label": "Sai Vishram Business Hotel",
              "value": "00002108"
            },
            {
              "loc": {
                "a": "St Marks Road",
                "c": "Bangalore",
                "lo": 77.600127,
                "la": 12.969146,
                "az": "M G Road",
                "z": "South Bangalore"
              },
              "label": "St Mark's Hotel",
              "value": "00004906"
            },
            {
              "loc": {
                "a": "Mathikere",
                "c": "Bangalore",
                "lo": 77.558343,
                "la": 13.033721,
                "az": "Yeshwanthpur"
              },
              "label": "FabHotel RMS Comforts",
              "value": "00079515"
            },
            {
              "loc": {
                "a": "Residency Road",
                "c": "Bangalore",
                "lo": 77.615715,
                "la": 12.971668,
                "az": "M G Road"
              },
              "label": "Hotel Ajantha",
              "value": "00030903"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.636087,
                "la": 12.968977,
                "az": "Indira Nagar"
              },
              "label": "FabHotel Park Inn Indiranagar",
              "value": "00075407"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.615796,
                "la": 12.926889,
                "az": "Koramangala"
              },
              "label": "Hotel Delta Regency",
              "value": "00047234"
            },
            {
              "loc": {
                "a": "Brigade Road",
                "c": "Bangalore",
                "lo": 77.606588,
                "la": 12.969623,
                "az": "M G Road"
              },
              "label": "FabHotel Capital Residency Brigade Road",
              "value": "00114361"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.614508,
                "la": 12.936639,
                "az": "Koramangala"
              },
              "label": "FabHotel Vipra Enclave Koramangala",
              "value": "00123167"
            },
            {
              "loc": {
                "a": "Mahadevapura Post",
                "c": "Bangalore",
                "lo": 77.70164,
                "la": 12.96487,
                "az": "Marathahalli",
                "z": "East Bangalore"
              },
              "label": "FabHotel Lotus Park Marathahalli",
              "value": "00004886"
            },
            {
              "loc": {
                "a": "Bellandur",
                "c": "Bangalore",
                "lo": 77.673822,
                "la": 12.924006,
                "az": "Marathahalli"
              },
              "label": "FabHotel Sri Krishnas Suites Bellandur",
              "value": "00151497"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.617869,
                "la": 12.934685,
                "az": "Koramangala"
              },
              "label": "Fabhotel Corporate Crown Koramangala",
              "value": "00083168"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.6135,
                "la": 12.99605
              },
              "label": "FabHotel Vista Suites Pulikeshi Nagar",
              "value": "00149142"
            },
            {
              "loc": {
                "a": "Ulsoor",
                "c": "Bangalore",
                "lo": 77.619626,
                "la": 12.973966,
                "az": "M G Road",
                "z": "South Bangalore"
              },
              "label": "The Park Bangalore",
              "value": "00000021"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.7562,
                "la": 12.98356,
                "az": "Whitefield"
              },
              "label": "The Byke Signature",
              "value": "00087716"
            },
            {
              "loc": {
                "a": "New Tippasandra",
                "c": "Bangalore",
                "lo": 77.657203,
                "la": 12.972168
              },
              "label": "FabHotel Oakwoods Serai",
              "value": "00114365"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.630219,
                "la": 12.929642,
                "az": "Koramangala"
              },
              "label": "FabHotel Ivory Pearl Koramangala",
              "value": "00088701"
            },
            {
              "loc": {
                "a": "Bannerghatta Road",
                "c": "Bangalore",
                "lo": 77.600832,
                "la": 12.902061
              },
              "label": "Elite Park",
              "value": "00061953"
            },
            {
              "loc": {
                "a": "Hsr Layout",
                "c": "Bangalore",
                "lo": 77.651421,
                "la": 12.922892,
                "az": "Koramangala"
              },
              "label": "Fabhotel Astra Suites HSR Layout",
              "value": "00084692"
            },
            {
              "loc": {
                "a": "Banashankari",
                "c": "Bangalore",
                "lo": 77.536164,
                "la": 12.916407,
                "az": "Jayanagar"
              },
              "label": "FabHotel Oriental Suites",
              "value": "00123016"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.410655,
                "la": 12.8877,
                "az": "Outskirts"
              },
              "label": "Aditya Orchards",
              "value": "00102372"
            },
            {
              "loc": {
                "a": "Mathikere",
                "c": "Bangalore",
                "lo": 77.56333,
                "la": 13.030195,
                "az": "Yeshwanthpur"
              },
              "label": "Visitors Comfort",
              "value": "00046288"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.643993,
                "la": 12.964879,
                "az": "Indira Nagar"
              },
              "label": "FabHotel Oakwey Inn Indiranagar",
              "value": "00123019"
            },
            {
              "loc": {
                "a": "B T M Layout",
                "c": "Bangalore",
                "lo": 77.605381,
                "la": 12.913113,
                "az": "Koramangala"
              },
              "label": "FabExpress Oriental Suites BTM layout",
              "value": "00020515"
            },
            {
              "loc": {
                "a": "New Bel Road",
                "c": "Bangalore",
                "lo": 77.554663,
                "la": 13.042004,
                "az": "Yeshwanthpur",
                "z": "North Bangalore"
              },
              "label": "Gokulam Grand Hotel & Spa",
              "value": "00006381"
            },
            {
              "loc": {
                "a": "Kalyan Nagar",
                "c": "Bangalore",
                "lo": 77.639609,
                "la": 13.026382,
                "az": "Hebbal",
                "z": "North Bangalore"
              },
              "label": "Hotel Jamayca",
              "value": "00005401"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.709705,
                "la": 12.97917,
                "az": "Whitefield",
                "z": "East Bangalore"
              },
              "label": "Keys Select Whitefield - By Lemon Tree Hotels",
              "value": "00006353"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.60969,
                "la": 13.203244,
                "az": "Bengaluru International Airport Road"
              },
              "label": "The Windflower Prakruthi",
              "value": "00028324"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.723089,
                "la": 12.990039,
                "az": "Whitefield",
                "z": "East Bangalore"
              },
              "label": "The Zuri Whitefield Bangalore",
              "value": "00004485"
            },
            {
              "loc": {
                "a": "Bommasandra Industrial Area",
                "c": "Bangalore",
                "lo": 77.68738,
                "la": 12.823206,
                "az": "Electronic City",
                "z": "South Bangalore"
              },
              "label": "Gardeenia Comforts",
              "value": "00006379"
            },
            {
              "loc": {
                "a": "Jayanagar",
                "c": "Bangalore",
                "lo": 77.583219,
                "la": 12.934576,
                "az": "Jayanagar"
              },
              "label": "Lilac Hotel",
              "value": "00028206"
            },
            {
              "loc": {
                "a": "Infantry Road",
                "c": "Bangalore",
                "lo": 77.593499,
                "la": 12.983617,
                "az": "M G Road",
                "z": "Central Bangalore"
              },
              "label": "Ashraya International Hotel",
              "value": "00001130"
            },
            {
              "loc": {
                "a": "Hosur Main Road",
                "c": "Bangalore",
                "lo": 77.702384,
                "la": 12.828477,
                "az": "Electronic City"
              },
              "label": "Gold Coins Club",
              "value": "00015302"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.718808,
                "la": 12.976928,
                "az": "Whitefield",
                "z": "East Bangalore"
              },
              "label": "Ginger (Whitefield)",
              "value": "00000422"
            },
            {
              "loc": {
                "a": "Mathikere",
                "c": "Bangalore",
                "lo": 77.562685,
                "la": 13.023254,
                "az": "Yeshwanthpur",
                "z": "North Bangalore"
              },
              "label": "Hotel Krishinton Suites",
              "value": "00005017"
            },
            {
              "loc": {
                "a": "Krishnarajapuram",
                "c": "Bangalore",
                "lo": 77.707872,
                "la": 13.019483
              },
              "label": "Bhagini Residency (K.R.Puram)",
              "value": "00015126"
            },
            {
              "loc": {
                "a": "J P Nagar",
                "c": "Bangalore",
                "lo": 77.583171,
                "la": 12.89219,
                "z": "South Bangalore"
              },
              "label": "Zip by Spree Hotels at the Woodrose",
              "value": "00004956"
            },
            {
              "loc": {
                "a": "New Bel Road",
                "c": "Bangalore",
                "lo": 77.571165,
                "la": 13.029908,
                "az": "Yeshwanthpur"
              },
              "label": "De Mandarin",
              "value": "00148447"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.579308,
                "la": 12.976342
              },
              "label": "Akshaya Aura",
              "value": "00042090"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.646699,
                "la": 13.19197,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Shivas Gateway",
              "value": "00079467"
            },
            {
              "loc": {
                "a": "Mathikere",
                "c": "Bangalore",
                "lo": 77.3332,
                "la": 13.01414,
                "az": "Yeshwanthpur"
              },
              "label": "Comfort Inn Insys",
              "value": "00085772"
            },
            {
              "loc": {
                "a": "Opp-t.dasarahalli Meto Station",
                "c": "Bangalore",
                "lo": 77.510721,
                "la": 13.043574,
                "az": "Yeshwanthpur"
              },
              "label": "Hotel Thanga Orchid",
              "value": "00096405"
            },
            {
              "loc": {
                "a": "Domlur",
                "c": "Bangalore",
                "lo": 77.640047,
                "la": 12.952268,
                "az": "Indira Nagar",
                "z": "South Bangalore"
              },
              "label": "Ginger Bangalore IRR",
              "value": "00008086"
            },
            {
              "loc": {
                "a": "Cunningham Road",
                "c": "Bangalore",
                "lo": 77.595549,
                "la": 12.986128,
                "az": "M G Road"
              },
              "label": "Citrus Cunningham Road Bangalore",
              "value": "00019784"
            },
            {
              "loc": {
                "a": "Infantry Road",
                "c": "Bangalore",
                "lo": 77.604889,
                "la": 12.981752,
                "az": "M G Road",
                "z": "Central Bangalore"
              },
              "label": "Hotel AJ International",
              "value": "00001480"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.469007,
                "la": 13.179662,
                "az": "Outskirts",
                "z": "North Bangalore"
              },
              "label": "Our Native Village Eco Resort",
              "value": "00001851"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.680173,
                "la": 13.159945,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Fiestaa Resort n Events Venue",
              "value": "00082804"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.616465,
                "la": 12.934412,
                "az": "Koramangala"
              },
              "label": "Comfy Luxury Hotel",
              "value": "00176902"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.603531,
                "la": 13.106556,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Hoppers Stop Yelahanka",
              "value": "00011329"
            },
            {
              "loc": {
                "a": "Bannerghatta Road",
                "c": "Bangalore",
                "lo": 77.600882,
                "la": 12.931049,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "Savoury Seashell Residency",
              "value": "00009477"
            },
            {
              "loc": {
                "a": "Jalahalli",
                "c": "Bangalore",
                "lo": 77.520691,
                "la": 13.043771,
                "az": "Yeshwanthpur"
              },
              "label": "Hotel Costal King",
              "value": "00136656"
            },
            {
              "loc": {
                "a": "R T Nagar",
                "c": "Bangalore",
                "lo": 77.587398,
                "la": 13.024073,
                "az": "Hebbal"
              },
              "label": "Goldfinch Express RT Nagar",
              "value": "00136775"
            },
            {
              "loc": {
                "a": "Brigade Road",
                "c": "Bangalore",
                "lo": 77.607244,
                "la": 12.968165,
                "az": "M G Road"
              },
              "label": "Hotel Windsor Castle Inn",
              "value": "00135113"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.630659,
                "la": 12.932624,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "Dass Suites Koramangala",
              "value": "00005510"
            },
            {
              "loc": {
                "a": "Marathahalli",
                "c": "Bangalore",
                "lo": 77.701524,
                "la": 12.949673,
                "az": "Marathahalli"
              },
              "label": "Hotel High Sky, Whitefield",
              "value": "00071351"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.624654,
                "la": 12.940068,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "D-Habitat Suites, Rooms n Apartments",
              "value": "00000859"
            },
            {
              "loc": {
                "a": "R T Nagar",
                "c": "Bangalore",
                "lo": 77.591662,
                "la": 13.017755,
                "az": "Hebbal",
                "z": "East Bangalore"
              },
              "label": "Coral Tree",
              "value": "00007022"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.555036,
                "la": 13.012727,
                "az": "Outskirts"
              },
              "label": "Hotel Gets Grand",
              "value": "00045196"
            },
            {
              "loc": {
                "a": "Shivaji Nagar",
                "c": "Bangalore",
                "lo": 77.60541,
                "la": 12.979024
              },
              "label": "Cubbon Suites",
              "value": "00176820"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.574289,
                "la": 12.974165
              },
              "label": "S N T Comforts",
              "value": "00016881"
            },
            {
              "loc": {
                "a": "Old Airport Road",
                "c": "Bangalore",
                "lo": 77.64,
                "la": 12.962,
                "az": "Indira Nagar"
              },
              "label": "Classic Inn",
              "value": "00177176"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.578593,
                "la": 12.977283,
                "az": "Gandhi Nagar"
              },
              "label": "Hotel A.T.G Royal Inn",
              "value": "00031070"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.75013,
                "la": 12.971389,
                "az": "Whitefield"
              },
              "label": "The White Tree Executive Suites",
              "value": "00141835"
            },
            {
              "loc": {
                "a": "Jayanagar",
                "c": "Bangalore",
                "lo": 77.5852,
                "la": 12.929619,
                "az": "Jayanagar"
              },
              "label": "Hotel Monarch International",
              "value": "00054399"
            },
            {
              "loc": {
                "a": "J P Nagar",
                "c": "Bangalore",
                "lo": 77.583861,
                "la": 12.902815,
                "z": "South Bangalore"
              },
              "label": "Inchara Hotel",
              "value": "00009095"
            },
            {
              "loc": {
                "a": "Bommasandra Industrial Area",
                "c": "Bangalore",
                "lo": 77.639739,
                "la": 12.779322,
                "az": "Electronic City"
              },
              "label": "Bella Vista",
              "value": "00152563"
            },
            {
              "loc": {
                "a": "Bannerghatta Road",
                "c": "Bangalore",
                "lo": 77.577462,
                "la": 12.802176,
                "az": "Koramangala"
              },
              "label": "Park Hotel And Resort",
              "value": "00079859"
            },
            {
              "loc": {
                "a": "Infantry Road",
                "c": "Bangalore",
                "lo": 77.596272,
                "la": 12.982841,
                "az": "M G Road",
                "z": "Central Bangalore"
              },
              "label": "iStay Hotels Infantry Road",
              "value": "00003894"
            },
            {
              "loc": {
                "a": "J P Nagar",
                "c": "Bangalore",
                "lo": 77.602576,
                "la": 12.892139
              },
              "label": "Arama Suites",
              "value": "00011352"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.576293,
                "la": 12.97897,
                "az": "Gandhi Nagar"
              },
              "label": "Hotel Canopy Classic",
              "value": "00046258"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.624578,
                "la": 12.93565,
                "az": "Koramangala"
              },
              "label": "The Aston Suites",
              "value": "00154606"
            },
            {
              "loc": {
                "a": "Airport Road",
                "c": "Bangalore",
                "lo": 77.619349,
                "la": 13.148174
              },
              "label": "S.M Royal Suites",
              "value": "00156703"
            },
            {
              "loc": {
                "a": "Outer Ring Road",
                "c": "Bangalore",
                "lo": 77.696784,
                "la": 12.975074
              },
              "label": "Krishnam A Business Hotel",
              "value": "00176903"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 0,
                "la": 0
              },
              "label": "Hotel RK Gardenia",
              "value": "00156682"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.571517,
                "la": 13.030843
              },
              "label": "Hotel Mint Green Path",
              "value": "00173828"
            },
            {
              "loc": {
                "a": "Manyata Tech Park",
                "c": "Bangalore",
                "lo": 77.619384,
                "la": 13.045219
              },
              "label": "Hotel Jade Blue Suite",
              "value": "00157011"
            },
            {
              "loc": {
                "a": "Madiwala",
                "c": "Bangalore",
                "lo": 77.619169,
                "la": 12.924187,
                "az": "Koramangala"
              },
              "label": "Executive Comfort",
              "value": "00011221"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.571702,
                "la": 12.969316,
                "z": "Central Bangalore"
              },
              "label": "Hotel Konark Residency",
              "value": "00007242"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.577495,
                "la": 12.956609
              },
              "label": "Skyline comforts",
              "value": "00017438"
            },
            {
              "loc": {
                "a": "Krishnarajapuram",
                "c": "Bangalore",
                "lo": 77.86001,
                "la": 13.130801,
                "z": "East Bangalore"
              },
              "label": "Solace Resort & Spa",
              "value": "00007984"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.575332,
                "la": 12.979125,
                "az": "Gandhi Nagar"
              },
              "label": "Mulberry Residency",
              "value": "00067623"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.576217,
                "la": 12.979124,
                "az": "Gandhi Nagar"
              },
              "label": "Magaji Residency",
              "value": "00031026"
            },
            {
              "loc": {
                "a": "Kammanahalli",
                "c": "Bangalore",
                "lo": 77.633589,
                "la": 13.015525,
                "az": "Hebbal"
              },
              "label": "Merivian Lets",
              "value": "00020788"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.538815,
                "la": 13.051961,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Air Avenue Suites",
              "value": "00149105"
            },
            {
              "loc": {
                "a": "Mahadevapura Post",
                "c": "Bangalore",
                "lo": 77.722055,
                "la": 12.990749,
                "az": "Marathahalli"
              },
              "label": "Abion Hotel",
              "value": "00147387"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.629886,
                "la": 12.935833,
                "az": "Koramangala"
              },
              "label": "Live Inn",
              "value": "00088046"
            },
            {
              "loc": {
                "a": "Kammanahalli",
                "c": "Bangalore",
                "lo": 77.636951,
                "la": 13.016056,
                "az": "Hebbal"
              },
              "label": "Royal Inn",
              "value": "00017529"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.574315,
                "la": 12.974
              },
              "label": "Everest Comforts",
              "value": "00032092"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.618805,
                "la": 13.144184,
                "az": "Outskirts"
              },
              "label": "A V Comforts",
              "value": "00037816"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.573894,
                "la": 12.978286
              },
              "label": "Honnagiri Residency",
              "value": "00027920"
            },
            {
              "loc": {
                "a": "Seshadripuram",
                "c": "Bangalore",
                "lo": 77.574096,
                "la": 12.988922,
                "az": "Yeshwanthpur"
              },
              "label": "Hotel Shiva International",
              "value": "00031042"
            },
            {
              "loc": {
                "a": "Minerva Circle",
                "c": "Bangalore",
                "lo": 77.581974,
                "la": 12.963349,
                "az": "Jayanagar"
              },
              "label": "Lusia Inn",
              "value": "00083205"
            },
            {
              "loc": {
                "a": "Banashankari",
                "c": "Bangalore",
                "lo": 77.5573,
                "la": 12.922411,
                "az": "Jayanagar"
              },
              "label": "Spiro Grand",
              "value": "00015986"
            },
            {
              "loc": {
                "a": "Mysore Road",
                "c": "Bangalore",
                "lo": 77.517346,
                "la": 12.936502,
                "az": "Outskirts",
                "z": "West Bangalore"
              },
              "label": "The Club",
              "value": "00006627"
            },
            {
              "loc": {
                "a": "Rajaji Nagar",
                "c": "Bangalore",
                "lo": 77.539708,
                "la": 12.99525,
                "az": "Yeshwanthpur",
                "z": "West Bangalore"
              },
              "label": "Shree Guru Residency",
              "value": "00004512"
            },
            {
              "loc": {
                "a": "Kalyan Nagar",
                "c": "Bangalore",
                "lo": 77.633873,
                "la": 13.027827,
                "az": "Hebbal",
                "z": "North Bangalore"
              },
              "label": "Royal Suites",
              "value": "00002975"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.313528,
                "la": 13.061103,
                "az": "Outskirts"
              },
              "label": "Ankit Vista Green Village",
              "value": "00010814"
            },
            {
              "loc": {
                "a": "Rajaji Nagar",
                "c": "Bangalore",
                "lo": 77.550078,
                "la": 12.989166,
                "az": "Yeshwanthpur"
              },
              "label": "Istay Hotels Rajajinagar",
              "value": "00015899"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.445523,
                "la": 12.888458,
                "az": "Outskirts",
                "z": "West Bangalore"
              },
              "label": "The Country Club Mysore Road",
              "value": "00003160"
            },
            {
              "loc": {
                "a": "Richmond Road",
                "c": "Bangalore",
                "lo": 77.604265,
                "la": 12.964365,
                "az": "M G Road",
                "z": "Central Bangalore"
              },
              "label": "Casa Cottage",
              "value": "00002491"
            },
            {
              "loc": {
                "a": "Brigade Road",
                "c": "Bangalore",
                "lo": 77.602715,
                "la": 12.975401,
                "az": "M G Road",
                "z": "Central Bangalore"
              },
              "label": "Hotel Empire International (Church Street)",
              "value": "00006057"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.491684,
                "la": 12.800022,
                "az": "Outskirts",
                "z": "South Bangalore"
              },
              "label": "Guhantara",
              "value": "00003683"
            },
            {
              "loc": {
                "a": "Race Course Road",
                "c": "Bangalore",
                "lo": 77.575988,
                "la": 12.980873,
                "az": "Gandhi Nagar",
                "z": "West Bangalore"
              },
              "label": "Fortune Park JP Celestial - Member ITC Hotel Group",
              "value": "00004558"
            },
            {
              "loc": {
                "a": "Bellandur",
                "c": "Bangalore",
                "lo": 77.670795,
                "la": 12.926023
              },
              "label": "Treebo Trip Hotel Worldtree Bellandur",
              "value": "00084784"
            },
            {
              "loc": {
                "a": "Bellandur",
                "c": "Bangalore",
                "lo": 77.671749,
                "la": 12.923293,
                "az": "Marathahalli",
                "z": "South Bangalore"
              },
              "label": "Citrus Bangalore",
              "value": "00007220"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.575901,
                "la": 12.97658,
                "z": "West Bangalore"
              },
              "label": "CRN Canary Sapphire",
              "value": "00005603"
            },
            {
              "loc": {
                "a": "Cunningham Road",
                "c": "Bangalore",
                "lo": 77.593118,
                "la": 12.988452,
                "az": "M G Road"
              },
              "label": "Sovereign Suites",
              "value": "00047107"
            },
            {
              "loc": {
                "a": "Madiwala",
                "c": "Bangalore",
                "lo": 77.61,
                "la": 12.92,
                "az": "Koramangala"
              },
              "label": "Delta Inn",
              "value": "00103381"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.57,
                "la": 12.97984,
                "az": "Gandhi Nagar"
              },
              "label": "Zion - A Luxurious Hotel",
              "value": "00177224"
            },
            {
              "loc": {
                "a": "Mathikere",
                "c": "Bangalore",
                "lo": 77.559,
                "la": 13.028438,
                "az": "Yeshwanthpur"
              },
              "label": "The Green Tree",
              "value": "00061459"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.542689,
                "la": 12.86741,
                "az": "Outskirts"
              },
              "label": "Holiday Village",
              "value": "00030579"
            },
            {
              "loc": {
                "a": "Marathahalli",
                "c": "Bangalore",
                "lo": 77.712226,
                "la": 12.971286,
                "az": "Marathahalli"
              },
              "label": "High Sky Sterling Brookside",
              "value": "00075782"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.613251,
                "la": 13.041973,
                "az": "Hebbal"
              },
              "label": "Country Inn & Suites, Bengaluru Hebbal",
              "value": "00028600"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.640617,
                "la": 12.970949,
                "az": "Indira Nagar",
                "z": "Central Bangalore"
              },
              "label": "juSTa Indiranagar, Bangalore",
              "value": "00003942"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.659471,
                "la": 12.839651,
                "az": "Electronic City"
              },
              "label": "CompactE-city",
              "value": "00087203"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.575539,
                "la": 12.980985,
                "az": "Gandhi Nagar",
                "z": "West Bangalore"
              },
              "label": "The Citadel Hotel",
              "value": "00004421"
            },
            {
              "loc": {
                "a": "Madiwala",
                "c": "Bangalore",
                "lo": 77.61,
                "la": 12.92,
                "az": "Koramangala"
              },
              "label": "Golden Regency-II",
              "value": "00098212"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.715058,
                "la": 12.964452,
                "az": "Whitefield"
              },
              "label": "Treebo Trend Emora Hotel And Suites Brookfield",
              "value": "00174818"
            },
            {
              "loc": {
                "a": "Seshadripuram",
                "c": "Bangalore",
                "lo": 77.583607,
                "la": 12.999256,
                "az": "Yeshwanthpur"
              },
              "label": "Tulip Inn Bangalore",
              "value": "00067561"
            },
            {
              "loc": {
                "a": "Ulsoor",
                "c": "Bangalore",
                "lo": 77.637789,
                "la": 12.97747,
                "az": "M G Road"
              },
              "label": "X by bloom l Indiranagar",
              "value": "00147566"
            },
            {
              "loc": {
                "a": "Hsr Layout",
                "c": "Bangalore",
                "lo": 77.63934,
                "la": 12.909673,
                "az": "Koramangala"
              },
              "label": "Treebo Trend Kings Suits",
              "value": "00149171"
            },
            {
              "loc": {
                "a": "Richmond Road",
                "c": "Bangalore",
                "lo": 77.599634,
                "la": 12.964765,
                "az": "M G Road",
                "z": "Central Bangalore"
              },
              "label": "The Pride Hotel",
              "value": "00004691"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.639777,
                "la": 12.978016,
                "az": "Indira Nagar"
              },
              "label": "Ixora Suites",
              "value": "00023503"
            },
            {
              "loc": {
                "a": "M G Road",
                "c": "Bangalore",
                "lo": 77.534496,
                "la": 12.980181,
                "az": "M G Road"
              },
              "label": "Zone by the Park, Infantry Road",
              "value": "00117258"
            },
            {
              "loc": {
                "a": "Brigade Road",
                "c": "Bangalore",
                "lo": 77.589348,
                "la": 12.969689,
                "az": "M G Road"
              },
              "label": "FabHotel 29th Church Inn M.G. Road",
              "value": "00070945"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.995404,
                "la": 13.31778
              },
              "label": "GK Hill View Resort",
              "value": "00147603"
            },
            {
              "loc": {
                "a": "Yelahanka",
                "c": "Bangalore",
                "lo": 77.550401,
                "la": 13.010713,
                "az": "Bengaluru International Airport Road",
                "z": "Central Bangalore"
              },
              "label": "Hotel Vande Matharam",
              "value": "00004261"
            },
            {
              "loc": {
                "a": "Mysore Road",
                "c": "Bangalore",
                "lo": 77.52,
                "la": 12.94
              },
              "label": "Mastiff Hotel Bangalore",
              "value": "00104059"
            },
            {
              "loc": {
                "a": "Sudhama Nagar",
                "c": "Bangalore",
                "lo": 77.589202,
                "la": 12.961465
              },
              "label": "Treebo Apple Villa",
              "value": "00145263"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.630278,
                "la": 12.970167,
                "az": "Indira Nagar"
              },
              "label": "FabHotel Millenium Stay Indiranagar",
              "value": "00114363"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.616012,
                "la": 12.934228,
                "az": "Koramangala"
              },
              "label": "Treebo Trend Terminus",
              "value": "00176452"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.619578,
                "la": 12.924354,
                "az": "Koramangala"
              },
              "label": "Treebo Trend White Inn",
              "value": "00145287"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.625317,
                "la": 12.937999
              },
              "label": "FabHotel Corporate Crown II Koramangala",
              "value": "00123022"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Gandhi Nagar"
              },
              "label": "Kengeri Gateway Comforts",
              "value": "00102568"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.61455,
                "la": 12.936877,
                "az": "Koramangala"
              },
              "label": "Treebo Trend Blue Bells Boutique Hotel",
              "value": "00177231"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.713129,
                "la": 12.977498,
                "az": "Whitefield",
                "z": "East Bangalore"
              },
              "label": "Radha Hometel Whitefield  - A Sarovar Hotel",
              "value": "00000449"
            },
            {
              "loc": {
                "a": "Domlur",
                "c": "Bangalore",
                "lo": 77.641175,
                "la": 12.966715,
                "az": "Indira Nagar",
                "z": "Central Bangalore"
              },
              "label": "Tristar Service Apartments",
              "value": "00001046"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.748356,
                "la": 12.95965,
                "az": "Whitefield"
              },
              "label": "Oakwood Residence Whitefield Bangalore",
              "value": "00016322"
            },
            {
              "loc": {
                "a": "M G Road",
                "c": "Bangalore",
                "lo": 77.61781,
                "la": 12.974677,
                "az": "M G Road",
                "z": "South Bangalore"
              },
              "label": "juSTa MG Road, Bangalore",
              "value": "00005432"
            },
            {
              "loc": {
                "a": "Brigade Road",
                "c": "Bangalore",
                "lo": 77.606822,
                "la": 12.966965,
                "az": "M G Road"
              },
              "label": "Hotel Vellara",
              "value": "00020508"
            },
            {
              "loc": {
                "a": "Minerva Circle",
                "c": "Bangalore",
                "lo": 77.577084,
                "la": 12.955215,
                "az": "Jayanagar"
              },
              "label": "Trishala Residency",
              "value": "00014257"
            },
            {
              "loc": {
                "a": "Kodihalli",
                "c": "Bangalore",
                "lo": 77.64945,
                "la": 12.964659,
                "az": "Indira Nagar"
              },
              "label": "CompactCopperQuilt",
              "value": "00087205"
            },
            {
              "loc": {
                "a": "Ulsoor",
                "c": "Bangalore",
                "lo": 77.61781,
                "la": 12.974677,
                "az": "M G Road",
                "z": "South Bangalore"
              },
              "label": "juSTa Off MG Road",
              "value": "00002244"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.750145,
                "la": 12.980347,
                "az": "Whitefield"
              },
              "label": "The Sanctum Suites Whitefield",
              "value": "00126109"
            },
            {
              "loc": {
                "a": "Domlur",
                "c": "Bangalore",
                "lo": 77.708769,
                "la": 12.957336,
                "az": "Indira Nagar"
              },
              "label": "CompactStatelyHomes",
              "value": "00017807"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.63,
                "la": 13.02,
                "az": "Hebbal"
              },
              "label": "Windsor Inn",
              "value": "00104366"
            },
            {
              "loc": {
                "a": "Mysore Road",
                "c": "Bangalore",
                "lo": 77.416349,
                "la": 12.810264,
                "az": "Outskirts",
                "z": "West Bangalore"
              },
              "label": "Eagleton (The Golf Resort)",
              "value": "00003233"
            },
            {
              "loc": {
                "a": "Richmond Road",
                "c": "Bangalore",
                "lo": 77.614385,
                "la": 12.968966,
                "az": "M G Road"
              },
              "label": "WelcomHotel Bengaluru- ITC Hotel Group",
              "value": "00019934"
            },
            {
              "loc": {
                "a": "Madiwala",
                "c": "Bangalore",
                "lo": 77.617256,
                "la": 12.925029,
                "az": "Koramangala"
              },
              "label": "Century Inn",
              "value": "00011161"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.73,
                "la": 12.98,
                "az": "Whitefield"
              },
              "label": "The Den Bengaluru",
              "value": "00101910"
            },
            {
              "loc": {
                "a": "Domlur",
                "c": "Bangalore",
                "lo": 77.64313,
                "la": 12.957297,
                "az": "Indira Nagar"
              },
              "label": "Hotel Felicity Inn EGL by Sky Stay",
              "value": "00021522"
            },
            {
              "loc": {
                "a": "J P Nagar",
                "c": "Bangalore",
                "lo": 77.592918,
                "la": 12.906433,
                "z": "South Bangalore"
              },
              "label": "HHI Select Bengaluru",
              "value": "00003813"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.629732,
                "la": 13.035146,
                "az": "Hebbal"
              },
              "label": "Treebo Trend Daffodil Suites",
              "value": "00046727"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.637734,
                "la": 12.979284,
                "az": "Indira Nagar"
              },
              "label": "Treebo Trend 9 Marks Inn",
              "value": "00052567"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.63089,
                "la": 12.93835,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "Treebo Trend Edha Suites",
              "value": "00002279"
            },
            {
              "loc": {
                "a": "Marathahalli",
                "c": "Bangalore",
                "lo": 77.675848,
                "la": 12.923325,
                "az": "Marathahalli",
                "z": "East Bangalore"
              },
              "label": "Treebo Trend Sterling Suites Inn",
              "value": "00003003"
            },
            {
              "loc": {
                "a": "Mysore Road",
                "c": "Bangalore",
                "lo": 77.401804,
                "la": 12.838117,
                "az": "Outskirts",
                "z": "West Bangalore"
              },
              "label": "Wonderla Resort",
              "value": "00009025"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.576498,
                "la": 13.025498,
                "az": "Hebbal"
              },
              "label": "The Sanctum Suites BEL Road",
              "value": "00024220"
            },
            {
              "loc": {
                "a": "Basavangudi",
                "c": "Bangalore",
                "lo": 77.56793,
                "la": 12.944202,
                "az": "Jayanagar"
              },
              "label": "Treebo Trend Akshaya Bull Temple",
              "value": "00145285"
            },
            {
              "loc": {
                "a": "M G Road",
                "c": "Bangalore",
                "lo": 77.607346,
                "la": 12.972864,
                "az": "M G Road"
              },
              "label": "Treebo Tryst Monarch Brigade Road",
              "value": "00146619"
            },
            {
              "loc": {
                "a": "Hsr Layout",
                "c": "Bangalore",
                "lo": 77.64324,
                "la": 12.910538,
                "az": "Koramangala"
              },
              "label": "Treebo Trip Shivas Kuteera",
              "value": "00145455"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.608619,
                "la": 12.935359,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "Treebo Trend Paul's Inn",
              "value": "00001800"
            },
            {
              "loc": {
                "a": "M G Road",
                "c": "Bangalore",
                "lo": 77.614794,
                "la": 12.970257,
                "az": "M G Road"
              },
              "label": "Brunton Heights",
              "value": "00013819"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.63782,
                "la": 12.982,
                "az": "Indira Nagar"
              },
              "label": "Treebo Trend Raj Premier",
              "value": "00073489"
            },
            {
              "loc": {
                "a": "Hsr Layout",
                "c": "Bangalore",
                "lo": 77.6432,
                "la": 12.907779,
                "az": "Koramangala"
              },
              "label": "Treebo Trip Crystal Suites",
              "value": "00177236"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.644501,
                "la": 12.965098,
                "az": "Indira Nagar"
              },
              "label": "Treebo Trend Mel's Suites Indiranagar",
              "value": "00087864"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.651196,
                "la": 12.848371,
                "az": "Electronic City"
              },
              "label": "Samrudhi Suites",
              "value": "00031933"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.748606,
                "la": 12.982699,
                "az": "Whitefield"
              },
              "label": "Treebo Trip Hotel Worldtree - ITPL",
              "value": "00075353"
            },
            {
              "loc": {
                "a": "J P Nagar",
                "c": "Bangalore",
                "lo": 77.59503,
                "la": 12.901237
              },
              "label": "Treebo Trend Stay Tuned",
              "value": "00145456"
            },
            {
              "loc": {
                "a": "Richmond Road",
                "c": "Bangalore",
                "lo": 77.616809,
                "la": 12.970626,
                "az": "M G Road"
              },
              "label": "Laika Boutique stay",
              "value": "00014886"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.638981,
                "la": 12.974922,
                "az": "Indira Nagar"
              },
              "label": "Treebo Blu Orchid",
              "value": "00149158"
            },
            {
              "loc": {
                "a": "Mysore Road",
                "c": "Bangalore",
                "lo": 77.540693,
                "la": 12.907414,
                "az": "Outskirts"
              },
              "label": "Treebo Trend Rajathadri Palace",
              "value": "00123222"
            },
            {
              "loc": {
                "a": "Seshadripuram",
                "c": "Bangalore",
                "lo": 77.574335,
                "la": 12.987502,
                "az": "Yeshwanthpur"
              },
              "label": "Treebo Trend President Suites",
              "value": "00147572"
            },
            {
              "loc": {
                "a": "Kalyan Nagar",
                "c": "Bangalore",
                "lo": 77.637559,
                "la": 13.022318,
                "az": "Hebbal"
              },
              "label": "Royal Serenity - Kammanahalli",
              "value": "00093894"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.57772,
                "la": 12.95955
              },
              "label": "Greens Residency",
              "value": "00033228"
            },
            {
              "loc": {
                "a": "B T M Layout",
                "c": "Bangalore",
                "lo": 77.608001,
                "la": 12.895806,
                "az": "Koramangala"
              },
              "label": "Treebo Trip Akshaya Mayflower",
              "value": "00047251"
            },
            {
              "loc": {
                "a": "Kammanahalli",
                "c": "Bangalore",
                "lo": 77.6365,
                "la": 13.0232,
                "az": "Hebbal"
              },
              "label": "Savoury Restaurant & Residency",
              "value": "00145413"
            },
            {
              "loc": {
                "a": "Yelahanka",
                "c": "Bangalore",
                "lo": 77.598096,
                "la": 13.10013
              },
              "label": "Treebo Trend Rotano Suites",
              "value": "00114338"
            },
            {
              "loc": {
                "a": "Jayanagar",
                "c": "Bangalore",
                "lo": 77.593803,
                "la": 12.916686,
                "az": "Jayanagar"
              },
              "label": "Hotel Paramos Inn",
              "value": "00147489"
            },
            {
              "loc": {
                "a": "Rajaji Nagar",
                "c": "Bangalore",
                "lo": 77.55782,
                "la": 12.99197,
                "az": "Yeshwanthpur"
              },
              "label": "Treebo Trend Saga Comforts",
              "value": "00177243"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.733741,
                "la": 12.987913,
                "az": "Whitefield"
              },
              "label": "Treebo Sri Udupi Park",
              "value": "00176403"
            },
            {
              "loc": {
                "a": "Seshadripuram",
                "c": "Bangalore",
                "lo": 77.574669,
                "la": 12.9872,
                "az": "Yeshwanthpur"
              },
              "label": "Modern Hotel",
              "value": "00017437"
            },
            {
              "loc": {
                "a": "Krishnarajapuram",
                "c": "Bangalore",
                "lo": 77.69687,
                "la": 13.00906
              },
              "label": "Nisarga Hotel (KR Puram)",
              "value": "00020785"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.570616,
                "la": 12.976835
              },
              "label": "Hotel Adarsha Palace",
              "value": "00055613"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.663867,
                "la": 12.840047
              },
              "label": "Treebo Oyster Inn",
              "value": "00156761"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.57794,
                "la": 12.979101,
                "az": "Gandhi Nagar"
              },
              "label": "Hotel GM Plaza",
              "value": "00153598"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 12.9766,
                "la": 77.5706
              },
              "label": "Manpho Bell Hotel and Convention Centre",
              "value": "00177151"
            },
            {
              "loc": {
                "a": "Sarjapur Road",
                "c": "Bangalore",
                "lo": 77.675346,
                "la": 12.916346
              },
              "label": "Treebo Trend Atithi Residency",
              "value": "00157062"
            },
            {
              "loc": {
                "a": "Bommasandra Industrial Area",
                "c": "Bangalore",
                "lo": 77.70027,
                "la": 12.80572,
                "az": "Electronic City"
              },
              "label": "Treebo Trend The Galaxy",
              "value": "00157247"
            },
            {
              "loc": {
                "a": "Seshadripuram",
                "c": "Bangalore",
                "lo": 77.580581,
                "la": 12.99721,
                "az": "Yeshwanthpur"
              },
              "label": "Hotel Bharat",
              "value": "00056164"
            },
            {
              "loc": {
                "a": "Domlur",
                "c": "Bangalore",
                "lo": 77.638019,
                "la": 12.957644,
                "az": "Indira Nagar"
              },
              "label": "Stately Homes Domlur Layout",
              "value": "00017804"
            },
            {
              "loc": {
                "a": "M G Road",
                "c": "Bangalore",
                "lo": 77.612334,
                "la": 12.97084,
                "az": "M G Road"
              },
              "label": "StayWithUs MGRoad",
              "value": "00060766"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.503253,
                "la": 13.072069,
                "az": "Outskirts"
              },
              "label": "Hotel Cinnamon Residency",
              "value": "00031920"
            },
            {
              "loc": {
                "a": "Minerva Circle",
                "c": "Bangalore",
                "lo": 77.579847,
                "la": 12.949193,
                "az": "Jayanagar"
              },
              "label": "Hotel Kamat Lal Bagh",
              "value": "00043710"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.617266,
                "la": 12.934196,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "Compact Tea Pavillion",
              "value": "00009761"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.573923,
                "la": 12.980128,
                "az": "Gandhi Nagar"
              },
              "label": "Hotel Rajmahal",
              "value": "00020017"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.708769,
                "la": 12.957336,
                "z": "East Bangalore"
              },
              "label": "Compact Magnolia",
              "value": "00009768"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.736319,
                "la": 12.956698,
                "az": "Whitefield",
                "z": "East Bangalore"
              },
              "label": "VR Royal Residency",
              "value": "00003743"
            },
            {
              "loc": {
                "a": "Cooke Town",
                "c": "Bangalore",
                "lo": 77.625721,
                "la": 13.002053
              },
              "label": "Treebo Trend Eden Suites",
              "value": "00177268"
            },
            {
              "loc": {
                "a": "Kodihalli",
                "c": "Bangalore",
                "lo": 77.643819,
                "la": 12.958355,
                "az": "Indira Nagar"
              },
              "label": "IBC Hotels and Resorts Pvt Ltd",
              "value": "00083368"
            },
            {
              "loc": {
                "a": "Rustam Bagh",
                "c": "Bangalore",
                "lo": 77.649653,
                "la": 12.958116
              },
              "label": "FabHotel Urban",
              "value": "00157145"
            },
            {
              "loc": {
                "a": "St Marks Road",
                "c": "Bangalore",
                "lo": 77.600684,
                "la": 12.970667,
                "az": "M G Road"
              },
              "label": "Treebo Trend Edge",
              "value": "00041917"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.529015,
                "la": 12.911581,
                "az": "Outskirts",
                "z": "South Bangalore"
              },
              "label": "Shakthi Hill Resorts",
              "value": "00002692"
            },
            {
              "loc": {
                "a": "Jayanagar",
                "c": "Bangalore",
                "lo": 77.583549,
                "la": 12.943543,
                "az": "Jayanagar"
              },
              "label": "Treebo Trend Akshaya Lalbagh Inn",
              "value": "00054154"
            },
            {
              "loc": {
                "a": "Doddaballapur Main Road",
                "c": "Bangalore",
                "lo": 77.559507,
                "la": 13.182467,
                "z": "North Bangalore"
              },
              "label": "Angsana Oasis Spa & Resort",
              "value": "00001300"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.734447,
                "la": 12.955435,
                "az": "Whitefield",
                "z": "East Bangalore"
              },
              "label": "Miraya Hotel Whitefield",
              "value": "00005638"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.5,
                "la": 10.25
              },
              "label": "Hotel Gokul Majestick",
              "value": "00066979"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.203028,
                "la": 12.712113,
                "az": "Outskirts"
              },
              "label": "The Kanva Heritage Resort",
              "value": "00087570"
            },
            {
              "loc": {
                "a": "Madiwala",
                "c": "Bangalore",
                "lo": 77.610409,
                "la": 12.933768,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "Hotel Golden Bell",
              "value": "00001787"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.617105,
                "la": 12.935847,
                "az": "Koramangala"
              },
              "label": "Emerald Suites by Omatra",
              "value": "00079575"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.695604,
                "la": 12.995886,
                "az": "Whitefield"
              },
              "label": "The Waverly Hotel & Residences",
              "value": "00072159"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 0,
                "la": 0
              },
              "label": "Jiwi rooms BudgetStays089",
              "value": "00108123"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Gandhi Nagar"
              },
              "label": "Jiwi rooms BudgetStays077",
              "value": "00108111"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Electronic City"
              },
              "label": "Jiwi rooms BudgetStays045",
              "value": "00108098"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.629965,
                "la": 12.938594,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "Shilton Royale - Kormangala",
              "value": "00003673"
            },
            {
              "loc": {
                "a": "M G Road",
                "c": "Bangalore",
                "lo": 77.586004,
                "la": 12.994117,
                "az": "M G Road",
                "z": "Central Bangalore"
              },
              "label": "ITC Windsor Bengaluru, A Luxury Collection Hotel",
              "value": "00007581"
            },
            {
              "loc": {
                "a": "Residency Road",
                "c": "Bangalore",
                "lo": 77.595815,
                "la": 12.966887,
                "az": "M G Road",
                "z": "South Bangalore"
              },
              "label": "ITC Gardenia Bengaluru, A Luxury Collection Hotel",
              "value": "00004884"
            },
            {
              "loc": {
                "a": "M G Road",
                "c": "Bangalore",
                "lo": 77.605051,
                "la": 12.975408,
                "az": "M G Road"
              },
              "label": "Ivory Tower",
              "value": "00060615"
            },
            {
              "loc": {
                "a": "Richmond Road",
                "c": "Bangalore",
                "lo": 77.604538,
                "la": 12.961155,
                "az": "M G Road"
              },
              "label": "Temple Tree Studios",
              "value": "00085628"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.64331,
                "la": 12.778872,
                "az": "Electronic City"
              },
              "label": "Hotel R.V International",
              "value": "00056189"
            },
            {
              "loc": {
                "a": "Jayanagar",
                "c": "Bangalore",
                "lo": 77.585931,
                "la": 12.929382,
                "az": "Jayanagar"
              },
              "label": "The Corporate Comforts",
              "value": "00017514"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.632458,
                "la": 12.932693,
                "az": "Hebbal"
              },
              "label": "Nandu Associates - Manyata Tech Park",
              "value": "00072988"
            },
            {
              "loc": {
                "a": "M G Road",
                "c": "Bangalore",
                "lo": 77.609971,
                "la": 12.968929,
                "az": "M G Road"
              },
              "label": "Hotel Ozone",
              "value": "00059571"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.541568,
                "la": 12.977168,
                "az": "Gandhi Nagar"
              },
              "label": "J.M Comforts",
              "value": "00083493"
            },
            {
              "loc": {
                "a": "Yelahanka",
                "c": "Bangalore",
                "lo": 77.600321,
                "la": 13.104858,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Narayana Comforts",
              "value": "00011119"
            },
            {
              "loc": {
                "a": "Hsr Layout",
                "c": "Bangalore",
                "lo": 77.638448,
                "la": 12.912701,
                "az": "Koramangala"
              },
              "label": "RedStone Villa and Suites",
              "value": "00109194"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.527653,
                "la": 12.834691,
                "az": "Outskirts"
              },
              "label": "Urban Valley",
              "value": "00055514"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.568264,
                "la": 12.973995,
                "az": "Gandhi Nagar"
              },
              "label": "Subha Residency",
              "value": "00058360"
            },
            {
              "loc": {
                "a": "Mahadevapura Post",
                "c": "Bangalore",
                "lo": 77.695519,
                "la": 12.978666,
                "az": "Marathahalli"
              },
              "label": "Magic Inn",
              "value": "00019676"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.611547,
                "la": 12.918406,
                "az": "Koramangala"
              },
              "label": "Ocean Inn Hotel",
              "value": "00055509"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.65229,
                "la": 13.188293,
                "az": "Bengaluru International Airport Road",
                "z": "North Bangalore"
              },
              "label": "Fantasy Golf Resort",
              "value": "00000735"
            },
            {
              "loc": {
                "a": "Sarjapur Road",
                "c": "Bangalore",
                "lo": 77.701408,
                "la": 12.899701,
                "az": "Koramangala"
              },
              "label": "Ivy Rossa Four Seasons Hotel And Resort",
              "value": "00062060"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.63791,
                "la": 12.980614,
                "az": "Indira Nagar"
              },
              "label": "Ivory Indiranagar",
              "value": "00096675"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Yeshwanthpur"
              },
              "label": "Jiwi rooms BudgetStays668",
              "value": "00109702"
            },
            {
              "loc": {
                "a": "Double Road",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Jayanagar"
              },
              "label": "Jiwi rooms BudgetStays641",
              "value": "00109682"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Yeshwanthpur"
              },
              "label": "Jiwi rooms BudgetStays618",
              "value": "00109666"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Outskirts"
              },
              "label": "Jiwi rooms BudgetStays610",
              "value": "00109658"
            },
            {
              "loc": {
                "a": "Race Course Road",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Gandhi Nagar"
              },
              "label": "Jiwi rooms BudgetStays586",
              "value": "00109637"
            },
            {
              "loc": {
                "a": "Bannerghatta Road",
                "c": "Bangalore",
                "lo": 0,
                "la": 0
              },
              "label": "Jiwi rooms BudgetStays137",
              "value": "00108150"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.627422,
                "la": 12.928869,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "Grand Mercure Bangalore - An Accor Hotels Brand",
              "value": "00004456"
            },
            {
              "loc": {
                "a": "Btm Layout Stage 1",
                "c": "Bangalore",
                "lo": 77.612372,
                "la": 12.917407
              },
              "label": "Orel Inn",
              "value": "00011181"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Apartel",
              "value": "00030666"
            },
            {
              "loc": {
                "a": "Domlur",
                "c": "Bangalore",
                "lo": 77.63492,
                "la": 12.962644
              },
              "label": "Treebo Trip Roxel Inn",
              "value": "00124300"
            },
            {
              "loc": {
                "a": "R T Nagar",
                "c": "Bangalore",
                "lo": 77.593253,
                "la": 13.025499,
                "az": "Hebbal",
                "z": "East Bangalore"
              },
              "label": "The Kings-10 (Luxury Serviced Suites)",
              "value": "00006513"
            },
            {
              "loc": {
                "a": "R T Nagar",
                "c": "Bangalore",
                "lo": 77.591646,
                "la": 13.017342,
                "az": "Hebbal",
                "z": "East Bangalore"
              },
              "label": "Eden Park Residency",
              "value": "00004000"
            },
            {
              "loc": {
                "a": "Madiwala",
                "c": "Bangalore",
                "lo": 77.617622,
                "la": 12.925756,
                "az": "Koramangala"
              },
              "label": "iNest Suites",
              "value": "00102559"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.601111,
                "la": 12.916389
              },
              "label": "TripStays2237",
              "value": "00135392"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.570278,
                "la": 12.973611
              },
              "label": "TripStays1834",
              "value": "00135393"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.585833,
                "la": 12.929444
              },
              "label": "TripStays1832",
              "value": "00135386"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.700833,
                "la": 12.952778
              },
              "label": "TripStays1811",
              "value": "00135385"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.575833,
                "la": 12.970278
              },
              "label": "TripStays1753",
              "value": "00135384"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.63,
                "la": 12.938333
              },
              "label": "TripStays1744",
              "value": "00135376"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.630278,
                "la": 12.929722
              },
              "label": "TripStays1736",
              "value": "00135374"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.595278,
                "la": 12.945556
              },
              "label": "TripStays1728",
              "value": "00135369"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.593333,
                "la": 12.941389
              },
              "label": "TripStays1727",
              "value": "00135368"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.516944,
                "la": 13.041389
              },
              "label": "TripStays1721",
              "value": "00135364"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.5712,
                "la": 13.02877
              },
              "label": "TripStays1718",
              "value": "00135362"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.570278,
                "la": 13.030278
              },
              "label": "TripStays1717",
              "value": "00135361"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.573056,
                "la": 12.971667
              },
              "label": "TripStays1716",
              "value": "00135360"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.573056,
                "la": 12.971667
              },
              "label": "TripStays1715",
              "value": "00135359"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.565278,
                "la": 12.966944
              },
              "label": "TripStays1709",
              "value": "00135353"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.577477,
                "la": 12.959789
              },
              "label": "TripStays1693",
              "value": "00135677"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.577792,
                "la": 12.960298
              },
              "label": "TripStays1691",
              "value": "00135673"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.558989,
                "la": 13.029202
              },
              "label": "TripStays1690",
              "value": "00135672"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.575833,
                "la": 12.970278
              },
              "label": "TripStays1685",
              "value": "00135664"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.57429,
                "la": 12.974164
              },
              "label": "TripStays1680",
              "value": "00135658"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.575833,
                "la": 12.978889
              },
              "label": "TripStays1678",
              "value": "00135655"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.623113,
                "la": 12.933359,
                "az": "Gandhi Nagar"
              },
              "label": "Sukh Sagar Restaurant",
              "value": "00059365"
            },
            {
              "loc": {
                "a": "Ulsoor",
                "c": "Bangalore",
                "lo": 77.619881,
                "la": 12.973239,
                "az": "M G Road",
                "z": "South Bangalore"
              },
              "label": "Taj MG Road, Bengaluru",
              "value": "00001751"
            },
            {
              "loc": {
                "a": "Yelahanka",
                "c": "Bangalore",
                "lo": 77.639502,
                "la": 12.96685,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Lahe Lahe Mane",
              "value": "00123666"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.61011,
                "la": 12.933947,
                "az": "Koramangala"
              },
              "label": "Hotel GS Suites",
              "value": "00123020"
            },
            {
              "loc": {
                "a": "Bannerghatta Road",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Koramangala"
              },
              "label": "Savoury Suites",
              "value": "00020702"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.6256,
                "la": 12.93429,
                "az": "Koramangala"
              },
              "label": "Hotel Mint Downtown",
              "value": "00094842"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 12.999163,
                "la": 77.58291,
                "az": "Gandhi Nagar"
              },
              "label": "The Orchard Suites",
              "value": "00177374"
            },
            {
              "loc": {
                "a": "Mahadevapura Post",
                "c": "Bangalore",
                "lo": 77.6708,
                "la": 12.96313,
                "az": "Marathahalli"
              },
              "label": "Pride Homes",
              "value": "00177563"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.73777,
                "la": 12.987107,
                "az": "Whitefield",
                "z": "East Bangalore"
              },
              "label": "Vivanta Bengaluru, Whitefield",
              "value": "00004335"
            },
            {
              "loc": {
                "a": "Domlur",
                "c": "Bangalore",
                "lo": 77.642049,
                "la": 12.957051,
                "az": "Indira Nagar",
                "z": "East Bangalore"
              },
              "label": "Niche Suite",
              "value": "00007068"
            },
            {
              "loc": {
                "a": "Old Airport Road",
                "c": "Bangalore",
                "lo": 77.648496,
                "la": 12.960146,
                "az": "Indira Nagar",
                "z": "East Bangalore"
              },
              "label": "The Leela Palace Bangalore",
              "value": "00001041"
            },
            {
              "loc": {
                "a": "Residency Road",
                "c": "Bangalore",
                "lo": 77.608709,
                "la": 12.972332,
                "az": "M G Road",
                "z": "South Bangalore"
              },
              "label": "Vivanta Bengaluru Residency Road",
              "value": "00001762"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.61,
                "la": 13.148664,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Sports icon Suites",
              "value": "00177377"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.576889,
                "la": 12.977671,
                "az": "Gandhi Nagar",
                "z": "West Bangalore"
              },
              "label": "Asha Regent",
              "value": "00002173"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.41235,
                "la": 13.169124,
                "az": "Outskirts"
              },
              "label": "Aadya Resort",
              "value": "00102204"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.742755,
                "la": 12.955975,
                "az": "Whitefield"
              },
              "label": "Transtree",
              "value": "00020725"
            },
            {
              "loc": {
                "a": "Banashankari",
                "c": "Bangalore",
                "lo": 77.5793,
                "la": 12.985534,
                "az": "Jayanagar"
              },
              "label": "Hotel Abhishek",
              "value": "00014642"
            },
            {
              "loc": {
                "a": "Race Course Road",
                "c": "Bangalore",
                "lo": 77.576577,
                "la": 12.983944,
                "az": "Gandhi Nagar"
              },
              "label": "Renaissance Bengaluru Race Course Hotel",
              "value": "00141299"
            },
            {
              "loc": {
                "a": "Outer Ring Road",
                "c": "Bangalore",
                "lo": 77.695193,
                "la": 12.937162,
                "az": "Marathahalli"
              },
              "label": "Aloft Bengaluru Cessna Business Park",
              "value": "00018757"
            },
            {
              "loc": {
                "a": "Ejipura",
                "c": "Bangalore",
                "lo": 77.630459,
                "la": 12.94321,
                "az": "Koramangala"
              },
              "label": "Compact - Green View Homes - Guest House",
              "value": "00126009"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.728357,
                "la": 12.979465,
                "az": "Whitefield"
              },
              "label": "Bengaluru Marriott Hotel Whitefield",
              "value": "00015466"
            },
            {
              "loc": {
                "a": "M G Road",
                "c": "Bangalore",
                "lo": 77.594871,
                "la": 12.972006,
                "az": "M G Road"
              },
              "label": "JW Marriott Hotel Bengaluru",
              "value": "00015460"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.751985,
                "la": 12.979358,
                "az": "Whitefield"
              },
              "label": "Four Points by Sheraton Bengaluru",
              "value": "00019695"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Outskirts"
              },
              "label": "Kanva Resort",
              "value": "00062604"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.608704,
                "la": 12.970228,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "16 Squares",
              "value": "00005490"
            },
            {
              "loc": {
                "a": "Kodihalli",
                "c": "Bangalore",
                "lo": 12.965076,
                "la": 77.649353,
                "az": "Indira Nagar"
              },
              "label": "Copper Quilt - Guest House",
              "value": "00126019"
            },
            {
              "loc": {
                "a": "Residency Road",
                "c": "Bangalore",
                "lo": 77.601586,
                "la": 12.967671,
                "az": "M G Road"
              },
              "label": "The Ritz-Carlton Bangalore",
              "value": "00015461"
            },
            {
              "loc": {
                "a": "Sarjapur Road",
                "c": "Bangalore",
                "lo": 77.665073,
                "la": 12.919184,
                "az": "Koramangala"
              },
              "label": "DoubleTree Suites by Hilton Hotel Bangalore",
              "value": "00079521"
            },
            {
              "loc": {
                "a": "Banaswadi",
                "c": "Bangalore",
                "lo": 77.633873,
                "la": 13.027827,
                "az": "Hebbal"
              },
              "label": "Royal Hotel Apartments",
              "value": "00061671"
            },
            {
              "loc": {
                "a": "Richmond Road",
                "c": "Bangalore",
                "lo": 77.593911,
                "la": 12.967351,
                "az": "M G Road"
              },
              "label": "ibis Bengaluru City Centre - An AccorHotels Brand",
              "value": "00020485"
            },
            {
              "loc": {
                "a": "Bellandur",
                "c": "Bangalore",
                "lo": 77.683366,
                "la": 12.929706,
                "az": "Marathahalli",
                "z": "South Bangalore"
              },
              "label": "ibis Bengaluru Techpark - An AccorHotels Brand",
              "value": "00006973"
            },
            {
              "loc": {
                "a": "Infantry Road",
                "c": "Bangalore",
                "lo": 77.588209,
                "la": 12.99195,
                "az": "M G Road"
              },
              "label": "Shangri-La Hotel Bengaluru",
              "value": "00079593"
            },
            {
              "loc": {
                "a": "Bellandur",
                "c": "Bangalore",
                "lo": 77.683098,
                "la": 12.92969,
                "az": "Marathahalli"
              },
              "label": "Novotel Bengaluru Techpark- An AccorHotels Brand",
              "value": "00006974"
            },
            {
              "loc": {
                "a": "Rajaji Nagar",
                "c": "Bangalore",
                "lo": 77.55944,
                "la": 12.983203,
                "az": "Yeshwanthpur"
              },
              "label": "Fairfield by Marriott Bengaluru Rajajinagar",
              "value": "00015551"
            },
            {
              "loc": {
                "a": "R T Nagar",
                "c": "Bangalore",
                "lo": 77.716559,
                "la": 13.024665,
                "az": "Hebbal"
              },
              "label": "Royal Residency",
              "value": "00065006"
            },
            {
              "loc": {
                "a": "Bellandur",
                "c": "Bangalore",
                "lo": 77.682533,
                "la": 12.927874,
                "az": "Marathahalli"
              },
              "label": "Fairfield by Marriott Bengaluru Outer Ring Road",
              "value": "00061672"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.570273,
                "la": 12.973311,
                "z": "West Bangalore"
              },
              "label": "U.G.ROYAL",
              "value": "00004788"
            },
            {
              "loc": {
                "a": "Hosur Main Road",
                "c": "Bangalore",
                "lo": 77.631984,
                "la": 12.900635,
                "az": "Electronic City"
              },
              "label": "ibis Bengaluru Hosur Road - An AccorHotels Brand",
              "value": "00011037"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.555677,
                "la": 13.020376,
                "az": "Yeshwanthpur"
              },
              "label": "Best Rooms",
              "value": "00046199"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.574289,
                "la": 12.974165
              },
              "label": "Snt Comforts",
              "value": "00060991"
            },
            {
              "loc": {
                "a": "Old Airport Road",
                "c": "Bangalore",
                "lo": 77.64559,
                "la": 12.948438,
                "az": "Indira Nagar"
              },
              "label": "Hilton Bangalore Embassy GolfLinks",
              "value": "00079595"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.649362,
                "la": 12.957591,
                "az": "Bengaluru International Airport Road",
                "z": "East Bangalore"
              },
              "label": "Classic Homes",
              "value": "00010152"
            },
            {
              "loc": {
                "a": "Kalasipalyam",
                "c": "Bangalore",
                "lo": 77.54554,
                "la": 12.95953
              },
              "label": "The Lounge",
              "value": "00141838"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.567181,
                "la": 12.999028
              },
              "label": "Emerald Green",
              "value": "00053921"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.576484,
                "la": 12.979177,
                "az": "Gandhi Nagar"
              },
              "label": "Saroj Palace",
              "value": "00031003"
            },
            {
              "loc": {
                "a": "Ulsoor",
                "c": "Bangalore",
                "lo": 77.620461,
                "la": 12.975503
              },
              "label": "Conrad",
              "value": "00112468"
            },
            {
              "loc": {
                "a": "Jalahalli",
                "c": "Bangalore",
                "lo": 77.520764,
                "la": 13.04358,
                "az": "Yeshwanthpur"
              },
              "label": "Hotel Premier Comforts",
              "value": "00011529"
            },
            {
              "loc": {
                "a": "Amruthahalli",
                "c": "Bangalore",
                "lo": 77.598314,
                "la": 13.070404
              },
              "label": "Resside Serviced Apartments",
              "value": "00145266"
            },
            {
              "loc": {
                "a": "B T M Layout",
                "c": "Bangalore",
                "lo": 77.604387,
                "la": 12.916551,
                "az": "Koramangala"
              },
              "label": "Hotel Vasavi Residency",
              "value": "00017448"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.573713,
                "la": 12.978784
              },
              "label": "Hotel Espee Residency",
              "value": "00053347"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.732693,
                "la": 12.990218,
                "az": "Whitefield",
                "z": "East Bangalore"
              },
              "label": "Aloft Bengaluru Whitefield",
              "value": "00005759"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Gandhi Nagar"
              },
              "label": "Jiwi rooms BudgetStays614",
              "value": "00109662"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 0,
                "la": 0
              },
              "label": "Jiwi rooms BudgetStays609",
              "value": "00109657"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 0,
                "la": 0
              },
              "label": "Jiwi rooms BudgetStays114",
              "value": "00108141"
            },
            {
              "loc": {
                "a": "Seshadripuram",
                "c": "Bangalore",
                "lo": 0,
                "la": 0
              },
              "label": "Jiwi rooms BudgetStays087",
              "value": "00108121"
            },
            {
              "loc": {
                "a": "Seshadripuram",
                "c": "Bangalore",
                "lo": 0,
                "la": 0
              },
              "label": "Jiwi rooms BudgetStays086",
              "value": "00108120"
            },
            {
              "loc": {
                "a": "Madiwala",
                "c": "Bangalore",
                "lo": 77.615954,
                "la": 12.923562,
                "az": "Koramangala"
              },
              "label": "New Golden Regency",
              "value": "00011168"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.577354,
                "la": 12.977098,
                "az": "Gandhi Nagar"
              },
              "label": "Sri Durgamb Lodge",
              "value": "00053314"
            },
            {
              "loc": {
                "a": "Yelahanka",
                "c": "Bangalore",
                "lo": 77.5833,
                "la": 12.9833,
                "az": "Bengaluru International Airport Road",
                "z": "North Bangalore"
              },
              "label": "Tranquil Suites Serviced Apartment",
              "value": "00004460"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.576588,
                "la": 12.978997,
                "az": "Gandhi Nagar"
              },
              "label": "Hotel Likhith International",
              "value": "00011252"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.574881,
                "la": 12.980312,
                "az": "Gandhi Nagar"
              },
              "label": "Hotel Kapila",
              "value": "00030982"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.599125,
                "la": 13.05324,
                "az": "Hebbal"
              },
              "label": "Pool View Residence",
              "value": "00016338"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.645581,
                "la": 12.906054,
                "az": "Outskirts"
              },
              "label": "Shantana Lodge",
              "value": "00016996"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.711562,
                "la": 12.963364,
                "az": "Whitefield"
              },
              "label": "Parkwood monarch",
              "value": "00016330"
            },
            {
              "loc": {
                "a": "Ulsoor",
                "c": "Bangalore",
                "lo": 77.615503,
                "la": 12.984596,
                "az": "M G Road"
              },
              "label": "Atithi Grand Guest House",
              "value": "00014452"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.57,
                "la": 12.98,
                "az": "Gandhi Nagar"
              },
              "label": "Devashree Comforts",
              "value": "00102564"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.638272,
                "la": 12.803419,
                "az": "Electronic City"
              },
              "label": "Xplore Adventure",
              "value": "00061796"
            },
            {
              "loc": {
                "a": "Hsr Layout",
                "c": "Bangalore",
                "lo": 77.62916,
                "la": 12.915902,
                "az": "Koramangala"
              },
              "label": "The Essence Suites",
              "value": "00031906"
            },
            {
              "loc": {
                "a": "Double Road",
                "c": "Bangalore",
                "lo": 77.572424,
                "la": 12.974557,
                "az": "Jayanagar"
              },
              "label": "Sanman Residency Lodge",
              "value": "00059790"
            },
            {
              "loc": {
                "a": "Richmond Road",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "M G Road"
              },
              "label": "Jiwi rooms BudgetStays613",
              "value": "00109661"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 0,
                "la": 0
              },
              "label": "Jiwi rooms BudgetStays092",
              "value": "00108126"
            },
            {
              "loc": {
                "a": "Seshadripuram",
                "c": "Bangalore",
                "lo": 0,
                "la": 0
              },
              "label": "Jiwi rooms BudgetStays085",
              "value": "00108119"
            },
            {
              "loc": {
                "a": "Malleshwaram",
                "c": "Bangalore",
                "lo": 0,
                "la": 0
              },
              "label": "Jiwi rooms BudgetStays084",
              "value": "00108118"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.580062,
                "la": 12.972176
              },
              "label": "Sri Manju Lodge",
              "value": "00054243"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.575276,
                "la": 12.978316,
                "az": "Gandhi Nagar"
              },
              "label": "Royal Regency Lodge",
              "value": "00020747"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.626593,
                "la": 13.057308,
                "az": "Hebbal"
              },
              "label": "Bulande Hospitality Services",
              "value": "00034144"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.578092,
                "la": 12.975961,
                "az": "Gandhi Nagar"
              },
              "label": "Kamat Yatrinivas Gandhi Nagar",
              "value": "00017509"
            },
            {
              "loc": {
                "a": "Seshadripuram",
                "c": "Bangalore",
                "lo": 77.572537,
                "la": 12.989409,
                "az": "Yeshwanthpur"
              },
              "label": "Hotel Vittal Regency",
              "value": "00020760"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.577466,
                "la": 12.979013,
                "az": "Gandhi Nagar"
              },
              "label": "Suvidh Comforts",
              "value": "00059309"
            },
            {
              "loc": {
                "a": "Seshadripuram",
                "c": "Bangalore",
                "lo": 77.578637,
                "la": 12.98708
              },
              "label": "Pranam Comforts Lodge",
              "value": "00058076"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.53,
                "la": 13,
                "az": "Yeshwanthpur"
              },
              "label": "Sun City Lodge",
              "value": "00104755"
            },
            {
              "loc": {
                "a": "Jayanagar",
                "c": "Bangalore",
                "lo": 77.626964,
                "la": 12.938495,
                "az": "Jayanagar"
              },
              "label": "Bangalore service apartments",
              "value": "00016370"
            },
            {
              "loc": {
                "a": "Kalyan Nagar",
                "c": "Bangalore",
                "lo": 77.641336,
                "la": 13.02437,
                "az": "Hebbal"
              },
              "label": "Noah's Inn",
              "value": "00020791"
            },
            {
              "loc": {
                "a": "J P Nagar",
                "c": "Bangalore",
                "lo": 77.597987,
                "la": 12.916633
              },
              "label": "Raja Galaxy",
              "value": "00059159"
            },
            {
              "loc": {
                "a": "R T Nagar",
                "c": "Bangalore",
                "lo": 77.592994,
                "la": 12.949362,
                "az": "Hebbal"
              },
              "label": "Hotel Garden City",
              "value": "00046004"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.576998,
                "la": 12.97854,
                "az": "Gandhi Nagar"
              },
              "label": "Shobha Deluxe Lodge",
              "value": "00021472"
            },
            {
              "loc": {
                "a": "Tumkur Road",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Yeshwanthpur"
              },
              "label": "Jiwi rooms BudgetStays633",
              "value": "00109674"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.627474,
                "la": 12.940818,
                "az": "Koramangala",
                "z": "South Bangalore"
              },
              "label": "Easy Stay",
              "value": "00002596"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.618428,
                "la": 12.973572,
                "az": "Yeshwanthpur"
              },
              "label": "Hotel Thai Deluxe",
              "value": "00016145"
            },
            {
              "loc": {
                "a": "Madiwala",
                "c": "Bangalore",
                "lo": 77.61,
                "la": 12.92,
                "az": "Koramangala"
              },
              "label": "Hotel Golden Nest",
              "value": "00098070"
            },
            {
              "loc": {
                "a": "Seshadripuram",
                "c": "Bangalore",
                "lo": 77.570837,
                "la": 12.993869,
                "az": "Yeshwanthpur"
              },
              "label": "Hotel Sheltron",
              "value": "00011296"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.55,
                "la": 13.01,
                "az": "Yeshwanthpur"
              },
              "label": "Grand Arabian Hotel",
              "value": "00177210"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.499592,
                "la": 13.008511,
                "az": "Outskirts"
              },
              "label": "Vishwas Deluxe Lodge",
              "value": "00060542"
            },
            {
              "loc": {
                "a": "R T Nagar",
                "c": "Bangalore",
                "lo": 77.708872,
                "la": 12.981757,
                "az": "Hebbal"
              },
              "label": "Otel",
              "value": "00027459"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.599375,
                "la": 12.897091,
                "z": "West Bangalore"
              },
              "label": "Hotel Sree Sai Comforts",
              "value": "00005313"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.573658,
                "la": 12.934612,
                "z": "South Bangalore"
              },
              "label": "Transit Living K R Road",
              "value": "00008366"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.48,
                "la": 12.91,
                "az": "Outskirts"
              },
              "label": "Siesta Aqua Greens",
              "value": "00103076"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.619823,
                "la": 13.148032,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Hotel Airport Comfort",
              "value": "00080164"
            },
            {
              "loc": {
                "a": "Malleshwaram",
                "c": "Bangalore",
                "lo": 77.569941,
                "la": 13.000201,
                "az": "Yeshwanthpur"
              },
              "label": "Kumara Guest Inn",
              "value": "00048330"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.6,
                "la": 13.05,
                "az": "Hebbal"
              },
              "label": "Madisons Suites",
              "value": "00102273"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.760015,
                "la": 12.992713,
                "az": "Koramangala"
              },
              "label": "GMR Residency",
              "value": "00020845"
            },
            {
              "loc": {
                "a": "Double Road",
                "c": "Bangalore",
                "lo": 77.57358,
                "la": 12.92065,
                "az": "Jayanagar"
              },
              "label": "Sahana Residency",
              "value": "00061046"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.573169,
                "la": 12.970721
              },
              "label": "Hotel Satyam Lodge",
              "value": "00065226"
            },
            {
              "loc": {
                "a": "Old Airport Road",
                "c": "Bangalore",
                "lo": 77.643425,
                "la": 12.959297,
                "az": "Indira Nagar",
                "z": "East Bangalore"
              },
              "label": "Roxel Inn Express  Diamond  District",
              "value": "00004359"
            },
            {
              "loc": {
                "a": "Hosur Main Road",
                "c": "Bangalore",
                "lo": 77.616671,
                "la": 12.926386,
                "az": "Koramangala"
              },
              "label": "Royal Comfort Park",
              "value": "00038015"
            },
            {
              "loc": {
                "a": "K R Road",
                "c": "Bangalore",
                "lo": 77.576669,
                "la": 12.971454
              },
              "label": "Hotel Shalimar",
              "value": "00056753"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.555086,
                "la": 13.01456,
                "az": "Gandhi Nagar"
              },
              "label": "Hotel Pawanshree",
              "value": "00068821"
            },
            {
              "loc": {
                "a": "Kalyan Nagar",
                "c": "Bangalore",
                "lo": 77.593386,
                "la": 12.991271,
                "az": "Hebbal"
              },
              "label": "Hotel Vasthan Comfort Inn",
              "value": "00066829"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.573125,
                "la": 12.971719
              },
              "label": "Pai Vihar Lodging and Boarding",
              "value": "00032755"
            },
            {
              "loc": {
                "a": "Rajaji Nagar",
                "c": "Bangalore",
                "lo": 77.554217,
                "la": 13.020883,
                "az": "Yeshwanthpur"
              },
              "label": "Sahara Lodge",
              "value": "00046968"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.578395,
                "la": 12.976967,
                "az": "Gandhi Nagar"
              },
              "label": "Sri Sai Yatrinivas",
              "value": "00053438"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.576587,
                "la": 12.975328
              },
              "label": "Paradise Lodge",
              "value": "00055623"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.437161,
                "la": 13.10337,
                "az": "Outskirts"
              },
              "label": "Bgrows Kanva Resort",
              "value": "00046317"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.574837,
                "la": 12.97773,
                "az": "Gandhi Nagar"
              },
              "label": "Manjusri Paradise",
              "value": "00031124"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.57768,
                "la": 12.96211
              },
              "label": "Bluestar Lodge",
              "value": "00060961"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.576231,
                "la": 12.957213
              },
              "label": "White Fort Lodge",
              "value": "00046439"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.55381,
                "la": 13.022464,
                "az": "Yeshwanthpur"
              },
              "label": "Citizen Boarding and lodging",
              "value": "00046203"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.602382,
                "la": 12.942333
              },
              "label": "Hotel Raj",
              "value": "00031178"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.54,
                "la": 12.99,
                "az": "Hebbal"
              },
              "label": "Rudhi Suites",
              "value": "00102439"
            },
            {
              "loc": {
                "a": "Yelahanka",
                "c": "Bangalore",
                "lo": 77.62,
                "la": 13.12,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Vijays Inn Service Apartment",
              "value": "00102679"
            },
            {
              "loc": {
                "a": "B T M Layout",
                "c": "Bangalore",
                "lo": 77.616609,
                "la": 12.922679,
                "az": "Koramangala"
              },
              "label": "VISTAAHOMESTAY",
              "value": "00059755"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.55635,
                "la": 13.020933,
                "az": "Yeshwanthpur"
              },
              "label": "CM Deluxe Lodge",
              "value": "00046184"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.575517,
                "la": 12.976423,
                "az": "Gandhi Nagar"
              },
              "label": "Hotel Ratnams Lodge",
              "value": "00031108"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.608709,
                "la": 12.972332
              },
              "label": "Hotel Residency",
              "value": "00031052"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.59952,
                "la": 12.897225,
                "az": "Electronic City"
              },
              "label": "The Mansion",
              "value": "00016372"
            },
            {
              "loc": {
                "a": "Madiwala",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Koramangala"
              },
              "label": "Second House",
              "value": "00102973"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.659683,
                "la": 12.840731,
                "az": "Indira Nagar"
              },
              "label": "City Cradle Hotel",
              "value": "00019562"
            },
            {
              "loc": {
                "a": "Ramamurthy Nagar",
                "c": "Bangalore",
                "lo": 77.66,
                "la": 13,
                "az": "Hebbal"
              },
              "label": "Prince Service Apartment",
              "value": "00102208"
            },
            {
              "loc": {
                "a": "Hsr Layout",
                "c": "Bangalore",
                "lo": 77.592431,
                "la": 13.058855,
                "az": "Koramangala"
              },
              "label": "Moon Suites apartments",
              "value": "00020748"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.575817,
                "la": 12.978317,
                "az": "Gandhi Nagar"
              },
              "label": "C.S. Residency Lodge",
              "value": "00046301"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.575266,
                "la": 12.979576,
                "az": "Gandhi Nagar"
              },
              "label": "Akshaya Residency Grand Lotus",
              "value": "00096450"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.553584,
                "la": 13.027365,
                "az": "Gandhi Nagar"
              },
              "label": "BK Lodge",
              "value": "00046187"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.576283,
                "la": 12.977017,
                "az": "Gandhi Nagar"
              },
              "label": "Nataraj Comforts",
              "value": "00046275"
            },
            {
              "loc": {
                "a": "Mathikere",
                "c": "Bangalore",
                "lo": 77.562042,
                "la": 13.030615,
                "az": "Yeshwanthpur"
              },
              "label": "Golden Nest Lodge",
              "value": "00046210"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.575206,
                "la": 12.977255,
                "az": "Gandhi Nagar"
              },
              "label": "Hotel Aruna Anandh",
              "value": "00031133"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 0,
                "la": 0
              },
              "label": "Lucky Lodge",
              "value": "00057565"
            },
            {
              "loc": {
                "a": "Madiwala",
                "c": "Bangalore",
                "lo": 77.596834,
                "la": 12.944706,
                "az": "Koramangala"
              },
              "label": "Hotel Floral Park",
              "value": "00055854"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.71,
                "la": 13.24,
                "az": "Outskirts"
              },
              "label": "Jade Lotus Villa 418",
              "value": "00107279"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.6,
                "la": 12.915
              },
              "label": "Aaccord Suites Inn",
              "value": "00177202"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.575252,
                "la": 12.9482
              },
              "label": "Delhi Bhavan Lodge",
              "value": "00031565"
            },
            {
              "loc": {
                "a": "Doddaballapur Main Road",
                "c": "Bangalore",
                "lo": 77.568956,
                "la": 13.15239
              },
              "label": "RAJ KAMAL STAY INN",
              "value": "00176618"
            },
            {
              "loc": {
                "a": "Indira Nagar",
                "c": "Bangalore",
                "lo": 77.383737,
                "la": 13.096527,
                "az": "Indira Nagar"
              },
              "label": "Yatrik Comforts",
              "value": "00136438"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.576944,
                "la": 12.979167
              },
              "label": "TripStays1670",
              "value": "00135641"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.577613,
                "la": 12.994914,
                "az": "Gandhi Nagar"
              },
              "label": "Sri Comforts Deluxe Lodge",
              "value": "00031060"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.497699,
                "la": 12.907459
              },
              "label": "Royal Residency Suites",
              "value": "00176988"
            },
            {
              "loc": {
                "a": "Domlur",
                "c": "Bangalore",
                "lo": 77.639253,
                "la": 12.953374,
                "az": "Indira Nagar"
              },
              "label": "Redwood Suites",
              "value": "00174820"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 0,
                "la": 0
              },
              "label": "Pink Petal Service Apartment",
              "value": "00157163"
            },
            {
              "loc": {
                "a": "Bannerghatta",
                "c": "Bangalore",
                "lo": 77.598349,
                "la": 12.893151
              },
              "label": "MistyBlue Serviced Apartment",
              "value": "00136236"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.624365,
                "la": 13.041086
              },
              "label": "Jiwirooms Exclusive4588",
              "value": "00144844"
            },
            {
              "loc": {
                "a": "Jayanagar",
                "c": "Bangalore",
                "lo": 77.597882,
                "la": 12.921912,
                "az": "Jayanagar"
              },
              "label": "Jiwirooms Exclusive4587",
              "value": "00144843"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.62,
                "la": 12.942513,
                "az": "Koramangala"
              },
              "label": "Hotel Sanhok",
              "value": "00177564"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.608709,
                "la": 12.972332,
                "az": "Gandhi Nagar"
              },
              "label": "Hotel Regency",
              "value": "00053218"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.542211,
                "la": 13.00956,
                "az": "Gandhi Nagar"
              },
              "label": "Hotel Asha Regent",
              "value": "00087978"
            },
            {
              "loc": {
                "a": "Airport Road",
                "c": "Bangalore",
                "lo": 77.647601,
                "la": 13.178636
              },
              "label": "Hotel Airport City",
              "value": "00174771"
            },
            {
              "loc": {
                "a": "Kalyan Nagar",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Hebbal"
              },
              "label": "Golden Nest Serviced Apartment",
              "value": "00154846"
            },
            {
              "loc": {
                "a": "Kammanahalli",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Hebbal"
              },
              "label": "Golden Guest House",
              "value": "00152523"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 0,
                "la": 0
              },
              "label": "Galaxy Comforts Service Apartment",
              "value": "00157164"
            },
            {
              "loc": {
                "a": "Tavarekere",
                "c": "Bangalore",
                "lo": 77.6095,
                "la": 12.9313
              },
              "label": "Beyond Stay Apple Tree Apartment & Suites",
              "value": "00174786"
            },
            {
              "loc": {
                "a": "Nagvara Palya Road",
                "c": "Bangalore",
                "lo": 77.626573,
                "la": 13.057155,
                "az": "Hebbal"
              },
              "label": "R & S Riveria",
              "value": "00061928"
            },
            {
              "loc": {
                "a": "Malleshwaram",
                "c": "Bangalore",
                "lo": 77.571642,
                "la": 12.994393,
                "az": "Yeshwanthpur"
              },
              "label": "Hotel Skyland",
              "value": "00032108"
            },
            {
              "loc": {
                "a": "Jayanagar",
                "c": "Bangalore",
                "lo": 77.559,
                "la": 13.028438,
                "az": "Jayanagar"
              },
              "label": "Green Tree Comforts",
              "value": "00059264"
            },
            {
              "loc": {
                "a": "Ulsoor",
                "c": "Bangalore",
                "lo": 77.617765,
                "la": 12.977604,
                "az": "M G Road"
              },
              "label": "Bon Cord",
              "value": "00056567"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.525509,
                "la": 13.035657,
                "az": "Outskirts"
              },
              "label": "S.V HOTEL",
              "value": "00045268"
            },
            {
              "loc": {
                "a": "Krishnarajapuram",
                "c": "Bangalore",
                "lo": 77.673931,
                "la": 12.924207
              },
              "label": "Sree Krishna Residency",
              "value": "00045185"
            },
            {
              "loc": {
                "a": "Minerva Circle",
                "c": "Bangalore",
                "lo": 77.589052,
                "la": 12.954765,
                "az": "Jayanagar"
              },
              "label": "Hotel Grand Regency Inn",
              "value": "00046647"
            },
            {
              "loc": {
                "a": "Mathikere",
                "c": "Bangalore",
                "lo": 77.562029,
                "la": 13.029335,
                "az": "Yeshwanthpur"
              },
              "label": "Ashikha Regency Lodge",
              "value": "00045183"
            },
            {
              "loc": {
                "a": "Basavangudi",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Jayanagar"
              },
              "label": "Octave Plaza Hotel",
              "value": "00157272"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.57,
                "la": 12.96
              },
              "label": "Hotel Taiba Regency",
              "value": "00101779"
            },
            {
              "loc": {
                "a": "Seshadripuram",
                "c": "Bangalore",
                "lo": 77.574522,
                "la": 12.985538,
                "az": "Yeshwanthpur"
              },
              "label": "Karavali lodge",
              "value": "00057217"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.6125,
                "la": 12.9375
              },
              "label": "Vijayadri Exotica",
              "value": "00126600"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.603268,
                "la": 12.972789,
                "az": "Whitefield"
              },
              "label": "Sri Satya Sai Developers & Relators",
              "value": "00056799"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.597488,
                "la": 12.944392
              },
              "label": "S.R Guest House",
              "value": "00109572"
            },
            {
              "loc": {
                "a": "Basavangudi",
                "c": "Bangalore",
                "lo": 75.658201,
                "la": 12.433553,
                "az": "Jayanagar"
              },
              "label": "Ram's Hill Top",
              "value": "00062925"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.716654,
                "la": 12.967635,
                "az": "Whitefield"
              },
              "label": "Properto Guest House",
              "value": "00061254"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Gandhi Nagar"
              },
              "label": "Paravathi Palace Lodging",
              "value": "00109568"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.7,
                "la": 12.9
              },
              "label": "Lakshimish Guest House",
              "value": "00106428"
            },
            {
              "loc": {
                "a": "J P Nagar",
                "c": "Bangalore",
                "lo": 77.58,
                "la": 12.91
              },
              "label": "Impana PG",
              "value": "00106427"
            },
            {
              "loc": {
                "a": "Bannerghatta Road",
                "c": "Bangalore",
                "lo": 77.600302,
                "la": 12.92035,
                "az": "Koramangala"
              },
              "label": "Hotel The Blue Ivy",
              "value": "00054256"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.579014,
                "la": 12.968702
              },
              "label": "Hotel Swarna Lodging",
              "value": "00053928"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.594563,
                "la": 12.971599,
                "az": "Outskirts"
              },
              "label": "Hotel Godavari International",
              "value": "00062365"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.631646,
                "la": 12.929244,
                "az": "Hebbal"
              },
              "label": "Alcove - Hennur Road",
              "value": "00031559"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.626573,
                "la": 12.938482,
                "az": "Koramangala"
              },
              "label": "Achates Corporate Services",
              "value": "00024011"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.627033,
                "la": 12.974633,
                "az": "Hebbal"
              },
              "label": "Kalarikkal Homes",
              "value": "00023999"
            },
            {
              "loc": {
                "a": "Krishnarajapuram",
                "c": "Bangalore",
                "lo": 77.69687,
                "la": 13.00906
              },
              "label": "Nisarga lodge",
              "value": "00059699"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.571297,
                "la": 13.02852,
                "az": "Hebbal"
              },
              "label": "Aishwarya Comfort",
              "value": "00047129"
            },
            {
              "loc": {
                "a": "Madiwala",
                "c": "Bangalore",
                "lo": 77.579377,
                "la": 12.978079,
                "az": "Koramangala"
              },
              "label": "Golden Residency Guest House",
              "value": "00011170"
            },
            {
              "loc": {
                "a": "Infantry Road",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "M G Road"
              },
              "label": "Sahara Guest House",
              "value": "00101777"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.61,
                "la": 12.92,
                "az": "Electronic City"
              },
              "label": "Crown Boarding & Lodging",
              "value": "00101778"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.57605,
                "la": 12.97838,
                "az": "Gandhi Nagar"
              },
              "label": "Sri Kenchamba Lodge 1",
              "value": "00061100"
            },
            {
              "loc": {
                "a": "J P Nagar",
                "c": "Bangalore",
                "lo": 77.644471,
                "la": 13.056055
              },
              "label": "Karunya Residency",
              "value": "00020656"
            },
            {
              "loc": {
                "a": "Seshadripuram",
                "c": "Bangalore",
                "lo": 77.571831,
                "la": 12.988013,
                "az": "Yeshwanthpur"
              },
              "label": "Hotel Goupee's Regency",
              "value": "00020762"
            },
            {
              "loc": {
                "a": "Madiwala",
                "c": "Bangalore",
                "lo": 77.61242,
                "la": 12.932394,
                "az": "Koramangala"
              },
              "label": "Cassia Inn",
              "value": "00011167"
            },
            {
              "loc": {
                "a": "Marathahalli",
                "c": "Bangalore",
                "lo": 77.708735,
                "la": 12.957341,
                "az": "Marathahalli"
              },
              "label": "Compact Panache - Guest House",
              "value": "00126016"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.57,
                "la": 12.97,
                "az": "Gandhi Nagar"
              },
              "label": "Sri Sai Logde",
              "value": "00102560"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Outskirts"
              },
              "label": "Raashi Farm",
              "value": "00062320"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Gandhi Nagar"
              },
              "label": "Living Space Bootique",
              "value": "00061899"
            },
            {
              "loc": {
                "a": "Peenya Industrial Estate",
                "c": "Bangalore",
                "lo": 77.5405,
                "la": 13.0291,
                "az": "Yeshwanthpur"
              },
              "label": "Iconics Hotel",
              "value": "00118401"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 75.138212,
                "la": 15.352338,
                "az": "Gandhi Nagar"
              },
              "label": "Basant Trupti International",
              "value": "00059908"
            },
            {
              "loc": {
                "a": "J P Nagar",
                "c": "Bangalore",
                "lo": 77.598496,
                "la": 12.907673
              },
              "label": "Shravanthi Sarovar Portico",
              "value": "00176625"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.57,
                "la": 12.97,
                "az": "Gandhi Nagar"
              },
              "label": "C.B Deluxe Lodge",
              "value": "00102924"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.614444,
                "la": 12.936944,
                "az": "Koramangala"
              },
              "label": "Octave Studio Koramangala",
              "value": "00126598"
            },
            {
              "loc": {
                "a": "Bommasandra Industrial Area",
                "c": "Bangalore",
                "lo": 77.686993,
                "la": 12.814495,
                "az": "Electronic City"
              },
              "label": "Narayana Studio Apartments",
              "value": "00176842"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.665284,
                "la": 12.845158
              },
              "label": "Star Plaza Lodge",
              "value": "00068539"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.469591,
                "la": 12.902002,
                "az": "Outskirts"
              },
              "label": "Sri Sai Palace",
              "value": "00057005"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.55,
                "la": 12.98,
                "az": "Yeshwanthpur"
              },
              "label": "Sri Devi Lodge",
              "value": "00104758"
            },
            {
              "loc": {
                "a": "Hsr Layout",
                "c": "Bangalore",
                "lo": 77.655784,
                "la": 12.87996,
                "az": "Koramangala"
              },
              "label": "Roo Luxury Boutique Hotel",
              "value": "00087199"
            },
            {
              "loc": {
                "a": "Koramangala",
                "c": "Bangalore",
                "lo": 77.63,
                "la": 12.93
              },
              "label": "Pleasant Suites",
              "value": "00110022"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.57,
                "la": 12.97,
                "az": "Gandhi Nagar"
              },
              "label": "Naga Residency Deluxe Lodge",
              "value": "00104717"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.618552,
                "la": 12.923479,
                "az": "Electronic City"
              },
              "label": "Grand Krishna Lodge  2",
              "value": "00061193"
            },
            {
              "loc": {
                "a": "Jayanagar",
                "c": "Bangalore",
                "lo": 77.59,
                "la": 12.92,
                "az": "Jayanagar"
              },
              "label": "Vijay Lakshmi Residency",
              "value": "00104709"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.55,
                "la": 13.02,
                "az": "Yeshwanthpur"
              },
              "label": "Pavithra Deluxe Suites",
              "value": "00104711"
            },
            {
              "loc": {
                "a": "Madiwala",
                "c": "Bangalore",
                "lo": 77.61,
                "la": 12.92,
                "az": "Koramangala"
              },
              "label": "Varcity Hotels",
              "value": "00097566"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.623228,
                "la": 12.985744,
                "az": "Outskirts"
              },
              "label": "Riviera Residency",
              "value": "00055673"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.62,
                "la": 12.93,
                "az": "Yeshwanthpur"
              },
              "label": "Lifestyle Service Apartments",
              "value": "00098576"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 78.43,
                "la": 17.5,
                "az": "Yeshwanthpur"
              },
              "label": "Balaji Residency",
              "value": "00104756"
            },
            {
              "loc": {
                "a": "Madiwala",
                "c": "Bangalore",
                "lo": 77.617606,
                "la": 12.925764,
                "az": "Koramangala"
              },
              "label": "The Little Libra",
              "value": "00017449"
            },
            {
              "loc": {
                "a": "Marathahalli",
                "c": "Bangalore",
                "lo": 77.655126,
                "la": 12.849216,
                "az": "Marathahalli"
              },
              "label": "Zelo Branded PG",
              "value": "00060580"
            },
            {
              "loc": {
                "a": "Kammanahalli",
                "c": "Bangalore",
                "lo": 77.646822,
                "la": 13.017292,
                "az": "Hebbal"
              },
              "label": "Estancia A Home Apart",
              "value": "00060350"
            },
            {
              "loc": {
                "a": "Seshadripuram",
                "c": "Bangalore",
                "lo": 77.57528,
                "la": 12.97675,
                "az": "Yeshwanthpur"
              },
              "label": "IHM Bengaluru",
              "value": "00147515"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 78.683056,
                "la": 10.795556,
                "az": "Yeshwanthpur"
              },
              "label": "Paragon Heritage",
              "value": "00135231"
            },
            {
              "loc": {
                "a": "Old Airport Road",
                "c": "Bangalore",
                "lo": 77.593421,
                "la": 13.006708,
                "az": "Indira Nagar"
              },
              "label": "Guest House 24/7",
              "value": "00057275"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 77.57,
                "la": 12.97
              },
              "label": "Hotel Akshaya Deluxe Lodge",
              "value": "00103471"
            },
            {
              "loc": {
                "a": "Mathikere",
                "c": "Bangalore",
                "lo": 77.554152,
                "la": 12.988307,
                "az": "Yeshwanthpur"
              },
              "label": "Hotel Prashant",
              "value": "00060493"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.570383,
                "la": 12.974367,
                "az": "Gandhi Nagar"
              },
              "label": "Hotel Sree Lodging",
              "value": "00056797"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.693807,
                "la": 12.996245,
                "az": "Outskirts"
              },
              "label": "Srihari Paying Guest",
              "value": "00061003"
            },
            {
              "loc": {
                "a": "Bellandur",
                "c": "Bangalore",
                "lo": 77.67,
                "la": 12.92,
                "az": "Marathahalli"
              },
              "label": "Ivory Studio One Bellandur",
              "value": "00177167"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.644082,
                "la": 12.959883,
                "az": "Hebbal"
              },
              "label": "Roxel Inn- Hebbal",
              "value": "00004358"
            },
            {
              "loc": {
                "a": "Electronic City",
                "c": "Bangalore",
                "lo": 77.650687,
                "la": 12.838402,
                "az": "Electronic City"
              },
              "label": "YC Grand by Omatra",
              "value": "00176476"
            },
            {
              "loc": {
                "a": "Bannerghatta Road",
                "c": "Bangalore",
                "lo": 77.609288,
                "la": 12.891574
              },
              "label": "TrustedStay Plot # 944/945",
              "value": "00113165"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.576667,
                "la": 12.973133
              },
              "label": "Renuka Lodge",
              "value": "00066758"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.570729,
                "la": 12.976611,
                "az": "Gandhi Nagar"
              },
              "label": "Shiva S Stay",
              "value": "00055666"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.556467,
                "la": 13.020465,
                "az": "Yeshwanthpur"
              },
              "label": "Horizon Deluxe Lodge",
              "value": "00060180"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 76.68,
                "la": 11.82
              },
              "label": "Indraprastha Regency",
              "value": "00107254"
            },
            {
              "loc": {
                "a": "Madiwala",
                "c": "Bangalore",
                "lo": 77.621119,
                "la": 13.000769,
                "az": "Koramangala"
              },
              "label": "Tulip Residency",
              "value": "00057795"
            },
            {
              "loc": {
                "a": "Infantry Road",
                "c": "Bangalore",
                "lo": 77.59,
                "la": 12.98,
                "az": "M G Road"
              },
              "label": "Labamba Suites",
              "value": "00104533"
            },
            {
              "loc": {
                "a": "B T M Layout",
                "c": "Bangalore",
                "lo": 77.61,
                "la": 12.92,
                "az": "Koramangala"
              },
              "label": "Moonlight Residency",
              "value": "00098568"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Bengaluru International Airport Road"
              },
              "label": "The Kaiser International",
              "value": "00102254"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Hebbal"
              },
              "label": "Finesse International Hebbal",
              "value": "00060795"
            },
            {
              "loc": {
                "a": "Seshadripuram",
                "c": "Bangalore",
                "lo": 77.574669,
                "la": 12.9872,
                "az": "Yeshwanthpur"
              },
              "label": "Moderh Hotel",
              "value": "00057133"
            },
            {
              "loc": {
                "a": "Bommasandra Industrial Area",
                "c": "Bangalore",
                "lo": 77.637784,
                "la": 12.923194,
                "az": "Electronic City"
              },
              "label": "Shanthiniketan Homes",
              "value": "00053870"
            },
            {
              "loc": {
                "a": "Hebbal",
                "c": "Bangalore",
                "lo": 77.621443,
                "la": 13.050586,
                "az": "Hebbal"
              },
              "label": "Finesse International Manyata Embassy",
              "value": "00060287"
            },
            {
              "loc": {
                "a": "Rajaji Nagar",
                "c": "Bangalore",
                "lo": 77.55,
                "la": 12.99,
                "az": "Yeshwanthpur"
              },
              "label": "Twin Tower  3 BHK",
              "value": "00107256"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 77.71,
                "la": 13.24,
                "az": "Outskirts"
              },
              "label": "Jade Lantern House",
              "value": "00107289"
            },
            {
              "loc": {
                "a": "Bengaluru International Airport Road",
                "c": "Bangalore",
                "lo": 77.59,
                "la": 13.05,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Hotel Moon Suite",
              "value": "00102438"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.68,
                "la": 13.37,
                "az": "Yeshwanthpur"
              },
              "label": "Diamond Pent House",
              "value": "00107310"
            },
            {
              "loc": {
                "a": "Yelahanka",
                "c": "Bangalore",
                "lo": 77.61,
                "la": 12.98,
                "az": "Bengaluru International Airport Road"
              },
              "label": "Tranquil Residences",
              "value": "00102258"
            },
            {
              "loc": {
                "c": "Bangalore",
                "lo": 76.68,
                "la": 11.81
              },
              "label": "Hotel Sri Guruprasad",
              "value": "00107248"
            },
            {
              "loc": {
                "a": "Yeshwanthpur",
                "c": "Bangalore",
                "lo": 77.64,
                "la": 12.95,
                "az": "Yeshwanthpur"
              },
              "label": "Diamond Studio Apartment",
              "value": "00107308"
            },
            {
              "loc": {
                "a": "Majestic",
                "c": "Bangalore",
                "lo": 77.576072,
                "la": 12.970236
              },
              "label": "Ashok Palace Deluxe Lodge",
              "value": "00059779"
            },
            {
              "loc": {
                "a": "Hsr Layout",
                "c": "Bangalore",
                "lo": 77.64,
                "la": 12.85,
                "az": "Koramangala"
              },
              "label": "Jade Woods Eco City 2 BHK",
              "value": "00107262"
            },
            {
              "loc": {
                "a": "Hsr Layout",
                "c": "Bangalore",
                "lo": 77.65,
                "la": 12.84,
                "az": "Koramangala"
              },
              "label": "Jade Wood E-City",
              "value": "00107266"
            },
            {
              "loc": {
                "a": "Whitefield",
                "c": "Bangalore",
                "lo": 77.603423,
                "la": 12.984509,
                "az": "Whitefield"
              },
              "label": "Finesse International ITPL",
              "value": "00059814"
            },
            {
              "loc": {
                "a": "Gandhi Nagar",
                "c": "Bangalore",
                "lo": 77.67,
                "la": 12.92,
                "az": "Gandhi Nagar"
              },
              "label": "Sunrise Comfort",
              "value": "00098282"
            },
            {
              "loc": {
                "a": "Balepet",
                "c": "Bangalore",
                "lo": 77.576045,
                "la": 12.973846
              },
              "label": "Sri Kumara Lodge",
              "value": "00048230"
            },
            {
              "loc": {
                "a": "Minerva Circle",
                "c": "Bangalore",
                "lo": 77.57,
                "la": 12.94,
                "az": "Jayanagar"
              },
              "label": "Madhu Lodge",
              "value": "00104120"
            },
            {
              "loc": {
                "a": "Anand Rao Circle",
                "c": "Bangalore",
                "lo": 77.57,
                "la": 12.97,
                "az": "Gandhi Nagar"
              },
              "label": "Raj Deluxe",
              "value": "00104129"
            },
            {
              "loc": {
                "a": "Outskirts",
                "c": "Bangalore",
                "lo": 0,
                "la": 0,
                "az": "Outskirts"
              },
              "label": "Tyr",
              "value": "00094800"
            },
            {
              "loc": {
                "a": "Hbr Layout",
                "c": "Bangalore",
                "lo": 13.039595,
                "la": 77.62767
              },
              "label": "X by bloom - Hebbal",
              "value": "00177735"
            }
          ],
          "filterName": "Hotel List"
        },
        {
          "filterKey": "gi",
          "filterValues": [
            
          ],
          "filterName": "PAYMENT MODE"
        }
      ]
    },
    "wgSearchResults": [
      
    ],
    "lastPage": "false",
    "showWgViewAllBtn": true,
    "totalResultCount": 768,
    "voucher": [
      {
        "name": "Free Vouchers worth Rs. 1000",
        "id": "vouchers"
      }
    ],
    "waitForDBInsertionInMillisecond": "2000",
    "pageId": "23052020-24052020-10zzzzz-00zzzzz-00zzzzz-00zzzzz:51872",
    "isDisplayHomestay": "true",
    "supplierInteractionId": "23052020-24052020-10zzzzz-00zzzzz-00zzzzz-00zzzzz:51872",
    "searchResults": [
      {
        "freeCancel": true,
        "isAgency": false,
        "ratePlanType": "24",
        "latitude": "12.909673",
        "discount": 1548,
        "extras": [
          1,
          0
        ],
        "reviewRating": "2.5",
        "discountPercentage": 57,
        "isYatraSmart": true,
        "strikeOffPrice": 2708,
        "displayPrice": 1160,
        "supplier": "TGU",
        "propertyType": "Hotels",
        "theme": [
          "Couple Friendly Hotels"
        ],
        "id": "TGR-00149171",
        "isFeatured": true,
        "promoDiscount": 195,
        "comfortRating": 3,
        "longitude": "77.63934",
        "yatraSelectRating": "0",
        "tT": [
          "Business",
          "Family"
        ],
        "image": {
          "url": "https://imgcld.yatra.com/ytimages/image/upload/t_hotel_yatra_city_desktop/v1554102691/Hotel/00149171/766A5387_HDR_6hkL6l.jpg"
        },
        "locationName": "Hsr Layout",
        "specialOffers": [
          "Save 50% on Sun, Mon, Tue, Wed, Thu, Fri and Sat"
        ],
        "hotelId": "00149171",
        "guaranteeInfos": [
          {
            "depositAmount": 0,
            "depositNights": 0,
            "guaranteeType": "PrePay",
            "depositPercent": 0
          }
        ],
        "noOfBathroom": 0,
        "roomsLeft": 6,
        "name": "Treebo Trend Kings Suits",
        "noOfReviews": "4",
        "instantBook": false
      },
      {
        "freeCancel": true,
        "isAgency": false,
        "ratePlanType": "24",
        "latitude": "12.993664",
        "discount": 313,
        "reviewRating": "4.0",
        "discountPercentage": 14,
        "isYatraSmart": false,
        "strikeOffPrice": 2200,
        "displayPrice": 1887,
        "supplier": "TGU",
        "propertyType": "Hotels",
        "theme": [
          "Luxury Hotels",
          "Best value",
          "Business Hotels"
        ],
        "id": "TGR-00007154",
        "isFeatured": true,
        "promoDiscount": 313,
        "comfortRating": 3,
        "longitude": "77.571354",
        "yatraSelectRating": "0",
        "tT": [
          "Business",
          "Family"
        ],
        "image": {
          "url": "https://imgcld.yatra.com/ytimages/image/upload/t_hotel_yatra_city_desktop/v1520331215/Hotel/Bengaluru/00007154/Facade_2_QrRP19.jpg"
        },
        "locationName": "Malleshwaram",
        "hotelId": "00007154",
        "guaranteeInfos": [
          {
            "depositAmount": 0,
            "depositNights": 0,
            "guaranteeType": "PrePay",
            "depositPercent": 0
          }
        ],
        "roomsLeft": 1,
        "name": "bloom Boutique l Malleshwaram",
        "noOfReviews": "100",
        "instantBook": false
      },
      {
        "freeCancel": true,
        "isAgency": false,
        "ratePlanType": "24",
        "latitude": "12.853",
        "discount": 656,
        "extras": [
          0
        ],
        "reviewRating": "3.0",
        "discountPercentage": 27,
        "isYatraSmart": false,
        "strikeOffPrice": 2414,
        "displayPrice": 1758,
        "supplier": "TGU",
        "propertyType": "Hotels",
        "theme": [
          "Romantic Hotels",
          "Best value",
          "Business Hotels",
          "Family Hotels",
          "Budget Hotels",
          "Couple Friendly Hotels"
        ],
        "id": "TGR-00125410",
        "isFeatured": false,
        "promoDiscount": 295,
        "comfortRating": 3,
        "longitude": "77.674",
        "yatraSelectRating": "0",
        "tT": [
          "Business",
          "Solo travel"
        ],
        "image": {
          "url": "https://imgcld.yatra.com/ytimages/image/upload/t_hotel_yatra_city_desktop/v1573112697/Hotel/00125410/IMG_4372_TK6Bde.jpg"
        },
        "locationName": "Electronic City",
        "specialOffers": [
          "Save 15% on Mon, Tue, Wed, Thu, Fri, Sat and Sun"
        ],
        "hotelId": "00125410",
        "guaranteeInfos": [
          {
            "depositAmount": 0,
            "depositNights": 0,
            "guaranteeType": "PrePay",
            "depositPercent": 0
          }
        ],
        "noOfBathroom": 0,
        "roomsLeft": 6,
        "name": "Hotel Presidency-Electronic City",
        "noOfReviews": "1",
        "category": [
          "Bed and Breakfast"
        ],
        "instantBook": false
      },
      {
        "freeCancel": true,
        "isAgency": false,
        "ratePlanType": "24",
        "latitude": "13.157257",
        "discount": 331,
        "extras": [
          1,
          0
        ],
        "reviewRating": "5.0",
        "discountPercentage": 14,
        "isYatraSmart": true,
        "strikeOffPrice": 2301,
        "displayPrice": 1970,
        "supplier": "TGU",
        "propertyType": "Hotels",
        "theme": [
          "Best value",
          "Business Hotels",
          "Family Hotels",
          "Spa Hotels",
          "Couple Friendly Hotels"
        ],
        "id": "TGR-00147385",
        "isFeatured": false,
        "promoDiscount": 331,
        "comfortRating": 3,
        "longitude": "77.625009",
        "yatraSelectRating": "0",
        "tT": [
          "Business",
          "Family"
        ],
        "image": {
          "url": "https://imgcld.yatra.com/ytimages/image/upload/t_hotel_yatra_city_desktop/v1552307116/Hotel/Bengaluru/00147385/superior_room_nFtvLZ.jpg"
        },
        "locationName": "Bengaluru International Airport Road",
        "hotelId": "00147385",
        "guaranteeInfos": [
          {
            "depositAmount": 0,
            "depositNights": 0,
            "guaranteeType": "PrePay",
            "depositPercent": 0
          }
        ],
        "noOfBathroom": 0,
        "roomsLeft": 1,
        "name": "Arna Hotel",
        "noOfReviews": "59",
        "instantBook": false
      },
      {
        "freeCancel": true,
        "isAgency": false,
        "ratePlanType": "24",
        "latitude": "12.957145",
        "discount": 2042,
        "extras": [
          1,
          0
        ],
        "reviewRating": "4.0",
        "discountPercentage": 27,
        "isYatraSmart": false,
        "strikeOffPrice": 7500,
        "displayPrice": 5458,
        "supplier": "TGU",
        "propertyType": "Hotels",
        "theme": [
          "Business Hotels",
          "Golf Hotels"
        ],
        "id": "TGR-00000163",
        "isFeatured": false,
        "promoDiscount": 917,
        "comfortRating": 5,
        "longitude": "77.644017",
        "yatraSelectRating": "0",
        "tT": [
          "Business",
          "Family"
        ],
        "image": {
          "url": "https://imgcld.yatra.com/ytimages/image/upload/t_hotel_yatra_city_desktop/v1488280389/Hotel/Bengaluru/00000163/hotel-royal-orchid_5SgIhO.jpg"
        },
        "locationName": "Old Airport Road",
        "specialOffers": [
          "Book before 14 days  and save 15% on each night"
        ],
        "hotelId": "00000163",
        "guaranteeInfos": [
          {
            "depositAmount": 0,
            "depositNights": 0,
            "guaranteeType": "PrePay",
            "depositPercent": 0
          }
        ],
        "roomsLeft": 5,
        "name": "Hotel Royal Orchid, Bangalore",
        "noOfReviews": "1593",
        "instantBook": false
      },
      {
        "freeCancel": true,
        "isAgency": false,
        "ratePlanType": "24",
        "latitude": "12.93057",
        "discount": 648,
        "extras": [
          1,
          0
        ],
        "reviewRating": "4.5",
        "discountPercentage": 14,
        "isYatraSmart": false,
        "strikeOffPrice": 4501,
        "displayPrice": 3853,
        "supplier": "TGU",
        "propertyType": "Hotels",
        "theme": [
          "Romantic Hotels",
          "Luxury Hotels",
          "Best value",
          "Business Hotels",
          "Family Hotels",
          "City Holiday",
          "Family Get-Together",
          "Budget Hotels",
          "Couple Friendly Hotels"
        ],
        "id": "TGR-00020162",
        "isFeatured": false,
        "promoDiscount": 648,
        "comfortRating": 3,
        "longitude": "77.623564",
        "yatraSelectRating": "0",
        "tT": [
          "Family",
          "Friends getaway"
        ],
        "image": {
          "url": "https://imgcld.yatra.com/ytimages/image/upload/t_hotel_yatra_city_desktop/v1565249804/Hotel/Bengaluru/00020162/0-1200x900_hkMq07.jpg"
        },
        "locationName": "Koramangala",
        "hotelId": "00020162",
        "guaranteeInfos": [
          {
            "depositAmount": 0,
            "depositNights": 0,
            "guaranteeType": "PrePay",
            "depositPercent": 0
          }
        ],
        "roomsLeft": 5,
        "name": "Hotel Wafi Suites",
        "noOfReviews": "18",
        "category": [
          "Bed and Breakfast",
          "Villa",
          "Apartment"
        ],
        "instantBook": false
      },
      {
        "freeCancel": true,
        "isAgency": false,
        "ratePlanType": "10",
        "latitude": "13.188065",
        "discount": 898,
        "extras": [
          1,
          0
        ],
        "reviewRating": "4.0",
        "discountPercentage": 31,
        "isYatraSmart": false,
        "strikeOffPrice": 2851,
        "displayPrice": 1953,
        "supplier": "TGU",
        "propertyType": "Hotels",
        "theme": [
          "Romantic Hotels",
          "Luxury Hotels",
          "Family Hotels",
          "City Holiday",
          "Family Get-Together",
          "Couple Friendly Hotels"
        ],
        "id": "TGR-00152554",
        "isFeatured": false,
        "promoDiscount": 328,
        "comfortRating": 3,
        "longitude": "77.633648",
        "yatraSelectRating": "0",
        "tT": [
          "Family",
          "Business"
        ],
        "image": {
          "url": "https://imgcld.yatra.com/ytimages/image/upload/t_hotel_yatra_city_desktop/v1578060267/Hotel/Bengaluru/00152554/DSC_3919_DbxtfW.jpg"
        },
        "locationName": "Bengaluru International Airport Road",
        "specialOffers": [
          "Save 20% on Mon, Tue, Wed, Thu, Fri, Sat and Sun"
        ],
        "hotelId": "00152554",
        "guaranteeInfos": [
          {
            "depositAmount": 0,
            "depositNights": 0,
            "guaranteeType": "PrePay",
            "depositPercent": 0
          }
        ],
        "noOfBathroom": 0,
        "roomsLeft": 4,
        "name": "Royal Lotus View Resotel",
        "noOfReviews": "18",
        "instantBook": false
      },
      {
        "freeCancel": true,
        "isAgency": false,
        "ratePlanType": "10",
        "latitude": "12.977517",
        "discount": 648,
        "extras": [
          0
        ],
        "reviewRating": "3.5",
        "discountPercentage": 14,
        "isYatraSmart": true,
        "strikeOffPrice": 4501,
        "displayPrice": 3853,
        "supplier": "TGU",
        "propertyType": "Hotels",
        "theme": [
          "Luxury Hotels",
          "Best value",
          "Business Hotels",
          "Hourly Hotels"
        ],
        "id": "TGR-00007253",
        "isFeatured": false,
        "promoDiscount": 648,
        "comfortRating": 3,
        "longitude": "77.577756",
        "yatraSelectRating": "0",
        "tT": [
          "Business",
          "Family"
        ],
        "image": {
          "url": "https://imgcld.yatra.com/ytimages/image/upload/t_hotel_yatra_city_desktop/v1479993812/Domestic Hotels/Hotels_Bangalore/Hotel Basant Residency/Hotel_Basant_Residency.jpg"
        },
        "locationName": "Race Course Road",
        "hotelId": "00007253",
        "guaranteeInfos": [
          {
            "depositAmount": 0,
            "depositNights": 0,
            "guaranteeType": "PrePay",
            "depositPercent": 0
          }
        ],
        "roomsLeft": 1,
        "name": "Hotel Basant Residency",
        "noOfReviews": "74",
        "instantBook": false
      },
      {
        "freeCancel": true,
        "isAgency": false,
        "ratePlanType": "10",
        "latitude": "13.006283",
        "discount": 320,
        "extras": [
          1,
          0
        ],
        "reviewRating": "3.5",
        "discountPercentage": 27,
        "isYatraSmart": true,
        "strikeOffPrice": 1179,
        "displayPrice": 859,
        "supplier": "TGU",
        "propertyType": "Hotels",
        "theme": [
          "Luxury Hotels",
          "Business Hotels",
          "Family Hotels"
        ],
        "id": "TGR-00031050",
        "isFeatured": false,
        "promoDiscount": 144,
        "comfortRating": 3,
        "longitude": "77.593469",
        "yatraSelectRating": "0",
        "tT": [
          "Family",
          "Solo travel"
        ],
        "image": {
          "url": "https://imgcld.yatra.com/ytimages/image/upload/t_hotel_yatra_city_desktop/v1464153721/Domestic Hotels/Hotels_Bangalore/Atlaantic Inn/Front_View.jpg"
        },
        "locationName": "R T Nagar",
        "specialOffers": [
          "Book before 7 days  and save 15% on each night"
        ],
        "hotelId": "00031050",
        "guaranteeInfos": [
          {
            "depositAmount": 0,
            "depositNights": 0,
            "guaranteeType": "PrePay",
            "depositPercent": 0
          }
        ],
        "roomsLeft": 5,
        "name": "Atlaantic Inn",
        "noOfReviews": "21",
        "instantBook": false
      },
      {
        "freeCancel": true,
        "isAgency": false,
        "ratePlanType": "24",
        "latitude": "12.926023",
        "discount": 2330,
        "extras": [
          1,
          0
        ],
        "reviewRating": "3.5",
        "discountPercentage": 57,
        "isYatraSmart": true,
        "strikeOffPrice": 4075,
        "displayPrice": 1745,
        "supplier": "TGU",
        "propertyType": "Hotels",
        "theme": [
          "Best value",
          "Business Hotels"
        ],
        "id": "TGR-00084784",
        "isFeatured": false,
        "promoDiscount": 293,
        "comfortRating": 3,
        "longitude": "77.670795",
        "yatraSelectRating": "0",
        "tT": [
          "Business",
          "Family"
        ],
        "image": {
          "url": "https://imgcld.yatra.com/ytimages/image/upload/t_hotel_yatra_city_desktop/v1523010509/Hotel/00084784/Facade_(5)_XZGynx.jpg"
        },
        "locationName": "Bellandur",
        "specialOffers": [
          "Save 50% on Sun, Mon, Tue, Wed, Thu, Fri and Sat"
        ],
        "hotelId": "00084784",
        "guaranteeInfos": [
          {
            "depositAmount": 0,
            "depositNights": 0,
            "guaranteeType": "PrePay",
            "depositPercent": 0
          }
        ],
        "noOfBathroom": 0,
        "roomsLeft": 6,
        "name": "Treebo Trip Hotel Worldtree Bellandur",
        "noOfReviews": "40",
        "instantBook": false
      }
    ],
    "uid": "d8b9a248-0aec-4bb4-8545-b04f9fab2bf7",
    "yatraSmart": [
      {
        "name": "Priority Helpline",
        "id": "priority-helpline"
      },
      {
        "name": "Money Back Guarantee",
        "link": "https://www.yatra.com/offer/details/money-back-guarantee-offer",
        "id": "money-back-guarantee"
      },
      {
        "name": "Free Gift Vouchers",
        "id": "free-voucher"
      },
      {
        "name": "Free Cancellation",
        "id": "free-cancellation",
        "desc": "Free Cancellation till 24 hours in All Business Cities"
      },
      {
        "name": "Free Wifi",
        "id": "free-wifi",
        "desc": "Complimentary Wi-Fi ( 24 X 7 )"
      },
      {
        "name": "24x7 Security",
        "id": "security",
        "desc": "Security Guard/Lobby CCTV"
      },
      {
        "name": "24x7 Room service",
        "id": "all-day-room-service",
        "desc": "Restaurant / Room service available"
      },
      {
        "name": "2 Water Bottles",
        "id": "complimentary-mineral-water",
        "desc": "2 Ltr of Bottled Water per day"
      },
      {
        "name": "A/C Rooms, Power back up",
        "id": "ac-rooms",
        "desc": "Air-conditioned rooms and 24X7 power backup"
      },
      {
        "name": "24x7 H/C water",
        "id": "hot-water",
        "desc": "Hot and cold shower"
      },
      {
        "name": "DTH services",
        "id": "dth-services",
        "desc": "DTH services extensive in-room entertainment"
      }
    ],
    "sortType": "YTDesc",
    "srpDisplayMessage": "Price is for 1 room and 1 night.",
    "toastDuration": 6,
    "forXNight": "for 1 night",
    "sortKeys": [
      "re",
      "pr",
      "ta",
      "st",
      "id"
    ],
    "hotelsResponseTimeInMilis": "533",
    "status": "SUCCESS"
  }
}
Online JSON Viewer
About JSON
JSON, short for JavaScript Object Notation, is a lightweight computer data interchange format. JSON is a text-based, human-readable format for representing simple data structures and associative arrays (called objects).

Read more: json.org, wikipedia, google

In JSON, they take on these forms
JSON object

JSON array

JSON value

JSON string

JSON number
Example
{
    "firstName": "John",
    "lastName": "Smith",
    "gender": "man",
    "age": 32,
    "address": {
        "streetAddress": "21 2nd Street",
        "city": "New York",
        "state": "NY",
        "postalCode": "10021"
    },
    "phoneNumbers": [
        { "type": "home", "number": "212 555-1234" },
        { "type": "fax", "number": "646 555-4567" }
    ]
}
About Online JSON Viewer
Convert JSON Strings to a Friendly Readable Format
The application using Ext JS.
Author: {gabor}

PayPal - The safer, easier way to pay online! 
 */
}

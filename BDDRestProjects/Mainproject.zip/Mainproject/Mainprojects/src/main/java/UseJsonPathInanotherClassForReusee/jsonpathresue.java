package UseJsonPathInanotherClassForReusee;

import io.restassured.path.json.JsonPath;

public class jsonpathresue {

	
	public static JsonPath getreplaceresponse(String coderes) { //make static so we can reuse it in another class without creating object //accept string type data
		
		JsonPath jsonre = new JsonPath(coderes);
		return jsonre;
		
	}
}

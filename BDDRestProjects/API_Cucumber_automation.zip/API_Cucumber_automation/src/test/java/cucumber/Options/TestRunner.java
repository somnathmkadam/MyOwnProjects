package cucumber.Options;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/java/features",plugin="json:target/jsonReports/cucumber-report.json",tags= {"@AddPlace,@DeletePlace"}, glue= {"stepDefinations"})
public class TestRunner {
	
	//To Run project using cmd then first give path of mvn to environment variable path 
	//then open CMD in administration
	//Goto that project using Cd project path
	// Now use mvn test command which featch test runner file and execute it
	//To run mvn in cmd with tags use: mvn test -Dcucumber.options="--tags @AddPlace"

	
	
	//Now to generte report goto mvn generate report https://github.com/damianszczepanik/maven-cucumber-reporting
	//copy xml and paste it in pom file before dependency
	//and add new version in xml maven-cucumber-reporting version 
	//Now add plugin used to create json file in target folder which create jsonreports folder and using that json file html is getting generated
	//run mvn test verify command to run our project
	
	
	//java -jar jenkins.war used to run jenkins in cmd run .war file
	//jenkins- new item- name- General/advance/use custom workspace- add path of project - This proect is parameterized and add name= tag and in choices and tagnames
	//in golas: test verify -Dcucumber.options="--tags @"$tag""    apply and save so now project will run according to tags
	// test verify run all tests
	
}

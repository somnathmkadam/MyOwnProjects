package resources;

public enum APIResources {
	
	AddPlaceAPI("/maps/api/place/add/json"),
	GetPlaceAPI("/maps/api/place/get/json"),
	DeletePlaceAPI("/maps/api/place/delete/json");
	
	private String Resource;
	APIResources(String resources){ //constructor of apiresources class
		this.Resource = resources;
		
	}
	
	public String getresource() {
		return Resource; //pass resource to this method
	}
	

}

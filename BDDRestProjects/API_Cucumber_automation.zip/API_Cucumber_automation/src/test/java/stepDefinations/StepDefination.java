package stepDefinations;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.*;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import static io.restassured.RestAssured.given;
import pojo.AddPlace;
import pojo.Location;
import resources.APIResources;
import resources.TestDataBuild;
import resources.Utils;


public class StepDefination extends Utils {
	RequestSpecification res;
	ResponseSpecification resspec;
	Response Response;
	TestDataBuild data = new TestDataBuild();
	static String PlaceID;  //mentioned static beacuse in next scenarios everything is reset to null but not static value
	
	@Given("^Add place payload with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void add_place_payload_with(String name, String language, String address) throws IOException {
       
	
		RestAssured.baseURI="https://rahulshettyacademy.com";
		
		 
		 res= given().spec(requestSpecification()).body(data.addPlacePayload(name,language,address));
		
		
        
    }

	@When("^User calls \"([^\"]*)\" with \"([^\"]*)\" Http request$")
    public void user_calls_something_with_something_http_request(String resource, String method) throws Throwable {
    	
    	APIResources resourcevalue =APIResources.valueOf(resource); //call APIresource class with given value
    	 //created object of class
    	
    	System.out.println("value of resource is" +resourcevalue.getresource()); //get resource from file  
    	
    	resspec= new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();
    	
    	if(method.equalsIgnoreCase("POST"))
         Response= res.when().post(resourcevalue.getresource()) //placed resources here
        		.then().spec(resspec).extract().response();
    	
    	else if(method.equalsIgnoreCase("GET"))
    		Response= res.when().get(resourcevalue.getresource()) //placed resources here
    		.then().spec(resspec).extract().response();
    	
    }

    @Then("^The API call got success with status code 200$")
    public void the_api_call_got_success_with_status_code_200() throws Throwable {
    	assertEquals(Response.getStatusCode(),200);
    	
    	
        
    }

    @And("^\"([^\"]*)\" in response body is \"([^\"]*)\"$")
    public void something_in_response_body_is_something(String keyvalue, String Expectedvalue) throws Throwable {
     
    
     assertEquals(getJsonpathandExtractvalue(Response,keyvalue), Expectedvalue) ;
    	
    }
	
    @And("^Verify \"([^\"]*)\" using \"([^\"]*)\"$")
    public void verify_something_using_something(String name, String ResourceName) throws Throwable {
     PlaceID=	getJsonpathandExtractvalue(Response, "place_id");
    	 res= given().spec(requestSpecification()).queryParam("place_id",PlaceID );
    	 user_calls_something_with_something_http_request(ResourceName,"GET");
    	 String actualname= getJsonpathandExtractvalue(Response, "name");
    	 assertEquals(actualname, name);
    	 
    }
    
    @Given("^DeletePlace payload$")
    public void deleteplace_payload() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	res= given().spec(requestSpecification()).body(data.DeletePlacePayload(PlaceID));
    }
	
}

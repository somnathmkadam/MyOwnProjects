package stepDefinations;

import java.io.IOException;

import cucumber.api.java.Before;

public class Hooks {
	//used to set preconditions and post conditions so due to tags test cases should not get failed
	
	
	@Before("@DeletePlace")
	public void hooks() throws Throwable {
		
		StepDefination stepcall = new StepDefination();
		
		if(StepDefination.PlaceID==null) {  //place id is static so we can used it without object by directly calling class because its class memory not object memory
		stepcall.add_place_payload_with("Sanket", "Sanskrit", "Mumbai_andheri");
		stepcall.user_calls_something_with_something_http_request("AddPlaceAPI", "post");
		stepcall.verify_something_using_something("Sanket", "GetPlaceAPI");
		
		}
		
	}

}

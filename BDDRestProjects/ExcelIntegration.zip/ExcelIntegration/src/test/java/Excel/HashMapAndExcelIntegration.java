package Excel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;


public class HashMapAndExcelIntegration {

	public static void main (String []args) throws IOException {
		DataDriven data = new DataDriven(); //created object of fetch excel sheet program
	    ArrayList list=      data.datafetcher("AddProfile"); //fetch data of addprofile row and pass it into the hashmap
	    
	HashMap<String, Object>  jsonAsMap = new HashMap<>();   //hashmap is keyvalue pair in where key is string and value is object
	jsonAsMap.put("firstName", list.get(1));  //we fetch dat from excel sheet and pass it into the hashmap
	jsonAsMap.put("firstName", "John");
	jsonAsMap.put("Lastname", "vik");
	HashMap<String, Object>  nested = new HashMap<>(); 
	nested.put("star", "var");
	nested.put("pink", "colour");
	jsonAsMap.put("combination", nested);
	
	System.out.println(jsonAsMap);

//O/P=	{firstName=John, Lastname=vik, combination={pink=colour, star=var}}
	
	
	/*given().
    contentType(JSON).
    body(jsonAsMap).  //we can pass hashmap directy into the body
when().
    post("/somewhere").
then().
    statusCode(200)*/
	}

	private static void hashmapmethod() {
		// TODO Auto-generated method stub
		
	}
}

package Excel;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataDriven {
	
	
	public static ArrayList<String> datafetcher(String cellname) throws IOException {
		
		ArrayList<String> values = new ArrayList<String>();
		
		FileInputStream fis = new FileInputStream("D://ExcelSheet//abcs.xlsx");
		@SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		
		int sheetcount=workbook.getNumberOfSheets();
		for (int i=0; i<sheetcount;i++) {
			if(workbook.getSheetName(i).equalsIgnoreCase("testdata")) {
				
			XSSFSheet sheet= workbook.getSheetAt(i);  //taking first sheet getsheet return type is xssf
			Iterator<Row> rows=	sheet.iterator(); //take access of rows
		               
			          Row firstrow= rows.next();  //take first row
			      Iterator<Cell> cell= firstrow.cellIterator(); //Take cell access
			      int k=0;
			      int coloumn = 0;
			      while(cell.hasNext()) {  //if next cell is present
			    	  
			    	      Cell value=  cell.next(); //take cell value
			    	            if  ( value.getStringCellValue().equalsIgnoreCase("TestCases")) {
			    	            	//Check cell has TestCases name or not
			    	            	
			    	            	coloumn=k; //check coloumn number where exactly TestCases name is present
			    	            	
			    	            	
			    	            }
			    	            k++;
			      }
			    	            
			    	            while(rows.hasNext()) {
			    	            	Row r = rows.next();
			    	            	System.out.println(r.getCell(coloumn));
			    	            	if(r.getCell(coloumn)==null) {
			    	            		continue;
			    	            	}
			    	            	System.out.println(r.getCell(coloumn).getStringCellValue());
			    	            	if(r.getCell(coloumn).getStringCellValue().equalsIgnoreCase(cellname)) {
			    	            		Iterator <Cell> cv= r.cellIterator();
			    	            		while(cv.hasNext()) {
			    	            			Cell c = cv.next();
			    	            			if (c.getCellTypeEnum()==CellType.STRING) {
			    	            				values.add(c.getStringCellValue());
			    	            			}
			    	            	           
			    	            			else{
			    	            			values.add(NumberToTextConverter.toText(c.getNumericCellValue()));
			    	            				
			    	            			}
			    	            			
			    	            		}
			    	            		
			    	            		
			    	            	}
			    	            }
			    	                   
			    	  
			      }
			          
			
			
			
			}
		
		return values;	
			
		}
		
	}



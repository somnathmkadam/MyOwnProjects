package Excel;

import java.io.IOException;
import java.util.ArrayList;

public class FetchData {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		DataDriven data = new DataDriven();
		    ArrayList list=      data.datafetcher("AddProfile");
		
		System.out.println(list.get(1));
		
	}

}

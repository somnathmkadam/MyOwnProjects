import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.testng.Assert;

import PayLoad.Body;
import PayLoad.JsonPathReuse;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class ExtractDataFromResponse {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//post method
		RestAssured.baseURI="https://secure.yatra.com";
		
	String response=	given().header("Content-Type","application/x-www-form-urlencoded").body(Body.Payload())
		.when().log().all().post("ccwebapp/mobile/flight/mdomandroid/getPersuasionData.htm")
		.then().assertThat().statusCode(200).body("interationType", equalTo("PersuasionAPI"))
		.header("content-security-policy", "frame-ancestors 'self' *.yatra.com *.google.com").extract().response().asString(); 
		//here complete response is extract using extract as a string and pass to one variable
	//asString() is used to convert a jsonValue to a String. tostring() is The string representation of the current message
	System.out.println("Response from request is" +response);
	
	
	//now extract perticular value from that string
	JsonPath json = new JsonPath(response); //java class which convert string into json
	String interactionId = json.getString("interactionId");
	String header = json.getString("response.persuasionResp.message");
	String colorCode = json.getString("response.persuasionResp.colorTextList.colorCode");
	System.out.println("interaction "+ interactionId);
	System.out.println("header "+ header);  // output is in array [ 18 People  are looking to book flights departing Jun 05 for this sector]
	System.out.println("colorcode "+ colorCode.replaceAll("\\[*\\]*", "")); //regex used to pattern replace '\\'to skip [ to show [] is part to string * many times come normally if \\ is not used then [] used as a content search is not part of string
	
	//now we can use above string in our body //update param
	given().queryParam("key", "value").header("","").body("{\r\n" + 
			"    \"resCode\": 200,\r\n" + 
			"    \"resMessage\": \""+colorCode+"\",\r\n" +    //how to pass colorcode in body
			"    \"interactionId\": \"841bee59-87c0-4ef3-b49f-d3208071fff7\",\r\n" + 
			"    \"interationType\": \"PersuasionAPI\",\r\n" + 
			"    \"sessionId\": \"b73d13743966d9cd15794106683223259\",\r\n" + 
			"   \r\n" + 
			"}").when().put("resource").then().assertThat().statusCode(200);
	
	
	//get method we fect code and compare it with colour code
	String coderesponse= given().queryParam("key", "value").queryParam("key", "param")
	.when().get("resources").then().assertThat().log().all().statusCode(200).extract().response().asString();
	
	JsonPath json1 = new JsonPath(coderesponse); //get response json into string  //OR use can .body("",equalto(""));
	String colourcode1 = json1.getString("colorCode"); //colourcode fetch from response and now we can compare it with above color code
	
// to use assert java download testng jar https://repo1.maven.org/maven2/org/testng/testng/7.0.0/ download only .jar file
	//Assert.assertEquals(colourcode1, colorCode);
	
	// We can move jsonpath into another class to reuse
	JsonPath colourcode2= JsonPathReuse.getreplaceresponse(coderesponse);
	//jsonpath is type of colourcode2
	
	
	
	
	//To body raw data convert it into key-value pair goto post man- replace & with \n (next line) and then replace = to : and then
	//click on bulk data and then click on  key-value 
	
	/*
	 {
    "resCode": 200,
    "resMessage": "Success",
    "interactionId": "c57c4ee1-3579-4ffd-a75b-307bbfbef17b",
    "interationType": "PersuasionAPI",
    "sessionId": "b73d13743966d9cd15794106683223259",
    "response": {
        "persuasionResp": [
            {
                "header": "Seats Selling Fast",
                "boldText": [
                    "Jun 05"
                ],
                "id": "sellingFast",
                "message": " 19 People  are looking to book flights departing Jun 05 for this sector",
                "colorTextList": [
                    {
                        "colorCode": "#eb3d48",
                        "text": " 19 People "
                    }
                ]
            }
        ],
        "farePredictorResp": null
    }
}
	 */

	}
}

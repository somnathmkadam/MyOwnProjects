import PayLoad.JsondataParse;
import io.restassured.path.json.JsonPath;

public class JsonParsing {
	
	public static void main(String[]args) { //static is written because to call this class without creating any object by JVM and String [] means its accepts
		// String type arrays and args is array name which can be anything
		
		JsonPath js = new JsonPath(JsondataParse.jsondata());
		
		//print No of courses returned by API
		int count = js.getInt("courses.size()"); //size method apply only on arrays  
		System.out.println("courses return by api is "+ count);
		
		
		//Print Purchase Amount
	int amount=	js.getInt("dashboard.purchaseamount");
		System.out.println("purchas amount is "+ amount);
		
		//Print Title of the first course
	String firstTitle=	js.getString("courses[0].title"); //zeroth index fetch //get method can be used which pull out string by default
		System.out.println("first title is "+ firstTitle);
		
		for (int i=0;i<count;i++) {
		//Print All course titles and their respective Prices
		String coursetitle= js.get("courses["+i+"].title");
	System.out.println("count is " +i);
	int price = js.getInt("courses["+i+"].price");	 //another method to convert int to string and then show in syso
		System.out.println("coursetitle" + coursetitle);  //sysout always accepts string values
		
		System.out.println("price is "+ price);
		}
		
		
		//Print no of copies sold by RPA Course
		for (int i1=0;i1<count;i1++) {
			String coursetitle1= js.get("courses["+i1+"].title");
		if (coursetitle1.equalsIgnoreCase("RPA")) {
			int copies = js.get("courses["+i1+"].copies");
			System.out.println("copies insise RPA is " + copies);
			break;   //if element found then next loop will not be excuted
		}
		}
		
		
		
		/*
		 1. Print No of courses returned by API

2.Print Purchase Amount

3. Print Title of the first course

4. Print All course titles and their respective Prices

5. Print no of copies sold by RPA Course

6. Verify if Sum of all Course prices matches with Purchase Amount
		
		 {
  "dashboard": {
    "purchaseamount": 910,
    "Website": "rahushetty.com"
  },
  "courses": [   //inside courses there is nested json
    {
      "title": "selenium",
      "price": 50,
      "copies": 6
    },
    {
      "title": "cypress",
      "price": 40,
      "copies": 4
    },
    {
      "title": "RPA",
      "Price": 45,
      "copies": 10
    },
    
  ]

}
		 */
		
		
		
	}
	

}

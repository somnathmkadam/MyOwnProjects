import static io.restassured.RestAssured.*;


import java.io.File;

import org.testng.Assert;

import io.restassured.filter.session.SessionFilter;
import io.restassured.path.json.JsonPath;
public class JiraToolAPI {
	
	public static void main(String []args) {
	
	//if in your request {} is given then it means that path param is given so we have to add path param in ur request
	// ex: /bsbsbb/nsdsn/{key}/bdbdb/dndnn 
	
		SessionFilter session = new SessionFilter();
		//now add this session object in login request which stores session and then we can use this session for further uses
		//relax https validation used to bypass the https certification
		given().relaxedHTTPSValidation().header("","").body("").filter(session).when().post("").then().extract().response().asString();
		// here we are using filter session to get session id in login request
		
	given().pathParam("key", "1010").body("").filter(session).when().post("sshsh/shhshs/{key}/sgsgs"); //passing path param or u can directly pass this in {}
	// used this session in further requests
	
	
	//now to send any attchemnet we use .multipart("key" and then make file class as new file("file name" if its inside the project if outside the 
	//give path all in given section only) //header should be given to know content type is multipart formdata
	  given().header("content-type","multipart/formdata").multiPart("File",new File("file.txt")).when().post();
	  
	  
	  //we can use query parameter in get command to get perticular response from entire response
	String response=  given().queryParam("fields", "comments").when().get("resourse").then().extract().response().asString();
	  //from response only fields are taken
	  //ex: fields{ abc:asdd, comments:aggag, abbs:bbsbs}
	  
	  //now to get count of array and check every id inside comment is unquie or not
	  JsonPath js = new JsonPath(response);
	 int commentcount= js.getInt("location.size()"); //this gives size of comments array how many comments are present
	 for (int i=0;i<commentcount;i++) {
		String abc= js.get("fields.comments.comment["+i+"].id").toString(); //get zeroth location and get id
		 //convert it into string and then store for further comparison
		String oldid = "110";
		Assert.assertEquals(abc, oldid);
		 
	 }
	 
			  
	  
	  
	  
	  
	

	
	}
}

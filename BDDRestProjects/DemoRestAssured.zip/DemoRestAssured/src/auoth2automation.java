import static io.restassured.RestAssured.given;

import io.restassured.path.json.JsonPath;
public class auoth2automation {
	
	public static void main (String [] args)
	{
		
		
		
		System.setProperty("webdriver.chrome.driver", "c://chromedriver.exe");
	//	WebDriver driver = new ChromeDriver();
	//	driver.get("url");
		//driver.findelement(By.cssselector("input[type='email']")).sendkeys("enter email id");
		//same .sendkeys(keys.Enter);
		//Thread.sleep(4000);
		//same for password
		//now get url 
		//String url = driver.getcurrenturl();
		//String partialcode =  url.split("code=")[1]; //get url after code= which is first index and 0th index means url before code=
		//String actualcode= partialcode.split("&scope")[0];
		String actalcode;
		
	String accesstokenresponse=	given().queryParam("code", "actalcode").urlEncodingEnabled(false) //here code % not converted if we not give false then code chage happed by rest assured
		.queryParam("client_id", "").queryParam("client_screts", "").queryParam("redirect_url", "").queryParam("grant_type","authorization_code")
		.when().post("access_tokenurl").asString();
		
		JsonPath js = new JsonPath(accesstokenresponse); //get access token and save it in access_token
		String access_token   = js.getString("access_token");
		
		
	String response=given().queryParam("accessa_token", "").when().get("https://rahulshettyacademy.com/getCourse.php")
		.asString();
	}
}

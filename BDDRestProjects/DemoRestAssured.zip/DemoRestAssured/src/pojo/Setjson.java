package pojo;

public class Setjson {
	
	
	
	
	//1st for normal json
	//create object of class which used for getter and setter
	//ex: object is obj then obj.setloaction("pass the location");
	// if array present in json body then  make list of string 
	//List<String> mylist = new ArrayList<String>();
	//mylist.add("value");
	//mylist.add("value2");
	// obj.setlist(mylist); pass mylist in main class
	
	
	//if nested json is present json inside json then
	//create object of sub json class
	//object2 class and obj2 is object then
	//obj2.setpath(" "); if int then obj2.setpath();
	//now pass this value in main json class
	//obj.setvalue(obj2);
	
	//now you can pass entire json in body by .body(obj) with complete request
	

}

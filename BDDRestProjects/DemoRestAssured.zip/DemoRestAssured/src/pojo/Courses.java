package pojo;

import java.util.List;

public class Courses {
	
	private List <WebAutomation> WebAutomation;  //here also we have to mentioned //here in webautomation class returns array so we wrap this with list
	private String api;
	private String mobile;
	public List<pojo.WebAutomation> getWebautomation() {
		return WebAutomation;
	}
	public void setWebautomation(List<pojo.WebAutomation> webautomation) { //pojo.web means its accepts value from webautomation class now
		WebAutomation = webautomation;
	}
	public String getApi() {
		return api;
	}
	public void setApi(String api) {
		this.api = api;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	

}

package pojo;

public class GetCourses {
	
private	String Instructor;
private	String Url;
private	String Services;
private	String Expertises;
private	Courses Courses;   //courses class value
private	String LinkedIn;
public String getInstructor() {
	return Instructor;
}
public void setInstructor(String instructor) { //setter method used to set the value in global static variable void is given because its not returning anything
	Instructor = instructor;
}
public String getUrl() { //getter method used to get the value 
	return Url;
}
public void setUrl(String url) {
	Url = url;
}
public String getServices() {
	return Services;
}
public void setServices(String services) {
	Services = services;
}
public String getExpertises() {
	return Expertises;
}
public void setExpertises(String expertises) {
	Expertises = expertises;
}
public pojo.Courses getCourses() { //accept from courses class
	return Courses;
}
public void setCourses(pojo.Courses courses) {
	Courses = courses;
}
public String getLinkedIn() {
	return LinkedIn;
}
public void setLinkedIn(String linkedIn) {
	LinkedIn = linkedIn;
}
		
	/*
	 {
  "Instructor": "SomnathKadam",
  "Url": "www.somnathKadam.com",
  "Services": "abcd",
  "Expertises": "Automation",
  "Courses": {
    "Webautomation": [
{
        "CourseTitle": "Appium corses learn rest",
          "price": "100"
      },
 {
        "CourseTitle": "Appium corses learn rest",
          "price": "220"
      },
 {
        "CourseTitle": "Appium corses learn rest",
          "price": "330"
      }


],
    "api": [
 {
        "CourseTitle": "Appium corses learn rest",
          "price": "20"
      },
 {
        "CourseTitle": "Appium corses learn rest",
          "price": "30"
      }
],
    "mobile": [
      {
        "CourseTitle": "Appium corses learn rest",
          "price": "50"
      },
 {
        "CourseTitle": "Appium corses learn rest",
          "price": "40"
      }

    ]
  },
  "LinkedIn": "www.LinkedIn.com"
}
	 */

}

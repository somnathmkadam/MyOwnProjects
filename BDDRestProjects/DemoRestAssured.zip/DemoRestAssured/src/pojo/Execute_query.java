package pojo;
import static io.restassured.RestAssured.given;

import java.util.List;

import io.restassured.parsing.Parser;


public class Execute_query {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub

	GetCourses gc=	given().queryParam("", "").expect().defaultParser(Parser.JSON)   //here to transfer our json to java object converter pojo class we have to tell java that default response is in json
		.when().get("url").as(GetCourses.class);  //here we transfer the response to pojo class
		
	    
	System.out.println(gc.getLinkedIn());	//get linked in url
	System.out.println(gc.getExpertises()); //we can get expertise
	System.out.println(gc.getCourses().getWebautomation().get(1).getCourseTitle());  //taking course title of first index
	
	//now if we want to know the price of string whos position we dont know then 
	
	List <WebAutomation> webautomationlist=  gc.getCourses().getWebautomation(); //here we take list array response from class and pass it to the variable in variable also we have to mentioned which type of value iyt should be store
	for (int i=0; i<webautomationlist.size();i++) {  //taking size of an array
		
		
		if (webautomationlist.get(i).getCourseTitle().equalsIgnoreCase("abcds")){ //here we matches the string
			System.out.println(webautomationlist.get(i).getPrice()); //getting price of perticular string
			
		}
		
	}
		
	}

}

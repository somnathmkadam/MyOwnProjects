
public class Serialization_deserialization_of_pojo_class {

	
	//serialization means converting java object into request body(Payload)
	//Deser means converting response into java object
	//adv user friendly code more readable and its easy to use
	//create java object using pojo class
	//pojo class is created on the request
	//for json you need jackson and Gson library
	//https://repo1.maven.org/maven2/com/fasterxml/jackson/core/jackson-core/2.9.9/
	//https://mvnrepository.com/artifact/com.fasterxml.jackson.core/jackson-databind/2.9.9
	//https://repo1.maven.org/maven2/com/fasterxml/jackson/core/jackson-annotations/2.9.9/
	//https://repo1.maven.org/maven2/com/google/code/gson/gson/2.8.5/
	
	
	
	
}

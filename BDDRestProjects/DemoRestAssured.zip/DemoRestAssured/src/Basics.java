import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*; // done for given some packages in rest assured are static so we give this * pull out all packages
                                            // Eclipse is not showing auto suggestions for static packages
import static org.hamcrest.Matchers.*;

import PayLoad.Body;



public class Basics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//post method
		RestAssured.baseURI="https://secure.yatra.com";
		
		given().log().all().header("Content-Type","application/x-www-form-urlencoded").body(Body.Payload())
		.when().post("ccwebapp/mobile/flight/mdomandroid/getPersuasionData.htm")
		.then().log().all().assertThat().statusCode(200).body("interationType", equalTo("PersuasionAPI"))
		.header("content-security-policy", "frame-ancestors 'self' *.yatra.com *.google.com"); 
		
	//log all in given to show request and log all response show after then
//given().queryParam("","").header()
		// given : all input details
		//when: submit the API with resources,http method
		//then: validate the response
	}

}

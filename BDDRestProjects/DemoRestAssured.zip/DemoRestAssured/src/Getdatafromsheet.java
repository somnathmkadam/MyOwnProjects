import java.nio.file.Paths;

import org.testng.annotations.Test;

import PayLoad.Body;


import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.io.IOException;
import java.nio.file.Files;



public class Getdatafromsheet {
	
	
	@Test
	public void staticdata() throws IOException {
		String response=	given().header("Content-Type","application/x-www-form-urlencoded").body(GenerateStringFromResource("C:\\Users\\kadam.somnath\\Desktop\\RestAssured.json")) 
				.when().post("ccwebapp/mobile/flight/mdomandroid/getPersuasionData.htm")                                        //taken json data from file inside system
				.then().assertThat().statusCode(200).extract().response().asString(); 
		
	}
	
	public static String GenerateStringFromResource(String path) throws IOException {
		return new String (Files.readAllBytes(Paths.get(path)));
	}

}

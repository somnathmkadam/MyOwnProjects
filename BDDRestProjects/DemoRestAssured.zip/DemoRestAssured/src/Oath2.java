
public class Oath2 {
	
	//oath2.0 is social login case: google/face book login
	//client: bookmyshow, client id:to identify client ,client secret id: given by google at the time of reg
	//resource owner: user, resource/authorization server: google
	//Step1. in Book my show user login by hitting google authentication server which provide one code
	//Step 2. this code is fetched by book my show and create one request to hit google resource server which matches
	//code with particular user and provide required data to boook my show first n last name, token, profile pic and email id called scope which send in request no password shared
	// this is used because its easy to maintain user data without saving data in book my show data base so data leakage will not be happen
	//everything taken from google server
	//access token send by google is store in browser cookie 
	//ticket send on the basis of access token if token expires then book my show says to login again
	//Grand Types: Authorization code and Client credentials 
	
	//1. For code we first hit get request auth request in which params are scope: changes according to the data you want from google given by google
	//to know which server you should hit
	//auth url: google server url
	//client id: application user id for first time hitting
	//resource type: type of data you want from server: code authorization
	//redirection url: after giving successful code to which server google should redirect which is same page used for login
	//state: used for security its a code given by application to verify during google server redirection not mandatory
	//url: to hit first request is accounts.google.com/o.auth2/v2/auth
	//contains: scope, auth-url, client id, response type, redirect_url
	
	
	//take url and hit server on browser and response url we get a code contains state also
	
	//post request to get access token: second url is auth2/v4/token?code= called resource owner endpoint
	//in this we pass: code,client id, client secrets, redirect url,grant type: authorization_code/ client credentials
	
	
	//now get access tocken from response: use get request to get user data
	//1.get code 2.exchange tocken 3. actal request with token
	
	//contract details for oauth2.0: 1. Grand Type: authorization code structre 2.redirection url/call back url
	//3. access token url 4. client id 5. client screts 5. scope 6.state 7. how to pass oauth in request: header
	
	
	//Client crendiational is used when user wants its own data from another account
	//means from one account to another account so humnan is not include
	
	
	

}

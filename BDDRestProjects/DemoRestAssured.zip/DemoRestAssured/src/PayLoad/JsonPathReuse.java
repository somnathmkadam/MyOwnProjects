package PayLoad;

import io.restassured.path.json.JsonPath;

public class JsonPathReuse {
	
	public static JsonPath getreplaceresponse(String coderes) { //make static so we can reuse it in another class without creating object 
		
		JsonPath jsonre = new JsonPath(coderes);
		return jsonre;
		
	}

}

package PayLoad;

public class JsondataParse {
	
	public static String jsondata(){ //string return type given if method is not returning anything then we write void
	
		
String data =	"{\r\n" + 
		"		\"dashboard\" :{\r\n" + 
		"		\"purchaseamount\" : 910,\r\n" + 
		"		\"Website\" : \"rahushetty.com\" \r\n" + 
		"\r\n" + 
		"		},\r\n" + 
		"		\"courses\": [\r\n" + 
		"		{\r\n" + 
		"		\"title\" : \"selenium\",\r\n" + 
		"		\"price\" : 50,\r\n" + 
		"		\"copies\" : 6\r\n" + 
		"		},\r\n" + 
		"		{\r\n" + 
		"		\"title\" : \"cypress\",\r\n" + 
		"		\"price\" : 40,\r\n" + 
		"		\"copies\" : 4\r\n" + 
		"		},\r\n" + 
		"		{\r\n" + 
		"		\"title\": \"RPA\",\r\n" + 
		"		\"price\" : 45,\r\n" + 
		"		\"copies\" : 10\r\n" + 
		"		},\r\n" + 
		"\r\n" + 
		"\r\n" + 
		"		]\r\n" + 
		"\r\n" + 
		"		}\r\n" + 
		"		}";

return data;

	
}

}

package PayLoad;

public class Body {
	
	public static String Payload(){ //if we not give static then we have to create object in another class
		
		String body = "INF=0&appVersion=336&origin=DEL&destination=BOM"
				+ "&sessionId=b73d13743966d9cd15794106683223259&type=O&deviceId=b73d13743966d9cd&ADT=1&flight_depart_date=05/06/2020&osVersion=28&userType=GUEST&class=Economy&bookingMode=&CHD=0&"; 
		return body;
	}
	
	public static String Payload1(String appversion, String desti){	
	String body1= "\"INF\":\"0\",\"appVersion\":\""+appversion+"\",\"origin\":\"DEL\",\"destination\":\""+desti+"\"\",\"sessionId\":\"b73d13743966d9cd15794106683223259\",\"type\":\"O\",\"deviceId\":\"b73d13743966d9cd\",\"ADT\":\"1\",\"flight_depart_date\":\"05/06/2020\",\"osVersion\":\"28\",\"userType\":\"GUEST\",\"class\":\"Economy\",\"bookingMode\":\"\",\"CHD\":\"0\" \r\n" + 
			"";	
			return body1;
			
	}

}

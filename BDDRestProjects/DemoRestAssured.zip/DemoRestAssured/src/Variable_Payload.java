import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import PayLoad.Body;
import io.restassured.RestAssured;

public class Variable_Payload { //here we can change payload by adding 

	@Test(dataProvider="TestDataf")
	public void postreq(String appversion, String desti) {
	RestAssured.baseURI="https://secure.yatra.com";
	String response=	given().header("Content-Type","application/x-www-form-urlencoded").body(Body.Payload1("336","SIN")) //we passed payload in this way also
			.when().post("ccwebapp/mobile/flight/mdomandroid/getPersuasionData.htm")                                        //or we can use data provider string data directly
			.then().assertThat().statusCode(200).body("interationType", equalTo("PersuasionAPI"))
			.header("content-security-policy", "frame-ancestors 'self' *.yatra.com *.google.com").extract().response().asString(); 
	}
	
	@DataProvider(name="TestDataf")
	public Object [] [] getdata()
	{
		return new Object [][] {{"441","DEL"},{"552","SIN"},{"667","CHI"}};  //run three times
		//called parameterized data set with multiple data set
	}
}




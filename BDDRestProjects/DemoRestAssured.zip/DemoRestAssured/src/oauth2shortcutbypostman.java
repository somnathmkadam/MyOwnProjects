
public class oauth2shortcutbypostman {

	//Open postman: Get request: enter base url in and then select auth type in authorization
	//Tap on get access token: Enter call back url, Token name, auth url, access token url, client id, client secret,
	//Scope and grand type and them hit request token
	//Which open a new window having Google sign in page and then enter password
	//then you will get authen token in postman
	//now send this access token with request
	
	
}




package workpackage1;
import workpackage.Final_Keyword; // to access class from other package we have to use import
class abc extends Final_Keyword {

}

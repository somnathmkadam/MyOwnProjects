package Rest_assured;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;

public class postreq {
	public static void main(String args[]) throws IOException{
		Properties property = new Properties();
		
		FileInputStream fs;
		fs = new FileInputStream(System.getProperty("user.dir")+"\\config.propertise");
		property.load(fs);
	System.out.println(property.getProperty("URL"));	
	HttpClient client = HttpClients.custom().build();
	String json = "INF=0&appVersion=336&origin=DEL&destination=BOM&sessionId=b73d13743966d9cd15794106683223259&type=O&deviceId=b73d13743966d9cd&ADT=1&flight_depart_date=05/03/2020&osVersion=28&userType=GUEST&class=Economy&bookingMode=&CHD=0&";
    StringEntity entity = new StringEntity(json);
    
    String url=property.getProperty("URL");
    
    
    HttpPost httpPost=new HttpPost();
    HttpUriRequest request = RequestBuilder.post()
    		.setUri(url+property.getProperty("TYPE")+property.getProperty("TENANT")+property.getProperty("CALLTYPE"))
    		.setHeader(HttpHeaders.CONTENT_TYPE, "application/x-www-form-urlencoded")
  		  .setEntity(entity)
  		  .build();
  		
  		HttpResponse response= client.execute(request);
  		Scanner sc = new Scanner(response.getEntity().getContent());
  			
  			System.out.println(response.getStatusLine());
  			while(sc.hasNext()) {
  			     System.out.println(sc.nextLine());
  			     
  			     
  			    }
  	}

	
		
		
		
	}


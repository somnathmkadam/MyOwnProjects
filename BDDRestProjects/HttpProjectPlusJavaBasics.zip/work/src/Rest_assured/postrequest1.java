package Rest_assured;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;

public class postrequest1 {
	
	public static void main(String args[]) throws Exception{
		HttpClient client = HttpClients.custom().build();

		//String json = "INF=0&appVersion=336&origin=DEL&destination=BOM&sessionId=b73d13743966d9cd15794106683223259&type=O&deviceId=b73d13743966d9cd&ADT=1&flight_depart_date=05/03/2020&osVersion=28&userType=GUEST&class=Economy&bookingMode=&CHD=0&";
	    //StringEntity entity = new StringEntity(json);

	    List<NameValuePair> params = new ArrayList<NameValuePair>();
	    params.add(new BasicNameValuePair("INF","0"));
	    params.add(new BasicNameValuePair("appVersion","336"));
	    params.add(new BasicNameValuePair("origin","DEL"));
	    params.add(new BasicNameValuePair("destination","BOM"));
	    params.add(new BasicNameValuePair("sessionId","b73d13743966d9cd15794106683223259"));
	    params.add(new BasicNameValuePair("type","O"));
	    params.add(new BasicNameValuePair("deviceId","b73d13743966d9cd"));
	    params.add(new BasicNameValuePair("ADT","1"));
	    params.add(new BasicNameValuePair("flight_depart_date","05/03/2020"));
	    params.add(new BasicNameValuePair("osVersion","28"));
	    params.add(new BasicNameValuePair("userType","GUEST"));
	    params.add(new BasicNameValuePair("class","Economy"));
	    params.add(new BasicNameValuePair("bookingMode",""));
	    params.add(new BasicNameValuePair("CHD","0"));
	    
		HttpUriRequest request = RequestBuilder.post()
		  .setUri("https://secure.yatra.com/ccwebapp/mobile/flight/mdomandroid/getPersuasionData.htm")
		  .setHeader(HttpHeaders.CONTENT_TYPE, "application/x-www-form-urlencoded")
		  .setEntity(new UrlEncodedFormEntity(params))
		  .build();
		
		HttpResponse response= client.execute(request);
		Scanner sc = new Scanner(response.getEntity().getContent());
			
			System.out.println(response.getStatusLine());
			while(sc.hasNext()) {
			     System.out.println(sc.nextLine());
			    }
	}
	
}




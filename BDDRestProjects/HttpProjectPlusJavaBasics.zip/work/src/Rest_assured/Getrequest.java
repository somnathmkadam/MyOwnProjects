package Rest_assured;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

import org.apache.http.client.HttpClient;

public class Getrequest {
	
	public static void main  (String[]args) {
		
	//	RestAssured.baseURI="https://secure.yatra.com";
		
			given().
	    param("type","O").
		param("viewName","normal").
		param("flexi","0").
		param("noOfSegments","1").
		param("origin","DEL").
		param("originCountry","IN").
		param("destination","BOM").
		param("destinationCountry","IN").
		param("flight_depart_date","20%2F01%2F2020").
		param("ADT","1").
		param("CHD","0").
		param("INF","0").
		param("class","Economy").
		param("source","fresco-home").
		//header("Content-Type","application/x-www-form-urlencoded").
		//body("INF=0&appVersion=336&origin=DEL&destination=BOM&sessionId=b73d13743966d9cd15794106683223259&type=O&deviceId=b73d13743966d9cd&ADT=1&flight_depart_date=05/03/2020&osVersion=28&userType=GUEST&class=Economy&bookingMode=&CHD=0&").
		
		
		
		
		
		
		
		when().
		get("http://flight.yatra.com/air-search-ui/dom2/trigger").then().assertThat().statusCode(200)
		;
		
		
		
		
	}
	
	

}

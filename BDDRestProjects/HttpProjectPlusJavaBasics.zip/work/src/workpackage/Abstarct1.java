package workpackage;

 abstract class Abstarct1 extends Abstract {
	 
	 void disp()   // remaining methods explain in abstract2 but must be extends of abstract1
	 {
		 System.out.println("defining disp method from main class");
		 
	 }
	 
	 abstract void star();  //can define another abstract method
	 

}

package workpackage;

public class Interface implements A,B{
/*
 1. In interface all methods are abstract Method without body only signature and body given in other class
 2. The class with implements (extends/inherited) the interface they have to explain all methods given in interface like abstract 
 class otherwise they have defined as a abstract class
 3. one class can implement interface and extend other class called multiple inheritance / one class can inherited more than 
 one interface 
 ex: interface interfacename{
 variable declaration; and method declaration;
 }
 4. Normal class field can be static, constant or normal but in interface all field are constant and methods are abstract
 
 public static final datatype variablename = value; this is syntax    static-- class variable, final means value cant change
 or
 datatype variablename= value (Interface no need to define anything)
 Ex: int A=10;  here a is constant so written in capital you can write it in small letter also
 
 for methods:
 public returnType methodname (Parameter_list);
 in interface method is by default public so no need to write
 int add (int x, int y); --- signature (no body) abstarct method
 
 5. To inherite interface we use implements keyword
 6. we cannot create object of interface beacause all methods are abstact
 7. access specifier is only public keyword used in normal- public, private, protected used
 8. But in two interface we use extends keyword 
 ex: interface name1 extends name2, name3 ..{}  multiple interface combined in one interface
 9. One class can implement more than one interface 
 Ex: class classname implements interfacename1 , 2... {body}
 10. one class can extends one class and implement interface
 ex: class classname extends superclassname implements interface1, 2 ..{ body}
 

 */
	
	public void number() { // implemented methods of interface
	System.out.println("value of roll "+ roll);	
	}
	
	public void numberofB() {
		System.out.println("access interface b");
	}
	
	
	
}

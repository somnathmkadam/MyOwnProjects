package workpackage;

public class MethodOverriding_1 extends MethodOverriding {
	int y = 20;
	
	void disp()
	{
		System.out.println("in sub x is "+ x); //value of x taken from super class
		
		System.out.println(" in sub y is "+ y);
		
	}

}

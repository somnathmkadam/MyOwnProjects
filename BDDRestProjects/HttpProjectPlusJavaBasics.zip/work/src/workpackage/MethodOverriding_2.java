package workpackage;

public class MethodOverriding_2 {
	
	public static void main(String args[]) {
		MethodOverriding_1 obj = new MethodOverriding_1();
		obj.disp();
		
	}

}

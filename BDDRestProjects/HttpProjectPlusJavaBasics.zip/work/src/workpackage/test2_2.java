package workpackage;

public class test2_2 {
	
	public static void main(String args[]) {
		
		test2_1 obj = new test2_1(10,20); //object created
		obj.rectarea();
		
	}

	
	
	
}

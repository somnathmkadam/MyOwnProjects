package workpackage;

public class test1 {

	int a,b,c;
	void getdata(int x,int y) //Methods //return type is void
	{
	a=x;
	b=y;
	}
	void add ()  //method access by object obj
	{
	c=a+b;
	System.out.println("addition is "+ c);
	}
	
}

package workpackage;

 class Absatrct3_main {
	
	public static void main(String args[]) {
		
		Abstract2 obj = new Abstract2();
		obj.abcd();
		obj.disp();
		obj.disp1();
		obj.star();
		obj.view();
		
	}

}

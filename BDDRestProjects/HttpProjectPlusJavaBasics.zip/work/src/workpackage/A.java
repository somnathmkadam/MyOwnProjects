package workpackage;

public interface A {
int roll = 10;
void number(); // implement in interface class
}

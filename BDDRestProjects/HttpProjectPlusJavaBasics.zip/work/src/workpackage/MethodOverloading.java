package workpackage;

public class MethodOverloading {

/*
 Method name could be same but
 Number of argument, Type of argument, Sequence of argument must be differnt
 
 1. Number of arguments:
 add (int x,int y, int z)
 {
 }
 add (int x, int y)
 {
 }
 
 2. Type of argument:
 add (int x, int y)
 {
 }
 add (int x, float y)
 {
 }
 
 3. Sequence of argument:
 add (int x, float y)
 {
 }
 
 add (float x, int y)
 {
 }
	
 */
	

	int a,b;
	void calculation (int x)
	{
		a=x;
		System.out.println("Square is "+ a*a);
		
	}
	
	void calculation (int x, int y)
	{
		a=x;
		b=y;
		
		System.out.println("addition is "+ (a+b));
	}
	

	

}

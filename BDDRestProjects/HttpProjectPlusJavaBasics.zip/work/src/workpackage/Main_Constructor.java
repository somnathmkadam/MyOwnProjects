package workpackage;

public class Main_Constructor {

	public static void main(String args[]) {
		B_constructor obj = new B_constructor();
		
		// here Output is Constructor in class A   Constructor in class B
	}
	
	
}

package workpackage;

public class test1_1 {

	
	int a,b;
	
	test1_1() // constructor made in class whos value is default
	{
		System.out.println("addition method");
		a=10;
		b=20;
		
	}
void display()
{
	System.out.println("value of a is "+ a);
	System.out.println("value of b is "+b);
}
	
}

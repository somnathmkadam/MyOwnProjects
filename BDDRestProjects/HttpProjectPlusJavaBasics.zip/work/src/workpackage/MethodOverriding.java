package workpackage;

public class MethodOverriding {
	
	/*
	 Name, parameter and return type is same parent and child class (Sub class) 
	 
	 super class-- overridden method
	 subclass-- over riding method
	 
	 methods which cannot override:
	 private method cant inheritate, static method, constructor, final method
	 */
	
int x= 10;    // super class 
void disp() {
	System.out.println("value of x in super "+x );
}

	
	
}

package workpackage;

 class testofresult {
	public static void main(String args[]) {
		Result obj = new Result();
		obj.getmark(20, 30);
		obj.disp();
		
		
		
	}
	

}

package workpackage;

public class threads_Process {
	
	/*
	  thread is functionality under one process
	  Shred one memory locations 
	  where process shared different memory locations
	  process can be processed by processor one at a time
	  thread: task in one application
	   
	 */

}

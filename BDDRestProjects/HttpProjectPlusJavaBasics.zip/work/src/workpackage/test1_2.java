package workpackage;

public class test1_2 {

	public static void main(String args[]) {
		
		test1_1 obj = new test1_1(); //here created constructor is invoke
		obj.display();
		
	}
	
	
}

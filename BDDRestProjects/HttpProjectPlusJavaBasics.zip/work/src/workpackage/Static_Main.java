package workpackage;

 class Static_Main {
	
	public static void main(String args[]) {
		
		Static obj=new Static();
		obj.a=10;
		obj.cube1(20);// access normal method
		
		
		Static obj1 = new Static();
	
		obj1.a=5;
		obj1.cube1(10);
		
		
		int res = Static.cube(10); // Accessing static method from static class
		System.out.println("result of static method cube is " + res);
		
		int res1 = Static.x;
		System.out.println("taking 10 or 20 value=" + res1);
		
		
		
	}

}

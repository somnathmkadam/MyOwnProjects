package workpackage;

public class test2_1 {

	int length, width, result;
	
	test2_1 (int x, int y) //Parameterize constructor
	{
		length =x;
		width =y;
		
	}
	
	void rectarea() //method
	{
		result = length*width;
		System.out.println("area of rectangle "+ result);
	}
	
	
}

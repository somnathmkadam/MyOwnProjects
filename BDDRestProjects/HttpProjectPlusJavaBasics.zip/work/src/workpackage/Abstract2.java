package workpackage;

class Abstract2 extends Abstarct1 {
	
	void view() {   // defined remaining methods of abstract class
		System.out.println("view explain");
	}

	void disp1() {
	System.out.println("disp1 explain");	
	}
	
	void star() {
		
	System.out.println("star explain");
	}
}
